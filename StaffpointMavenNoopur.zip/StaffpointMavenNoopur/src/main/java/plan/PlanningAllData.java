package plan;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;

public class PlanningAllData extends PlanNextPage{

	
	
	public PlanningAllData(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
	
		//To access elements from PlanNextPage , TabularBarPage
		
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, PlanNextPage.class);

		PageFactory.initElements(driver, this);
	
	
	}

}
