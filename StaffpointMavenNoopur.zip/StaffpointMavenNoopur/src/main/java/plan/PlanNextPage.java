package plan;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;

public class PlanNextPage extends TabularBarPage{

	public PlanNextPage(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, this);
	}
	
	
	//Elements Related to LOB
	
	@FindBy(how = How.XPATH , 
			using = "//div[@id='LobInfoSection']/div[1]/span[2]")
	public WebElement Scenario_Parent_Client;

	@FindBy(how = How.XPATH , 
			using = "//div[@id='LobInfoSection']/div[2]/span[2]")
	public WebElement Scenario_Project;

	@FindBy(how = How.XPATH , 
			using = "//div[@id='LobInfoSection']/div[3]/span[2]")
	public WebElement Scenario_Site;

	
	
	//Elements related to Plan Tabs
	
	
	@FindBy(how = How.XPATH , 
			using = "//a[@section='4']")
	public WebElement Tab_Summary;

	@FindBy(how = How.XPATH , 
			using = "//a[@section='2']")
	public WebElement Tab_BreakDown;
	
	@FindBy(how = How.XPATH , 
			using = "//a[@section='3']")
	public WebElement Tab_Recomendations;

	@FindBy(how = How.XPATH , 
			using = "//a[@section='0']")
	public WebElement Tab_All_Data;
	
	//Element Related to date
	
	@FindBy(how = How.XPATH , 
			using = "//ul[@class='gridMenu']/li/a")
	public List<WebElement> Month_list;
	
	//Element to save to data base
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='saveToDataBaseBtnTop']")
	public WebElement Save_Database;
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Ok']")
	public List<WebElement> Database_Ok;
	
	
	//Element to save to profile
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='saveProfileBtnTop']")
	public WebElement Save_Profile;

	
	//Elements Related to Summary User Guide
	
	
	@FindBy(how = How.XPATH , 
			using = "//div[contains(@id ,'Wizard')]/label[text()=' Verify/update Run Rate Percent, if needed.']/div")
	public WebElement Verify_RunRate;
	
	@FindBy(how = How.XPATH , 
			using = "//div[contains(@id ,'Wizard')]/label[text()=' Verify/update FTE Actual/Projected.']/div")
	public WebElement Verify_Fte;
	
	
	@FindBy(how = How.XPATH , 
			using = "//div[contains(@id ,'Wizard')]/label[text()=' Verify/override Volume Forecast - Locked']/div")
	public WebElement Verify_Vol;
	
	@FindBy(how = How.XPATH , 
			using = "//div[contains(@id ,'Wizard')]/label[text()=' Verify/update Phone Occupancy Target']/div")
	public WebElement Verify_Locked;
	
	
	@FindBy(how = How.XPATH , 
			using = "//a[@id='opener']")
	public WebElement Verify_Opener;
	
	
	//Methods Related to breakdown user guide
	

	@FindBy(how = How.XPATH , 
			using = "//div[contains(@id ,'Wizard')]/label[text()=' Verify/update AHT Forecast']/div")
	public WebElement Verify_AHT;
	
	@FindBy(how = How.XPATH , 
			using = "//div[contains(@id ,'Wizard')]/label[text()=' Verify/update Headcount']/div")
	public WebElement Verify_Headcount;
	
	
	@FindBy(how = How.XPATH , 
			using = "//div[contains(@id ,'Wizard')]/label[text()=' Verify/update WorkHours']/div")
	public WebElement Verify_WorkHours;
	
	@FindBy(how = How.XPATH , 
			using = "//div[contains(@id ,'Wizard')]/label[text()=' Verify/update FTE Movements']/div")
	public WebElement Verify_Movements;
	
	
	@FindBy(how = How.XPATH , 
			using = "//div[contains(@id ,'Wizard')]/label[text()=' Verify/update Shrinkage']/div")
	public WebElement Verify_Shrinkage;
	
		
	
	//Method related to Plan Tabs
	
	public void clickSummary(){
		Tab_Summary.click();
	}
	
	
	public void clickBreakdown(){
		Tab_BreakDown.click();
	}
	
	public void clickRecomendations(){
		Tab_Recomendations.click();
	}
	
	public void clickAllData(){
		Tab_All_Data.click();
	}
	
	
	
	
	
	//Method Related to month select
	
	public void selectMonth(String Data_month){
		
		for(WebElement Sel_Month:Month_list){
		
		if(Sel_Month.getText().equalsIgnoreCase(Data_month)){
			
			Sel_Month.click();
			
		}
		}
	}
	
	//Method to compare Parent Client , Project , Site
	
	public ArrayList<String> verifyLob(){
		
		ArrayList<String> verify = new ArrayList();
		
		String str = Scenario_Parent_Client.getText();
	
		String str2 = Scenario_Project.getText();
		
		
		String str4 = Scenario_Site.getText();
	
		
		verify.add(str.trim());
		verify.add(str2.trim());
		verify.add(str4.trim());
		
		return verify;
			
	}
	
	public void saveDatabase() throws InterruptedException{
		
		Save_Database.click();
		
	
		for(WebElement Ok_first:Database_Ok){
			int X_Ok_first = Ok_first.getLocation().getX();
			int Y_Ok_first = Ok_first.getLocation().getY();	
			
			System.out.println( X_Ok_first+"1"+Y_Ok_first);
			if((X_Ok_first > 0)&&(Y_Ok_first > 0)){
				Ok_first.click();
			}
		}
		
		Thread.sleep(4000);
		
		for(WebElement Ok_Second:Database_Ok){
			int X_Ok_Second = Ok_Second.getLocation().getX();
			int Y_Ok_Second = Ok_Second.getLocation().getY();	
			System.out.println( X_Ok_Second+" "+Y_Ok_Second);
						
			if((X_Ok_Second > 0)&&(Y_Ok_Second > 0)){
				Ok_Second.click();

			}
		}
	}

		
	
	public void saveProfile(String ProfileName) throws InterruptedException{
		
		Save_Profile.click();
		
		Thread.sleep(2000);
		
		List<WebElement> Ok_List = driver.findElements(By.xpath("//span[@class='ui-button-text'][text()='Ok']"));
		for(WebElement Ok_first:Ok_List){
			int X_Ok_first = Ok_first.getLocation().getX();
			int Y_Ok_first = Ok_first.getLocation().getY();	
			
			System.out.println( X_Ok_first+"1"+Y_Ok_first);
			if((X_Ok_first > 0)&&(Y_Ok_first > 0)){
				Ok_first.click();
			}

			
		}
		//ele.click();
		
		WebElement Simulation_Name = driver.findElement(By.xpath("//input[@id='txtScenario']"));
		
		Simulation_Name.sendKeys(ProfileName);
		
		List<WebElement> Ok_List2 = driver.findElements(By.xpath("//span[@class='ui-button-text'][text()='Ok']"));
		System.out.println(Ok_List2.size());
		for(WebElement Ok_first:Ok_List2){
			int X_Ok_first = Ok_first.getLocation().getX();
			int Y_Ok_first = Ok_first.getLocation().getY();	
			
			System.out.println( X_Ok_first+"1"+Y_Ok_first);
			if((X_Ok_first > 0)||(Y_Ok_first > 0)){
				Ok_first.click();
			}
}
	
		Thread.sleep(8000);
		List<WebElement> Ok_List3 = driver.findElements(By.xpath("//span[@class='ui-button-text'][text()='Ok']"));
		for(WebElement Ok_first:Ok_List){
			System.out.println(Ok_List3.size());
			int X_Ok_first = Ok_first.getLocation().getX();
			int Y_Ok_first = Ok_first.getLocation().getY();	
			
			System.out.println( X_Ok_first+"1"+Y_Ok_first);
			if((X_Ok_first > 0)||(Y_Ok_first > 0)){
				Ok_first.click();
			}
}
		
		
	}
	
	
	public void SummaryUserGuide(){
		
		Actions action = new Actions(driver);
		
		action.moveToElement(Verify_RunRate).click(Verify_RunRate).build().perform();
		
		action.moveToElement(Verify_Fte).click(Verify_Fte).build().perform();
		
		action.moveToElement(Verify_Vol).click(Verify_Vol).build().perform();
		
		action.moveToElement(Verify_Locked).click(Verify_Locked).build().perform();
		
		action.moveToElement(Verify_Opener).click(Verify_Opener).build().perform();
		
		
		}
	
	
	public void BreakdownUserGuide(){
		
		Actions action = new Actions(driver);
		
		action.moveToElement(Verify_AHT).click(Verify_AHT).build().perform();
		
		action.moveToElement(Verify_Headcount).click(Verify_Headcount).build().perform();
		
		action.moveToElement(Verify_WorkHours).click(Verify_WorkHours).build().perform();
		
		action.moveToElement(Verify_Movements).click(Verify_Movements).build().perform();
		
		action.moveToElement(Verify_Shrinkage).click(Verify_Shrinkage).build().perform();
		
		action.moveToElement(Verify_Opener).click(Verify_Opener).build().perform();
		}
	


	
	}
