package plan;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;

public class PlanningRecomendation extends PlanNextPage {

	public PlanningRecomendation(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub

		//To access elements from PlanNextPage , TabularBarPage
		
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, PlanNextPage.class);

		PageFactory.initElements(driver, this);

	}



	//Elements for making Training visible

	@FindBy(how = How.XPATH , 
			using = "//tr[@role='row'][@id='683']/td[@role='gridcell'][@aria-describedby='metricGrid_Week1']")
	public WebElement Is_Tranining_Metric_Visible;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_0']/td/span[@style='cursor:pointer;']")
	public WebElement Make_Tranining_Metric_Visible;


	//List of Sections under Training


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='683']/td")
	public List<WebElement> NHC_Acceptable_Understaffing;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='684']/td")
	public List<WebElement> NHC_Max_Graduating;



	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='685']/td")
	public List<WebElement> NHC_Min_Graduating;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='686']/td")
	public List<WebElement> NHC_Locked_Required;

	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='687']/td")
	public List<WebElement> NHC_Contractual_Required;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='688']/td")
	public List<WebElement> NHC_Run_Rate_Required;

	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='689']/td")
	public List<WebElement> NHC_Actual;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='690']/td")
	public List<WebElement> NHC_Locked_Recommended;

	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='691']/td")
	public List<WebElement> NHC_Contractual_Recommended;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='692']/td")
	public List<WebElement> NHC_Run_Rate_Recommended;

	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='693']/td")
	public List<WebElement> NHC_Locked_Net_Recommended;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='694']/td")
	public List<WebElement> NHC_Contractual_Net_Recommended;

	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='695']/td")
	public List<WebElement> NHC_Run_Rate_Net_Recommended;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='696']/td")
	public List<WebElement> NHC_Class_Size;

	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='697']/td")
	public List<WebElement> NHC_Class_Size_Contractual;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='698']/td")
	public List<WebElement> NHC_Class_Size_Run_Rate;

	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='699']/td")
	public List<WebElement> Start_Date_Locked;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='700']/td")
	public List<WebElement> Start_Date_Contractual;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='701']/td")
	public List<WebElement> Start_Date_Run_Rate;


	//Elements to make ATO/OT Metrics Visible
	
	@FindBy(how = How.XPATH , 
			using = "//tr[@role='row'][@id='704']/td[@role='gridcell'][@aria-describedby='metricGrid_Week1']")
	public WebElement Is_ATO_Metric_Visible;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_1']/td/span[@style='cursor:pointer;']")
	public WebElement Make_ATO_Metric_Visible;
	

	//Elements Related to ATO/OT
	
	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='702']/td")
	public List<WebElement> ATO_Acceptable_Overstaffing;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='703']/td")
	public List<WebElement> ATO_Acceptable_Understaffing;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='704']/td")
	public List<WebElement> ATO_Locked;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='705']/td")
	public List<WebElement> ATO_Contractual;


	@FindBy(how = How.XPATH , 
			using = "//table[@id='metricGrid']/tbody/tr[@role='row'][@id='706']/td")
	public List<WebElement> ATO_Run_Rate;


	
	
	/*Methods to make Training Metric Visible or close*/
	
	public void makeTrainingMetricClose(){

		Make_Tranining_Metric_Visible.click();

	}


	public void makeTrainingMetricVisible(){

		int Training_X = Is_Tranining_Metric_Visible.getLocation().getX();
		int Training_Y = Is_Tranining_Metric_Visible.getLocation().getY();

		System.out.println(Training_X+" "+Training_Y);

		if(Training_X==0){

			Make_Tranining_Metric_Visible.click();

		}

	}


	/*Methods to get the Training metric value*/
	
	public void getNHC_Acceptable_Understaffing(String Week){

		for(WebElement week_Value:NHC_Acceptable_Understaffing){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getNHC_Max_Graduating(String Week){

		for(WebElement week_Value:NHC_Max_Graduating){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getNHC_Min_Graduating(String Week){

		for(WebElement week_Value:NHC_Min_Graduating){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}

	public void getNHC_Locked_Required(String Week){

		for(WebElement week_Value:NHC_Locked_Required){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getNHC_Contractual_Required(String Week){

		for(WebElement week_Value:NHC_Contractual_Required){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getNHC_Run_Rate_Required(String Week){

		for(WebElement week_Value:NHC_Run_Rate_Required){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getNHC_Actual(String Week){

		for(WebElement week_Value:NHC_Actual){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getNHC_Locked_Recommended(String Week){

		for(WebElement week_Value:NHC_Locked_Recommended){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getNHC_Contractual_Recommended(String Week){

		for(WebElement week_Value:NHC_Contractual_Recommended){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getNHC_Run_Rate_Net_Recommended(String Week){

		for(WebElement week_Value:NHC_Run_Rate_Net_Recommended){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getNHC_Class_Size(String Week){

		for(WebElement week_Value:NHC_Class_Size){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getNHC_Class_Size_Contractual(String Week){

		for(WebElement week_Value:NHC_Class_Size_Contractual){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}



	public void getNHC_Class_Size_Run_Rate(String Week){

		for(WebElement week_Value:NHC_Class_Size_Run_Rate){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getStart_Date_Locked(String Week){

		for(WebElement week_Value:Start_Date_Locked){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}



	public void getStart_Date_Contractual(String Week){

		for(WebElement week_Value:Start_Date_Contractual){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getStart_Date_Run_Rate(String Week){

		for(WebElement week_Value:Start_Date_Run_Rate){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	/*Methods to make ATO/OT Metric Visible or close*/
	
	public void makeATOMetricClose(){

		Make_ATO_Metric_Visible.click();

	}


	public void makeATOMetricVisible(){

		int ATO_X = Is_ATO_Metric_Visible.getLocation().getX();
		int ATO_Y = Is_ATO_Metric_Visible.getLocation().getY();

		System.out.println(ATO_X+" "+ATO_Y);

		if(ATO_X==0){

			Make_ATO_Metric_Visible.click();

		}

	}


	//Methods Related to ATO/OT metrics


	public void getATO_Acceptable_Overstaffing(String Week){

		for(WebElement week_Value:ATO_Acceptable_Overstaffing){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getATO_Acceptable_Understaffing(String Week){

		for(WebElement week_Value:ATO_Acceptable_Understaffing){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getATO_Locked(String Week){

		for(WebElement week_Value:ATO_Locked){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}


	public void getATO_Contractual(String Week){

		for(WebElement week_Value:ATO_Contractual){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}

	public void getATO_Run_Rate(String Week){

		for(WebElement week_Value:ATO_Run_Rate){

			if(week_Value.getAttribute("aria-describedby").equalsIgnoreCase(Week)){
				System.out.println(week_Value.getText());
			}	
		}
	}



}
