package plan;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;

public class PlanningBreakdown extends PlanNextPage {

	public PlanningBreakdown(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
	  
		//To access elements from PlanNextPage , TabularBarPage
		
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, PlanNextPage.class);

		PageFactory.initElements(driver, this);
	
	}

	

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_0']")
	public List<WebElement> Breakdown_HeadCount;

	
	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_1']")
	public List<WebElement> Breakdown_Requested;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_2']")
	public List<WebElement> Breakdown_Average;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_3']")
	public List<WebElement> Breakdown_FTEs;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_4']")
	public List<WebElement> Breakdown_Concurrency;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_5']")
	public List<WebElement> Breakdown_Volume;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_6']")
	public List<WebElement> Breakdown_AHT;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_7']")
	public List<WebElement> Breakdown_Shrinkage;

}
