package config;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;
import pageFactory.ConfigurationPage;
import pageFactory.PlanningPage;

public class DeleteConfiguration extends ConfigurationPage{

	public DeleteConfiguration(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
		
		PageFactory.initElements(driver, ConfigurationPage.class);
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, PlanningPage.class);
		PageFactory.initElements(driver, this);

		
	}



//List of fields in delete Configuration Page


@FindBy(how = How.XPATH , 
using = "//input[@type='submit'][@value='Confirm Delete']")
public WebElement ConfigDelete;


@FindBy(how = How.XPATH , 
using = "//div[@id='Project_Code_chosen']/div/ul[@class='chosen-results']/li")
public List<WebElement> Config_Project_list;


public void ConfigDelete(){
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("arguments[0].scrollIntoView(true);", ConfigDelete);
	
	ConfigDelete.click();
}


public void ConfigBack(){
	
	ConfigDelete.click();
}


}