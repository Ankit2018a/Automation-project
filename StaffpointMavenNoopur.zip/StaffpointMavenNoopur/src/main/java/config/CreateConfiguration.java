package config;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;
import pageFactory.ConfigurationPage;
import pageFactory.PlanningPage;

public class CreateConfiguration extends ConfigurationPage{

	public CreateConfiguration(WebDriver driver2) {
		super(driver2);

		// To access elements in Tabular bar Page and Configuration Page
		PageFactory.initElements(driver, ConfigurationPage.class);
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, PlanningPage.class);
		PageFactory.initElements(driver, this);

	}

	//List of fields in create Configuration Page


	//Elements Related to Project

	@FindBy(how = How.XPATH , 
			using = "//div[@id='Project_Code_chosen']")
	public WebElement Config_Project;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='Project_Code_chosen']/div/ul[@class='chosen-results']/li")
	public List<WebElement> Config_Project_list;


	//Elements Related to site

	@FindBy(how = How.XPATH , 
			using = "//div[@id='Site_Code_chosen']")
	public WebElement Config_Site;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='Site_Code_chosen']/div/ul[@class='chosen-results']/li")
	public List<WebElement> Config_Site_list;


	//Elements Related to Headcount type

	@FindBy(how = How.XPATH , 
			using = "//div[@id='HeadcountSource_chosen']")
	public WebElement Config_Headcount_type;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='HeadcountSource_chosen']/div/ul[@class='chosen-results']/li")
	public List<WebElement> Config_Headcount_type_list;

	/*input fields in createConfiguration Page*/

	//Elements Related to Agents
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='Production']")
	public WebElement Config_AgentProduction;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='Nesting']")
	public WebElement Config_AgentNesting;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='Training']")
	public WebElement Config_AgentTraining;

	//Elements Related to G&A
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='ProductionGA']")
	public WebElement Config_GAProduction;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='NestingGA']")
	public WebElement Config_GANesting;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='TrainingGA']")
	public WebElement Config_GATraining;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='FTEDefinitionDefaultValue']")
	public WebElement Config_FTEDefinition;

	@FindBy(how = How.XPATH , 
			using = "//input[@id='TargetPhoneOccupancyDefaultValue']")
	public WebElement Config_TargetPhoneOccupancy;



	@FindBy(how = How.XPATH , 
			using = "//input[@id='ContractualForecastPercentDefaultValue']")
	public WebElement Config_ContractualForecast;

	@FindBy(how = How.XPATH , 
			using = "//input[@id='LockedWeeks']")
	public WebElement Config_LockedWeeks;


	//Elements Related to First day of week type

	@FindBy(how = How.XPATH , 
			using = "//div[@id='chznDayOfWeek_chosen']")
	public WebElement Config_chznDayOfWeek;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='chznDayOfWeek_chosen']/div/ul[@class='chosen-results']/li")
	public List<WebElement> Config_chznDayOfWeek_list;


	//Elements Related to submit

	@FindBy(how = How.XPATH , 
			using = "//input[@type='submit'][@value='Save']")
	public WebElement Config_Save;

	//Element for going back to Config Page

	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/WeekConfiguration']")
	public WebElement Config_Back;

	
	//Elements Related to Verify Errors
	
	@FindBy(how = How.XPATH , 
			using = "//span[@class='field-validation-error']")
	public List<WebElement> Config_Errors;

	
	//methods related to Project

	public synchronized void selectConfigProject(String Data_Config_Project){

		Config_Project.click();


		Outerloop:
		for(WebElement Project:Config_Project_list ){

			if(Project.getText().equalsIgnoreCase(Data_Config_Project)){

				Project.click();
			
				break Outerloop; 
			}
		}
	}


	//methods related to Site

	public synchronized void selectConfigSite(String DataConfigSite){

		Config_Site.click();



		for(WebElement Site:Config_Site_list){

			if(Site.getText().equalsIgnoreCase(DataConfigSite)){

				Site.click();
				
				break;
			}
		}
	}

	//methods related to Headcount Type

	public synchronized void selectConfigHeadcountType(String DataConfigHeadcountType){

		Config_Headcount_type.click();



		for(WebElement Headcount_type:Config_Headcount_type_list){

			if(Headcount_type.getText().equalsIgnoreCase(DataConfigHeadcountType)){

				Headcount_type.click();
				
				break;
			}
		}
	}
	
		/*Methods related to Agents*/
	
	//Methods Related to Agent Production
	
	public void inputAgentProduction(String AgentProductionData){

		Config_AgentProduction.clear();
		
		Config_AgentProduction.sendKeys(AgentProductionData);
	}

	//Methods Related to Agent Nesting
	
	public void inputAgentNesting(String AgentNestingData){

		Config_AgentNesting.clear();
		
		Config_AgentNesting.sendKeys(AgentNestingData);
	}

	//Methods Related to Agent Training
	
	public void inputAgentTraining(String AgentTrainingData){

		Config_AgentTraining.clear();
		Config_AgentTraining.sendKeys(AgentTrainingData);
	}
	
	/*Methods related to G&A*/
	
	//Methods Related to G&A Production
	
	public void inputGAProduction(String GAProductionData){

		Config_GAProduction.clear();
		
		Config_GAProduction.sendKeys(GAProductionData);
	}

	//Methods Related to G&A Nesting
	
	public void inputGANesting(String GANestingData){

		Config_GANesting.clear();
		
		Config_GANesting.sendKeys(GANestingData);
	}

	//Methods Related to G&A Training
	
	public void inputGATraining(String GATrainingData){

		Config_GATraining.clear();
		Config_GATraining.sendKeys(GATrainingData);
	}

	//Method related to FTEDefinition

	public void inputConfigFTEDefinition(String FTEDefinitionData){

		Config_FTEDefinition.clear();
		
		Config_FTEDefinition.sendKeys(FTEDefinitionData);
	}

	//Method related to Target Phone Occupancy

	public void inputTargetPhoneOccupancy(String TargetPhoneOccupancyData){

		Config_TargetPhoneOccupancy.clear();
		
		Config_TargetPhoneOccupancy.sendKeys(TargetPhoneOccupancyData);
	}


	//Method related to Contractual Forecast

	public void inputContractualForecast(String ContractualForecastData){

		Config_ContractualForecast.clear();
		
		Config_ContractualForecast.sendKeys(ContractualForecastData);
	}


	//Method related to Locked weeks

	public void inputLockedWeeks(String LockedWeeksData){

		Config_LockedWeeks.clear();
		
		Config_LockedWeeks.sendKeys(LockedWeeksData);
	}

	//Method related to First Day of Week

	public void selectConfigFirstDayOfWeek(String DataFirstDayOfWeek){

		Config_chznDayOfWeek.click();



		for(WebElement First_Day:Config_chznDayOfWeek_list){

			if(First_Day.getText().equalsIgnoreCase(DataFirstDayOfWeek)){

				First_Day.click();
			}
		}
	}

	//To verify List of errors present in the Config Page
	
	public ArrayList<String> errorValidation(){
		ArrayList<String> Err = new ArrayList();
		for(WebElement error:Config_Errors){
			Err.add(error.getText());
		}
		 
		return Err;
	}
	
	
	//Methods related to Save

	public void clickSave(){

		Config_Save.click();
	}


	public void clickBack(){

		Config_Back.click();
	}
	

	
	
	
}
