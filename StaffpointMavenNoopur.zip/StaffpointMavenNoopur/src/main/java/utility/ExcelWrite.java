package utility;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbookType;

import org.apache.poi.ss.usermodel.Cell;

public class ExcelWrite {
	 private static final XSSFWorkbookType Excel_File = null;


		public static synchronized void writeExcel(String filePath ,String sheetName , String Result , int RowIndex , String ColumnName) throws IOException{
			  FileInputStream FIS = new FileInputStream(filePath);
			  FileOutputStream fos = null;
			  XSSFWorkbook ExcelWBook = new XSSFWorkbook(FIS);
			  System.out.println("Check3");
			  XSSFSheet ExcelWSheet =  ExcelWBook.getSheet(sheetName);
			  XSSFRow row = null;
			  XSSFCell cell = null;
			  int colNum = -1;
			  row = ExcelWSheet.getRow(0);
			  for(int i =0;i<row.getLastCellNum();i++){
				  System.out.println("Check4");
				  if(row.getCell(i).getStringCellValue().trim().equals(ColumnName)){
					  System.out.println("Check5");
					  colNum = i;
				  }
			  }
			  
			  Row row1 = ExcelWSheet.getRow(RowIndex);
			  System.out.println("Check6");
			  if(row1==null){
				  System.out.println("Check7");
				  row = ExcelWSheet.createRow(1);
			  }
			  System.out.println("Check8");
			  Cell cell1 =  row1.getCell(colNum);
			  
			  if(cell1==null){
				  cell1=row.createCell(1);
			  }
			  
			  System.out.println("Check9");
			  cell1.setCellValue(Result);
			  System.out.println("Check10");
			  fos = new  FileOutputStream(filePath);
			  System.out.println("Check11");
			  ExcelWBook.write(fos);
		    }
	  
}
