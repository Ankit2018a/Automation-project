package pageFactory;

public class Email {

}
