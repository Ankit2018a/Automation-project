package pageFactory;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import StaticPages.TabularBarPage;

public class AccountPlanning extends TabularBarPage{

	public AccountPlanning(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, this);
		
	}


	JavascriptExecutor scrool = null;
	
	//Element Related to create new configuration

	@FindBy(how = How.XPATH , 
			using = "//td[@title='Create a new account']")
	public WebElement Account_Create_New_Account;
	
	@FindBy(how = How.XPATH , 
			using = "//td[@title='refresh_accountGrid']")
	public WebElement Account_Refresh;
	
	
	//Element for Row Count
	
	@FindBy(how = How.XPATH , 
			using = "//select[@class='ui-pg-selbox'][@role='listbox']")
	public WebElement Select_row_Count;
	
	//Elements related to Configuration Grid
	//Row Elements
	
	@FindBy(how = How.XPATH , 
			using = "//table[@id='accountGrid']/tbody/tr")
	public List<WebElement> Account_List;
	
	/*
	//Column Elements
	@FindBy(how = How.XPATH , 
			using = "//table[@id='WeekConfigurationGrid']/tbody/tr")
	public WebElement Config_WeekConfiguration_List;
	
	*/
	
	//Cofiguration details
	

	
	//method to verify that configuration details for Project and sites
	
	
	public void getAccountValue(String OracleId ){
		
		for(WebElement TableRow:Account_List){
			
			String str2 = TableRow.getAttribute("id");
		
			System.out.println("check4");
			
	if((str2.length()>0)){
	
		
		String str1	=	"//table[@id='accountGrid']/tbody/tr[@id='"+str2+
				"']/td[@aria-describedby='accountGrid_OracleID']";

		WebElement el3 = driver.findElement(By.xpath(str1));
		
		System.out.println("check5");
		
		if(el3.getText().equalsIgnoreCase(OracleId)){
			
			System.out.println("check6");
			
			String str3	=	"//table[@id='accountGrid']/tbody/tr[@id='"+str2+
					"']/td[@aria-describedby='accountGrid_Action']/a/img[@alt='Account details']";

			WebElement el4 = driver.findElement(By.xpath(str3));
			
			System.out.println(el4.getAttribute("alt"));
			
			System.out.println(el4.getAttribute("src"));
			
			el4.click();
			
			break;
			
		}		
			
		}
		
	}
	}
	
	
	
	//edit Account
	
	public void editAccount(String OracleId ){
		
		for(WebElement TableRow:Account_List){
			
			String str2 = TableRow.getAttribute("id");
		
			System.out.println("check4");
			
	if((str2.length()>0)){
	
		
		String str1	=	"//table[@id='accountGrid']/tbody/tr[@id='"+str2+
				"']/td[@aria-describedby='accountGrid_OracleID']";

		WebElement el3 = driver.findElement(By.xpath(str1));
		
		System.out.println("check5");
		
		if(el3.getText().equalsIgnoreCase(OracleId)){
			
			System.out.println("check6");
			
			String str3	=	"//table[@id='accountGrid']/tbody/tr[@id='"+str2+
					"']/td[@aria-describedby='accountGrid_Action']/a/img[@alt='Edit account']";

			WebElement el4 = driver.findElement(By.xpath(str3));
			
			System.out.println(el4.getAttribute("alt"));
			
			System.out.println(el4.getAttribute("src"));
			
			el4.click();
			
			break;
			
		}		
			
		}
		
	}
	}
	
	//Delete Account
	
	public void deleteAccount(String OracleId ){
		
		for(WebElement TableRow:Account_List){
			
			String str2 = TableRow.getAttribute("id");
		
			System.out.println("check4");
			
	if((str2.length()>0)){
	
		
		String str1	=	"//table[@id='accountGrid']/tbody/tr[@id='"+str2+
				"']/td[@aria-describedby='accountGrid_OracleID']";

		WebElement el3 = driver.findElement(By.xpath(str1));
		
		System.out.println("check5");
		
		if(el3.getText().equalsIgnoreCase(OracleId)){
			
			System.out.println("check6");
			
			String str3	=	"//table[@id='accountGrid']/tbody/tr[@id='"+str2+
					"']/td[@aria-describedby='accountGrid_Action']/a/img[@alt='Delete account']";

			WebElement el4 = driver.findElement(By.xpath(str3));
			
			System.out.println(el4.getAttribute("alt"));
			
			System.out.println(el4.getAttribute("src"));
			
			el4.click();
			
			break;
			
		}		
			
		}
		
	}
			
	}
	
	
	public void selectRoWCount(String Value){
		
	Select RowCount = new Select(Select_row_Count);
	
	RowCount.selectByValue(Value);
	
	}
	
	
	
	//Methods related to Config Page
	
	
	
	public void newAccount(){
		
		Account_Create_New_Account.click();
	}
	
	
	public void Refresh(){
		
		Account_Refresh.click();
	}
	

	public void scrollGrid(){
		 scrool = (JavascriptExecutor) driver;
		//scrool.executeScript("window.scrollBy(0,500)", "");
		 //scrool.executeScript("document.querySelector('tr[id='27']")", "");
	
	}
	
	
}





