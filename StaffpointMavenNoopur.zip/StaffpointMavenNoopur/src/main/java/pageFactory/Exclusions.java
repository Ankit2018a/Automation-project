package pageFactory;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;

public class Exclusions extends TabularBarPage {

	public Exclusions(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
		
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, this);
		
	}
	
		@FindBy(how = How.XPATH , 
				using = "//table[@class='ui-pg-table navtable']/tbody/tr/td[@title='Create a new exclusion']") 
		WebElement Create_Exclusion;


		@FindBy(how = How.XPATH , 
				using = "//td[@id='exclusionsPager_center']/table/tbody/tr/td/select[@class='ui-pg-selbox']")
		public WebElement Select_Count;

		
		@FindBy(how = How.XPATH , 
				using = "//table[@id='exclusionsApprovalGrid']/tbody/tr")
		public List<WebElement> Request_Approval_Grid;
		
		
		//Elements Related to approval note
		@FindBy(how = How.XPATH , 
				using = "//div[@class='editor-field']/textarea[@id='Comments']")
		public WebElement Request_Approval_Note;
		
		//Exclusion Approve
		
		@FindBy(how = How.XPATH , 
				using = "//input[@type='submit'][@value='Approve']")
		public WebElement Exclusion_Approve;
		
		//Exclusion Reject
		
		@FindBy(how = How.XPATH , 
				using = "//input[@type='submit'][@value='Reject']")
		public WebElement Exclusion_Reject;
		
		
		//Elements Related to My Scope Exclusion
		
		@FindBy(how = How.XPATH , 
				using = "//table[@id='exclusionsGrid']/tbody/tr")
		public List<WebElement> MyScope_Grid;
		
		
		//to delete the Exclusion
		
		@FindBy(how = How.XPATH , 
				using = "//input[@type='submit'][@value='Confirm Delete']")
		public WebElement Confirm_Delete;
		
		
		
		//Methods related to create Exclusion
		
		
		public void newExclusion(){
			Create_Exclusion.click();
		}

		//Method related to Scope Exclusion Requests
		

		public void approveExclusion(String Project , String Site) throws InterruptedException{

			System.out.println("Check0");

			outerloop:
			for(WebElement tableRow:Request_Approval_Grid){

				System.out.println("Check1");

				String str2 = tableRow.getAttribute("id");

				//System.out.println(str2);

				if(str2.isEmpty()){ System.out.println(" String is Empty");
				}

				else{

					System.out.println("Check2");

					String str1	=	"//table[@id='exclusionsApprovalGrid']/tbody/tr[@id='"+str2+
							"']/td[@aria-describedby='exclusionsApprovalGrid_Project']";

					System.out.println(str1);

					Thread.sleep(1000);


					WebElement ele = null;
					try{
						ele = driver.findElement(By.xpath(str1));
					}

					catch(Exception e){
						System.out.println(e.getMessage());
					}

					
					System.out.println(ele.getText());

					if(ele.getText().trim().equalsIgnoreCase(Project)){

						System.out.println(tableRow.getAttribute("id"));

						String str = tableRow.getAttribute("id");

						String str3 = "//table[@id='exclusionsApprovalGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='exclusionsApprovalGrid_Site']";

						WebElement ele2 =	driver.findElement(By.xpath(str3));

						System.out.println(ele2.getText());
						
						if(ele2.getText().trim().equalsIgnoreCase(Site)){


							System.out.println(ele2.getText());
							System.out.println(ele.getText());

							String str4 = "//table[@id='exclusionsApprovalGrid']/tbody/tr[@id='"+str+
									"']/td[@aria-describedby='exclusionsApprovalGrid_Action']"
									+ "/a/img[@alt='Approve Exclusion Request']";
						

							WebElement Ele6 = driver.findElement(By.xpath(str4));
							

							Ele6.click();

						break outerloop;

						}
					}

				}		

			}

	}

		
		public void detailExclusion(String Project , String Site) throws InterruptedException{
		
			System.out.println("Check0");

			outerloop:
			for(WebElement tableRow:Request_Approval_Grid){

				System.out.println("Check1");

				String str2 = tableRow.getAttribute("id");

				//System.out.println(str2);

				if(str2.isEmpty()){ System.out.println(" String is Empty");
				}

				else{

					System.out.println("Check2");

					String str1	=	"//table[@id='exclusionsApprovalGrid']/tbody/tr[@id='"+str2+
							"']/td[@aria-describedby='exclusionsApprovalGrid_Project']";

					System.out.println(str1);

					Thread.sleep(1000);


					WebElement ele = null;
					try{
						ele = driver.findElement(By.xpath(str1));
					}

					catch(Exception e){
						System.out.println(e.getMessage());
					}

					
					System.out.println(ele.getText());

					if(ele.getText().trim().equalsIgnoreCase(Project)){

						System.out.println(tableRow.getAttribute("id"));

						String str = tableRow.getAttribute("id");

						String str3 = "//table[@id='exclusionsApprovalGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='exclusionsApprovalGrid_Site']";

						WebElement ele2 =	driver.findElement(By.xpath(str3));

						System.out.println(ele2.getText());
						
						if(ele2.getText().trim().equalsIgnoreCase(Site)){


							System.out.println(ele2.getText());
							System.out.println(ele.getText());

							String str4 = "//table[@id='exclusionsApprovalGrid']/tbody/tr[@id='"+str+
									"']/td[@aria-describedby='exclusionsApprovalGrid_Action']"
									+ "/a/img[@alt='Exclusion Request Details']";
						

							WebElement Ele6 = driver.findElement(By.xpath(str4));
							

							Ele6.click();

						break outerloop;

						}
					}

				}		

			}

			
		}
		
		public void rejectExclusion(String Project , String Site) throws InterruptedException{

			System.out.println("Check0");

			outerloop:
			for(WebElement tableRow:Request_Approval_Grid){

				System.out.println("Check1");

				String str2 = tableRow.getAttribute("id");

				//System.out.println(str2);

				if(str2.isEmpty()){ System.out.println(" String is Empty");
				}

				else{

					System.out.println("Check2");

					String str1	=	"//table[@id='exclusionsApprovalGrid']/tbody/tr[@id='"+str2+
							"']/td[@aria-describedby='exclusionsApprovalGrid_Project']";

					System.out.println(str1);

					Thread.sleep(1000);


					WebElement ele = null;
					try{
						ele = driver.findElement(By.xpath(str1));
					}

					catch(Exception e){
						System.out.println(e.getMessage());
					}

					
					System.out.println(ele.getText());

					if(ele.getText().trim().equalsIgnoreCase(Project)){

						System.out.println(tableRow.getAttribute("id"));

						String str = tableRow.getAttribute("id");

						String str3 = "//table[@id='exclusionsApprovalGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='exclusionsApprovalGrid_Site']";

						WebElement ele2 =	driver.findElement(By.xpath(str3));

						System.out.println(ele2.getText());
						
						if(ele2.getText().trim().equalsIgnoreCase(Site)){


							System.out.println(ele2.getText());
							System.out.println(ele.getText());

							String str4 = "//table[@id='exclusionsApprovalGrid']/tbody/tr[@id='"+str+
									"']/td[@aria-describedby='exclusionsApprovalGrid_Action']"
									+ "/a/img[@alt='Reject Exclusion Request']";
						

							WebElement Ele6 = driver.findElement(By.xpath(str4));
							

							Ele6.click();

						break outerloop;

						}
					}

				}		

			}

	}
		
		
		
		
	public void confirmApproval(String Approval_Notes){
		
		Request_Approval_Note.clear();
		
		Request_Approval_Note.sendKeys(Approval_Notes);
		
		Exclusion_Approve.click();
		
		
	}	
	
	
	public void rejectApproval(String Approval_Notes){
		
		Request_Approval_Note.clear();
		
		Request_Approval_Note.sendKeys(Approval_Notes);
		
		Exclusion_Reject.click();
		
		
	}	
	
	//My Scope Exclusion Requests
	
	public void editExclusion(String Project , String Site) throws InterruptedException{
		System.out.println("Check0");

		outerloop:
		for(WebElement tableRow:MyScope_Grid){

			System.out.println("Check1");

			String str2 = tableRow.getAttribute("id");

			//System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='exclusionsGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='exclusionsGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);


				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

				
				System.out.println(ele.getText());

				if(ele.getText().trim().equalsIgnoreCase(Project)){

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='exclusionsGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='exclusionsGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));

					System.out.println(ele2.getText());
					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){


						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='exclusionsGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='exclusionsGrid_Action']"
								+ "/a/img[@alt='Edit Exclusion Request']";
					

						WebElement Ele6 = driver.findElement(By.xpath(str4));
						

						Ele6.click();

					break outerloop;

					}
				}

			}		

		}
}
		
	
	public void deleteExclusion(String Project , String Site) throws InterruptedException{

		System.out.println("Check0");

		outerloop:
		for(WebElement tableRow:MyScope_Grid){

			System.out.println("Check1");

			String str2 = tableRow.getAttribute("id");

			//System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='exclusionsGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='exclusionsGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);


				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

				
				System.out.println(ele.getText());

				if(ele.getText().trim().equalsIgnoreCase(Project)){

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='exclusionsGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='exclusionsGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));

					System.out.println(ele2.getText());
					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){


						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='exclusionsGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='exclusionsGrid_Action']"
								+ "/a/img[@alt='Delete Exclusion Request']";
					

						WebElement Ele6 = driver.findElement(By.xpath(str4));
						

						Ele6.click();

					break outerloop;

					}
				}

			}		

		}

}
	
	//Confirm_Delete
	
	public void deleteConfirm(){
		
		Confirm_Delete.click();
		
	}

}