package pageFactory;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import StaticPages.TabularBarPage;

public class PlanningPage extends TabularBarPage{

	public PlanningPage(WebDriver driver2) {
		super(driver2);
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}

	//Line of business

		/*Elements Related to Plan Start date*/
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='StartDate']")
	public WebElement Plan_StartDate;

	
	/*Elements Related to Plan End date*/
	
	@FindBy(how = How.XPATH , 
			using = "//table[@class='ui-datepicker-calendar']/tbody/tr/td/a")
	public List<WebElement> Plan_StartDate_List;
	
	//Elements Related to date picker
	
	//Element to select Prev months
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Prev']")
	public WebElement Plan_StartDate_Prev;

	//Element to select Next month
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Next']")
	public WebElement Plan_StartDate_Next;

	
		/*Elements Related to Plan End date*/
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='FinishDate']")
	public WebElement Plan_EndDate;

	@FindBy(how = How.XPATH , 
			using = "//table[@class='ui-datepicker-calendar']/tbody/tr/td[@class=' ']")
	public WebElement Plan_EndDate_List;
	
	//Element to select Prev month
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Prev']")
	public WebElement Plan_EndDate_Prev;

	//Element to select Next month
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Next']")
	public WebElement Plan_EndDate_Next;

	
	//Elements related to Plan_Operation_Vp

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single']")
	public WebElement Plan_Operations_VP_ID;

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-search']/input[@type='text']")
	public WebElement Op_Vp_id_input;


	@FindBy(how = How.XPATH , 
			using = "//ul[@class='chosen-results']/li")
	public List<WebElement> Op_Vp_id_list;

	
	//Elements related to Simulation Grid in Planning Page
	
	@FindBy(how = How.XPATH , 
			using = "//table[@id='scenarioGrid']/tbody/tr[@role='row']")
	public List<WebElement> Simulation_List;
	
		
	//Elements related to Parent_Client_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='ParentClientIds_chosen']")
	public WebElement Parent_client_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ParentClientIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Parent_client_List;

	//Elements related to Client_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='ClientIds_chosen']")
	public WebElement Client_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ClientIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Client_List;

	//Elements related to Program_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='ProgramIds_chosen']")
	public WebElement Program_Id_Select;



	@FindBy(how = How.XPATH , 
			using = "//div[@id='ProgramIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Program_Id_List;

	//Elements related to Project_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='ProjectIds_chosen']")
	public WebElement Project_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ProjectIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Project_Id_List;

	//Elements related to Region

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='RegionIds_chosen']")
	public WebElement Region_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='RegionIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Region_Id_List;

	//Elements Related to country

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='CountryIds_chosen']")
	public WebElement Country_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='CountryIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Country_Id_List;

	//Elements Related to Site

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='SiteIds_chosen']")
	public WebElement Site_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='SiteIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Site_Id_List;



	//Element Related to create Plan

	@FindBy(how = How.XPATH , 
			using = "//input[@value='Retrieve/Create Plan']")
	public WebElement Plan_Submit;

	//Search Scenarios
	
	@FindBy(how = How.XPATH , 
			using = "//input[@value='Search Simulations']")
	public WebElement Search_Scenarios;
	
	
	//Plan Favorite


	@FindBy(how = How.XPATH , 
			using = "//img[@src='/StaffPoint.WebDev/Content/Images/fav_transparent_2.png']")
	public WebElement Plan_Favorite;

	//Favorite_Ok_Ui_Button

	@FindBy(how = How.XPATH , 
			using = "//span[@class='ui-button-text'][text()='Ok']")
	public List<WebElement> Ok_Favorite;

	@FindBy(how = How.XPATH , 
			using = "//span[@class='ui-button-text'][text()='Cancel']")
	public List<WebElement> Cancel_Favorite;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='txtFavorite']")
	public WebElement Favorite_Text;
	
	
	
	//View fav Planning
	
	@FindBy(how = How.XPATH , 
			using = "//img[@title='View Favorites'][@class='favorite']")
	public WebElement Favorite_View;
	
	
	@FindBy(how = How.XPATH , 
			using = "//table[@aria-labelledby='gbox_favoriteGrid'][@class='ui-jqgrid-btable']/tbody/tr")
	public List<WebElement> Fav_Favorite_Grid;
		
		
	//"//select[@class='ui-pg-selbox'][@role='listbox']"
	
	@FindBy(how = How.XPATH , 
			using = "//select[@class='ui-pg-selbox'][@role='listbox']")
	public WebElement Fav_Select;
	
	
	//Element for delete favourite pop up
	
	@FindBy(how = How.XPATH , 
			using = "//div[@class='ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix']/a/span[text()='close']")
	public WebElement Fav_delete;
	
	@FindBy(how = How.XPATH , 
			using = "//button[@type='button']/span[text()='Cancel']")
	public WebElement Fav_cancel;
	
	
	//Elements for sorting of simulations
	
	@FindBy(how = How.XPATH , 
			using = "//th[@id='scenarioGrid_Description']")
	public WebElement Name_Simulations;
	
	@FindBy(how = How.XPATH , 
			using = "//th[@id='scenarioGrid_CreatedDate']")
	public WebElement Created_date_Simulation;
	
	@FindBy(how = How.XPATH , 
			using = "//th[@id='scenarioGrid_CreatedBy']")
	public WebElement CreatedBy_Simulation;
	
	@FindBy(how = How.XPATH , 
			using = "//th[@id='scenarioGrid_Project']")
	public WebElement Project_Simulation;
	
	@FindBy(how = How.XPATH , 
			using = "//th[@id='scenarioGrid_Site']")
	public WebElement Site_Simulation;
	
	
	//Rowcount for Simulation Grid
	
	@FindBy(how = How.XPATH , 
			using = "//td[@id='scenarioPager_center']/table/tbody/tr/td/select[@class='ui-pg-selbox']")
	public WebElement Select_row_Count_Simulation;
	
	
	//Row count for favourite Grid
	
	
	@FindBy(how = How.XPATH , 
			using = "//td[@id='favoritePager_center']/table/tbody/tr/td/select[@class='ui-pg-selbox']")
	public WebElement Select_row_Count_Favourite;
	
		
	/*Method Related to Plan Start date*/
	
	public void selectStartDate(String Data_StartDate) throws InterruptedException{

		
		Plan_StartDate.click();

		Thread.sleep(2000);

		for(WebElement StartDate:Plan_StartDate_List ){
			
			if(StartDate.getText().equalsIgnoreCase(Data_StartDate)){
				
				StartDate.click();
				
				break;
			}
		}


	}
	
	//Method related to plan End Date
	
	public void selectEndDate(String Data_EndDate) throws InterruptedException{

		
		Plan_EndDate.click();

		Thread.sleep(2000);

		for(WebElement StartDate:Plan_StartDate_List ){

			
			if(StartDate.getText().equalsIgnoreCase(Data_EndDate)){

				
				StartDate.click();
				
				break;
			}
		}


	}
	
	
	
	
	//Method related to OP_VP

	public void selectOperationVp(String Data_Operations_Vp) throws InterruptedException{

		Plan_Operations_VP_ID.click();

		Op_Vp_id_input.sendKeys(Data_Operations_Vp);

		Thread.sleep(2000);


		for(WebElement Operations_Vp:Op_Vp_id_list ){

			if(Operations_Vp.getText().equalsIgnoreCase(Data_Operations_Vp)){

				Operations_Vp.click();
				
				break;
			}
		}


	}


	//Method related to Parent Client

	public void selectParentClient(String Data_ParentClient) throws InterruptedException{

		Parent_client_Select.click();

		Thread.sleep(1000);

		for(WebElement ParentClient:Parent_client_List ){

			if(ParentClient.getText().equalsIgnoreCase(Data_ParentClient)){

				ParentClient.click();
				
				break;
			}
		}
	}

	//Method related to client

	public void selectClient(String Data_Client) throws InterruptedException{

		//Actions act = new Actions(driver);
		
		//act.moveToElement(Client_Select).click().build().perform();
		
		Client_Select.click();

		Thread.sleep(1000);

		for(WebElement Client:Client_List){

			if(Client.getText().equalsIgnoreCase(Data_Client)){

				Client.click();
				
				break;
			}
		}
	}

	//Method Related to Program

	public void selectProgram(String Data_Program_Id) throws InterruptedException{

		Program_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Program_Id:Program_Id_List ){

			if(Program_Id.getText().equalsIgnoreCase(Data_Program_Id)){

				Program_Id.click();
				
				break;
			}
		}
	}

	//Method related to Project

	public void selectProject(String Data_Project_Id) throws InterruptedException{

		Project_Id_Select.click();


		Thread.sleep(2000);
		for(WebElement Project_Id:Project_Id_List ){

			if(Project_Id.getText().equalsIgnoreCase(Data_Project_Id)){

				Project_Id.click();
				
				break;
			}
		}
	}

	//Method related to Region

	public void selectRegion(String Data_Region) throws InterruptedException{

		Region_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Region:Region_Id_List ){

			if(Region.getText().equalsIgnoreCase(Data_Region)){

				Region.click();
				
				break;
			}
		}
	}

	//Method Related to country

	public void selectCountry(String Data_Country) throws InterruptedException{

		Country_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Country:Country_Id_List ){

			if(Country.getText().equalsIgnoreCase(Data_Country)){

				Country.click();
				
				break;
			}
		}
	}

	//Method related to site

	public void selectSite(String Data_Site) throws InterruptedException{

		Site_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Site:Site_Id_List ){

			if(Site.getText().equalsIgnoreCase(Data_Site)){

				Site.click();
				
				break;
			}
		}
	}



	public void submitPlan(){

		Plan_Submit.click();
		
	
	}

	public void submitFavorite(String Input_Faovorite_Name) throws InterruptedException{

		Plan_Favorite.click();

		Thread.sleep(2000);

		for(WebElement Ok_first:Ok_Favorite){
			int X_Ok_first = Ok_first.getLocation().getX();
			int Y_Ok_first = Ok_first.getLocation().getY();	
			if((X_Ok_first > 0)&&(Y_Ok_first > 0)){
				Ok_first.click();
			}
		}
		Favorite_Text.sendKeys(Input_Faovorite_Name);
		
		Thread.sleep(1000);
		
		for(WebElement Ok_Second:Ok_Favorite){
			int X_Ok_Second = Ok_Second.getLocation().getX();
			int Y_Ok_Second = Ok_Second.getLocation().getY();	
			if((X_Ok_Second > 0)&&(Y_Ok_Second > 0)){
				Ok_Second.click();
			}
		}
		
		Thread.sleep(4000);
		
		for(WebElement Ok_Third:Ok_Favorite){
			int X_Ok_Third = Ok_Third.getLocation().getX();
			int Y_Ok_Third = Ok_Third.getLocation().getY();	
			if((X_Ok_Third > 0)&&(Y_Ok_Third > 0)){
				Ok_Third.click();
			}
		}
	}


	public void cancelFavorite() throws InterruptedException{

		Plan_Favorite.click();

		Thread.sleep(3000);

		for(WebElement Cancel_first:Cancel_Favorite){
			int X_Cancel_first = Cancel_first.getLocation().getX();
			int Y_Cancel_first = Cancel_first.getLocation().getY();	
			if((X_Cancel_first > 0)&&(Y_Cancel_first > 0)){
				Cancel_first.click();
			}
		}

	}

	public void secondCancelFavorite(String Input_Favorite_Name) throws InterruptedException{

		Plan_Favorite.click();

		Thread.sleep(2000);

		for(WebElement Ok_first:Ok_Favorite){
			int X_Ok_first = Ok_first.getLocation().getX();
			int Y_Ok_first = Ok_first.getLocation().getY();	
			if((X_Ok_first > 0)&&(Y_Ok_first > 0)){
				Ok_first.click();
			}
		}
		Favorite_Text.sendKeys(Input_Favorite_Name);

		Thread.sleep(2000);
		
		for(WebElement Cancel_first:Cancel_Favorite){
			int X_Cancel_first = Cancel_first.getLocation().getX();
			int Y_Cancel_first = Cancel_first.getLocation().getY();	
			if((X_Cancel_first > 0)&&(Y_Cancel_first > 0)){
				Cancel_first.click();

			}
		}
	}
	
	

	public void viewFavPlanning(){
	 
	 Favorite_View.click();
	 
 }
	

	public void delFav(String Project , String Site ) throws InterruptedException{

		System.out.println("Check0");

		outerloop:
		for(WebElement tableRow:Fav_Favorite_Grid){

			System.out.println("Check1");

			String str2 = tableRow.getAttribute("id");

			//System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='favoriteGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='favoriteGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);


				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].scrollIntoView(true);", ele);
				
				System.out.println(ele.getText());

				if(ele.getText().trim().equalsIgnoreCase(Project)){

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='favoriteGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));

					System.out.println(ele2.getText());
					
					js = (JavascriptExecutor) driver;
					js.executeScript("arguments[0].scrollIntoView(true);", ele2);
					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){


						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_Action']"
								+ "/a/img[@title='Delete Favorite']";
					

						WebElement Ele6 = driver.findElement(By.xpath(str4));
						
						js = (JavascriptExecutor) driver;
						js.executeScript("arguments[0].scrollIntoView(true);", Ele6);

						Ele6.click();

					break outerloop;


					}
				}

			}		

		}

	}


	
	public void selectRoWCount(String Value){
		
	Select RowCount = new Select(Fav_Select);
	
	RowCount.selectByValue(Value);
	
	}
	
	
	
	public void delFavPopup(){
		
		Fav_delete.click();
		
	}
	
	
	//Method to view favorite


	public void viewFav(String Project , String Site ) throws InterruptedException{

		System.out.println("Check0");

		outerloop:
		for(WebElement tableRow:Fav_Favorite_Grid){

			System.out.println("Check1");

			String str2 = tableRow.getAttribute("id");

			//System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='favoriteGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='favoriteGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);


				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].scrollIntoView(true);", ele);
				
				System.out.println(ele.getText());

				if(ele.getText().trim().equalsIgnoreCase(Project)){

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='favoriteGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));

					System.out.println(ele2.getText());
					
					js = (JavascriptExecutor) driver;
					js.executeScript("arguments[0].scrollIntoView(true);", ele2);
					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){


						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_Action']"
								+ "/a/img[@title='Load Favorite']";
					

						WebElement Ele6 = driver.findElement(By.xpath(str4));
						
						js = (JavascriptExecutor) driver;
						js.executeScript("arguments[0].scrollIntoView(true);", Ele6);

						Ele6.click();

					break outerloop;

					}
				}

			}		

		}

}

	
	public void searchScenarios(){
		
		Search_Scenarios.click();
		
	}

	
	public void viewSimulationPlanning(String SimulationName) throws InterruptedException{
		
	System.out.println("Check0");
		
		//String Plan_Complaince = null;

		for(WebElement tableRow:Simulation_List){

			System.out.println("Check1");

			String str2 = tableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='scenarioGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='scenarioGrid_Description']";

				System.out.println(str1);

				Thread.sleep(1000);

				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

		
				System.out.println(ele.getText());

				if(ele.getText().trim().equalsIgnoreCase(SimulationName)){
					
					System.out.println(ele.getText());
					
					String str = tableRow.getAttribute("id");

					String str4 = "//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='scenarioGrid_Action']/input";

					
					WebElement Ele6 = driver.findElement(By.xpath(str4));
					
					Ele6.click();
					
					break;

				}
			}
		
	}
	
	
}

	
	public void sortingSimulation(){
		
		
		
		
	}

	public void deleteSimulationPlanning(String SimulationName) throws InterruptedException{
		
		System.out.println("Check0");
			
			//String Plan_Complaince = null;

			for(WebElement tableRow:Simulation_List){

				System.out.println("Check1");

				String str2 = tableRow.getAttribute("id");

				System.out.println(str2);

				if(str2.isEmpty()){ System.out.println(" String is Empty");
				}

				else{

					System.out.println("Check2");

					String str1	=	"//table[@id='scenarioGrid']/tbody/tr[@id='"+str2+
							"']/td[@aria-describedby='scenarioGrid_Description']";

					System.out.println(str1);

					Thread.sleep(1000);

					WebElement ele = null;
					try{
						ele = driver.findElement(By.xpath(str1));
					}

					catch(Exception e){
						System.out.println(e.getMessage());
					}

			
					System.out.println(ele.getText());

					if(ele.getText().trim().equalsIgnoreCase(SimulationName)){
						
						System.out.println(ele.getText());
						
						String str = tableRow.getAttribute("id");

						String str4 = "//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='scenarioGrid_Action']/a/img[@alt='Delete Simulation']";


						WebElement Ele6 = driver.findElement(By.xpath(str4));
						
						Ele6.click();
						
						break;

					}
				}
			
		}
		
			
	}
	
	/*
	 	@FindBy(how = How.XPATH , 
			using = "//th[@id='scenarioGrid_Description']")
	public WebElement Name_Simulations;
	
	@FindBy(how = How.XPATH , 
			using = "//th[@id='scenarioGrid_CreatedDate']")
	public WebElement Created_date_Simulation;
	
	@FindBy(how = How.XPATH , 
			using = "//th[@id='scenarioGrid_CreatedBy']")
	public WebElement CreatedBy_Simulation;
	
	@FindBy(how = How.XPATH , 
			using = "//th[@id='scenarioGrid_Project']")
	public WebElement Project_Simulation;
	
	@FindBy(how = How.XPATH , 
			using = "//th[@id='scenarioGrid_Site']")
	public WebElement Site_Simulation;
	 
	 */
	
	

public void sortingSimulation1() throws InterruptedException{
	
	Name_Simulations.click();
	
	Thread.sleep(2000);
	
	Created_date_Simulation.click();
	
	Thread.sleep(2000);
	
	CreatedBy_Simulation.click();
	
	Thread.sleep(2000);
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", Project_Simulation);
	
	Project_Simulation.click();
	
	js = (JavascriptExecutor) driver;
	js.executeScript("arguments[0].scrollIntoView(true);", Site_Simulation);
	
	Thread.sleep(2000);
	
	Site_Simulation.click();
	
} 
	

	public void selectSimulationRoWCount(String Value){
	
		Select RowCount = new Select(Select_row_Count_Simulation);

		RowCount.selectByValue(Value);

}
	
	public void selectfavoriteRoWCount(String Value){
		
		Select RowCount = new Select(Select_row_Count_Favourite);

		RowCount.selectByValue(Value);

}
	
	
}
