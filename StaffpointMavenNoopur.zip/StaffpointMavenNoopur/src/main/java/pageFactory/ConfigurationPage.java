package pageFactory;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import StaticPages.TabularBarPage;

public class ConfigurationPage extends TabularBarPage {

	public ConfigurationPage(WebDriver driver2) {
		super(driver2);
		// To access elements in Tabular bar Page
		
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, this);
	}

	JavascriptExecutor scrool = null;
	
	//Element Related to create new configuration

	@FindBy(how = How.XPATH , 
			using = "//td[@title='Create a new Week Configuration']")
	public WebElement Create_New_Config;
	
	@FindBy(how = How.XPATH , 
			using = "//td[@id='refresh_WeekConfigurationGrid']")
	public WebElement Config_Refresh;
	
	
	//Element for Row Count
	
	@FindBy(how = How.XPATH , 
			using = "//select[@class='ui-pg-selbox'][@role='listbox']")
	public WebElement Select_row_Count;
	
	//Elements related to Configuration Grid
	//Row Elements
	
	@FindBy(how = How.XPATH , 
			using = "//table[@id='WeekConfigurationGrid']/tbody/tr")
	public List<WebElement> Config_WeekConfiguration_List;
	
	/*
	//Column Elements
	@FindBy(how = How.XPATH , 
			using = "//table[@id='WeekConfigurationGrid']/tbody/tr")
	public WebElement Config_WeekConfiguration_List;
	
	*/
	
	//Cofiguration details
	

	
	//method to verify that configuration details for Project and sites
	
	
	public void getConfigurationValue(String Project , String Site ){
		
		for(WebElement TableRow:Config_WeekConfiguration_List){
			
			String str2 = TableRow.getAttribute("id");
		
			System.out.println("check4");
			
	if((str2.length()>0)){
	
		
		String str1	=	"//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str2+
				"']/td[@aria-describedby='WeekConfigurationGrid_Project']";

		List<WebElement> Al =(List<WebElement>) driver.findElements(By.xpath(str1));
		
		System.out.println("check5");
		
		for (WebElement ele:Al){
			
			if(ele.getText().equalsIgnoreCase(Project)){
				
								System.out.println(TableRow.getAttribute("id"));
				
				String str = TableRow.getAttribute("id");
				
				String str3 = "//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str+
						"']/td[@aria-describedby='WeekConfigurationGrid_Site']";
			
				System.out.println("check6");
				
			WebElement ele2 =driver.findElement(By.xpath(str3));
			
			if(ele2.getText().equalsIgnoreCase(Site)){
				
		System.out.println("check7");
		System.out.println(ele2.getText());
		System.out.println(ele.getText());
			
			}
				
		}		
			
		}
		
	}
	}
	}
	
	//delete configuration having Project and Site
	
	public void deleteConfigurationValue(String Project , String Site ){
		
		
		outerloop:
		for(WebElement TableRow:Config_WeekConfiguration_List){
			
			String str2 = TableRow.getAttribute("id");
		
	if((str2.length()>0)){
	
		
		String str1	=	"//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str2+
				"']/td[@aria-describedby='WeekConfigurationGrid_Project']";

		List<WebElement> Al =(List<WebElement>) driver.findElements(By.xpath(str1));
		
		for (WebElement ele:Al){
			
			if(ele.getText().equalsIgnoreCase(Project)){
				
			System.out.println(TableRow.getAttribute("id"));
				
				String str = TableRow.getAttribute("id");
				
				String str3 = "//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str+
						"']/td[@aria-describedby='WeekConfigurationGrid_Site']";
			
			WebElement ele2 =	driver.findElement(By.xpath(str3));
			
			if(ele2.getText().equalsIgnoreCase(Site)){
				
		System.out.println(ele2.getText());
		System.out.println(ele.getText());
				
				String str4 = "//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str+
						"']/td[@aria-describedby='WeekConfigurationGrid_Action']"
						+ "/a/img[@title='Delete Week Configuration']";
			
				
				WebElement ele7 =	driver.findElement(By.xpath(str4));
				
			
				ele7.click();
					break outerloop;
				
			}
			}
				
		}		
			
		}
		
	}
	}
	
	
	
	//delete configuration having Project and Site
	
	public void editConfigurationValue(String Project , String Site ){
		
		
		outerloop:
		for(WebElement TableRow:Config_WeekConfiguration_List){
			
			String str2 = TableRow.getAttribute("id");
		
	if((str2.length()>0)){
	
		
		String str1	=	"//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str2+
				"']/td[@aria-describedby='WeekConfigurationGrid_Project']";

		List<WebElement> Al =(List<WebElement>) driver.findElements(By.xpath(str1));
		
		for (WebElement ele:Al){
			
			if(ele.getText().equalsIgnoreCase(Project)){
				
			System.out.println(TableRow.getAttribute("id"));
				
				String str = TableRow.getAttribute("id");
				
				String str3 = "//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str+
						"']/td[@aria-describedby='WeekConfigurationGrid_Site']";
			
			WebElement ele2 =	driver.findElement(By.xpath(str3));
			
			if(ele2.getText().equalsIgnoreCase(Site)){
				
		System.out.println(ele2.getText());
		System.out.println(ele.getText());
				
				String str4 = "//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str+
						"']/td[@aria-describedby='WeekConfigurationGrid_Action']"
						+ "/a/img[@title='Edit Week Configuration']";
			
				
				WebElement ele7 =	driver.findElement(By.xpath(str4));
				
			
				ele7.click();
					break outerloop;
				
			}
			}
				
		}		
			
		}
		
	}
	}
	
	
	public void detailConfigurationValue(String Project , String Site ){
		
		
		outerloop:
		for(WebElement TableRow:Config_WeekConfiguration_List){
			
			String str2 = TableRow.getAttribute("id");
		
	if((str2.length()>0)){
	
		
		String str1	=	"//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str2+
				"']/td[@aria-describedby='WeekConfigurationGrid_Project']";

		List<WebElement> Al =(List<WebElement>) driver.findElements(By.xpath(str1));
		
		for (WebElement ele:Al){
			
			if(ele.getText().equalsIgnoreCase(Project)){
				
			System.out.println(TableRow.getAttribute("id"));
				
				String str = TableRow.getAttribute("id");
				
				String str3 = "//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str+
						"']/td[@aria-describedby='WeekConfigurationGrid_Site']";
			
			WebElement ele2 =	driver.findElement(By.xpath(str3));
			
			if(ele2.getText().equalsIgnoreCase(Site)){
				
		System.out.println(ele2.getText());
		System.out.println(ele.getText());
				
				String str4 = "//table[@id='WeekConfigurationGrid']/tbody/tr[@id='"+str+
						"']/td[@aria-describedby='WeekConfigurationGrid_Action']"
						+ "/a/img[@title='Week Configuration details']";
			
				
				WebElement ele7 =	driver.findElement(By.xpath(str4));
				
			
				ele7.click();
					break outerloop;
				
			}
			}
				
		}		
			
		}
		
	}
	}
	
	
	
	
	
	
	public void selectRoWCount(String Value){
		
	Select RowCount = new Select(Select_row_Count);
	
	RowCount.selectByValue(Value);
	
	}
	
	
	
	//Methods related to Config Page
	
	
	
	public void newConfig(){
		
		Create_New_Config.click();
	}
	
	
	public void Refresh(){
		
		Config_Refresh.click();
	}
	

	public void scrollGrid(){
		 scrool = (JavascriptExecutor) driver;
		//scrool.executeScript("window.scrollBy(0,500)", "");
		 //scrool.executeScript("document.querySelector('tr[id='27']")", "");
	
	
	}
	
	
}
