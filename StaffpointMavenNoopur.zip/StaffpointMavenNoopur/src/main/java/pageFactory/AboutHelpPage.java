package pageFactory;

import org.openqa.selenium.WebDriver;

import StaticPages.TabularBarPage;

public class AboutHelpPage extends TabularBarPage {

	public AboutHelpPage(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
	}

}
