package TestScripts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;

import utility.ExcelWrite;
import utility.ExcellData;
import utility.Repositories;
import utility.TakeScreenshot;

public class DriverConfig {

	WebDriver StaffpointDriver = null;
	DesiredCapabilities capabilities=null;
	ChromeOptions options=null;
	String[][] getExcell = null;
	int RowIndex;

	
	
	@BeforeMethod
	public void beforeMethod() throws IOException, JSONException {

		 /* ExtentReports extent;
		  
		  extent = new ExtentReports (System.getProperty("user.dir") +"/test-output/STMExtentReport.html", true);
		//Configuring Chrome Options to Enable Automation extension in Chrome
*/
		options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_settings.popups", 0);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.setExperimentalOption("excludeSwitches", Arrays.asList("enable-automation"));
		options.addArguments("start-maximized");
		options.addArguments("ash-debug-shortcuts");
		options.addArguments("ash-dev-shortcuts");

		//Chrome Option is Passed to Desired Capabilities to make driver Compatible

		capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		int count = 0;

		System.out.println(capabilities.isJavascriptEnabled());
		System.out.println(capabilities.getCapability(ChromeOptions.CAPABILITY));



		// 

		while(count==0){
			try{
				System.setProperty(Repositories.getChromeProperty(), Repositories.getChromePath());
				StaffpointDriver = new ChromeDriver(capabilities);
				count++;
			}

			catch(Exception e){
				e.printStackTrace();

			}	
			System.out.println(options.toJson());

		}

		try{

			StaffpointDriver.get(Repositories.getURL());

			//dvr.get("https://www.google.com");
		}
		catch(Exception e){
			e.printStackTrace();
			
		}	
		

	}

	@AfterMethod(alwaysRun=true)
	public void writeResult(ITestResult result) throws IOException, InterruptedException
		{
		
		
		TakeScreenshot.screenShot(StaffpointDriver, Repositories.getScreenshotPath());
		
		
		//Reporter.log(result.getName());
		 
			try
		    {
		        if(result.getStatus() == ITestResult.SUCCESS)
		        {
		        	TakeScreenshot.screenShot(StaffpointDriver, Repositories.getScreenshotPath());
		            //System.out.println("Log Message:: @AfterMethod: Method-"+methodName+"- has Failed");
		            //Do your excel writing stuff here
		        	ExcelWrite.writeExcel("C:\\Users\\499434\\Desktop\\Staffpoint_testData.xlsx", "PlanningData", "Pass", 1 , "Test Results");
		        	Reporter.log("The given Method is Passed"+result.getMethod().getMethodName());
		        }
		        else if(result.getStatus() == ITestResult.FAILURE)
		        {
		        	TakeScreenshot.screenShot(StaffpointDriver, Repositories.getScreenshotPath());
		            //System.out.println("Log Message:: @AfterMethod: Method-"+methodName+"- has Failed");
		            //Do your excel writing stuff here
		        	ExcelWrite.writeExcel("C:\\Users\\499434\\Desktop\\Staffpoint_testData.xlsx", "PlanningData", "Fail", 1 , "Test Results");
		        	Reporter.log("The given Method is Failed"+result.getMethod().getMethodName());
		        }
		        else if(result.getStatus() == ITestResult.SKIP)
		        {
		        	TakeScreenshot.screenShot(StaffpointDriver, Repositories.getScreenshotPath());
		            //System.out.println("Log Message:: @AfterMethod: Method-"+methodName+"- has Failed");
		            //Do your excel writing stuff here
		        	ExcelWrite.writeExcel("C:\\Users\\499434\\Desktop\\Staffpoint_testData.xlsx", "PlanningData", "Skip", 1 , "Test Results");
		        	Reporter.log("The given Method is Skipped"+result.getMethod().getMethodName());

		        }
		    }
		    catch(Exception e)
		    {
		        System.out.println("\nLog Message::@AfterMethod: Exception caught");
		        e.printStackTrace();
		    }

		    //StaffpointDriver.quit();
		    
		}
	@AfterMethod(dependsOnMethods="writeResult")
	public void driverQuit()
	{
		StaffpointDriver.quit();
	}
	
	
}
