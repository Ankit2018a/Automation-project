package TestScripts;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.apache.log4j.*;
import org.apache.log4j.PropertyConfigurator;



import pageFactory.ConfigurationPage;
import pageFactory.HomePage;
import pageFactory.Login_Page;
import pageFactory.PlanningPage;
import plan.PlanNextPage;
import utility.ExcelWrite;
import utility.ExcellData;
import utility.Loggers;
import utility.Repositories;
import StaticPages.TabularBarPage;
import config.DeleteConfiguration;



@Test
public class ValidatePlan extends DriverConfig {
	
	

	//PropertyConfigurator.configure("Log4j.properties");
	
	
	
	
  /*
	@Test(priority=1)
  public void CreatePlan() throws AWTException, InterruptedException {
	

		Login_Page.userLogin();
		Thread.sleep(5000);
		
		Thread.sleep(3000);


		DeleteConfiguration dc = new DeleteConfiguration(StaffpointDriver);

		dc.clickConfiguration();
		dc.selectRoWCount("100");

		String str1 = "EXPERIAN SERVICE CORP [835]";
		String str2 = "Kuala Lumpur, MY [132]";
		//ccp.scrollGrid();
		
		//ccp.getConfigurationValue(str1 , str2);
		
		JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
		
		js.executeScript("window.scrollBy(0,500)");
		
		Thread.sleep(6000);
		
		dc.deleteConfigurationValue(str1, str2);
		
		Thread.sleep(3000);
		
		
		Thread.sleep(3000);
		
		js = (JavascriptExecutor)StaffpointDriver;
		
		js.executeScript("window.scrollBy(0,500)");

		dc.ConfigBack();
		
		Thread.sleep(2000);
		
		dc.clickConfiguration();
		
		Thread.sleep(4000);
		dc.selectRoWCount("100");

		//ccp.scrollGrid();
		
		//ccp.getConfigurationValue(str1 , str2);
		
		Thread.sleep(3000);
		
		dc.deleteConfigurationValue(str1, str2);
		
		Thread.sleep(3000);
		
		dc.ConfigDelete();
		 
  }*/
	
	
  
	public void CreatePlanDB() throws AWTException, InterruptedException {
		
		//Login_Page lp = new Login_Page();
		  
		 //lp.userLogin();
		
		try {
			/*getExcell = ExcellData.ExcelData(Repositories.getExcelPath(), Repositories.getSheet("ExclusionSheet"));
			 Thread.sleep(3000);
			System.out.println(getExcell[1][1]);
			*/
			//getExcell = ExcellData.ExcelData(Repositories.getExcelPath(), Repositories.getSheet("PlanningSheet") );
			getExcell = ExcellData.ExcelData("C:\\Users\\499434\\Desktop\\Staffpoint_testData.xlsx", "PlanningData");
			 Thread.sleep(3000);
			 int RowIndex=1;
			System.out.println(getExcell[RowIndex][1]);
			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	/*	
		Reporter.log("The following is the Test data we are using");
		
		
		Thread.sleep(7000);
	
		PlanningPage pp = new PlanningPage(StaffpointDriver);	
		 
		 Thread.sleep(3000);
		 pp.clickPlanning(); 
	  
		 Thread.sleep(2000);
		
		//String Data_Operations_Vp = "COMBS DARLA [1487783]";
		
			//pp.selectOperationVp(Data_Operations_Vp);
			
			Thread.sleep(3000);
			
			String Data_Start_Date = getExcell[2][2];
			
		
			String Data_ParentClient = getExcell[2][3];
			
					
			String Data_Client = getExcell[2][4];
			
			String Data_program = getExcell[2][5];
			
			String Data_project = getExcell[2][6];
			
			String Data_region = getExcell[2][7];
			
			String Data_Country = getExcell[2][8];
			
			String Data_Site = getExcell[2][9];
						
			String Data_EndDate = getExcell[2][10];
			
			String Project_Valid= getExcell[2][11];
								
			String Site_Valid	= getExcell[2][12];
			
			pp.selectStartDate(Data_Start_Date);
			
			Reporter.log("The given StartDate is selected"+Data_Start_Date);
			
			Thread.sleep(3000);
			
			pp.selectEndDate(Data_EndDate);
			
			Reporter.log("The given EndDate is selected"+Data_EndDate);
			
			Thread.sleep(3000);
			
			pp.selectParentClient(Data_ParentClient);
			
			Reporter.log("The given ParentClient is selected"+Data_ParentClient);
			
			Thread.sleep(4000);
			
			pp.selectClient(Data_Client);
			
			Reporter.log("The given Client is selected"+Data_Client);
			
			Thread.sleep(4000);
		
			pp.selectProgram(Data_program);
			
			Reporter.log("The given program is selected"+Data_program);
			
			Thread.sleep(4000);
			
			pp.selectProject(Data_project);
			
			Reporter.log("The given project is selected"+Data_project);
			
			Thread.sleep(4000);
			
			pp.selectRegion(Data_region);
			
			Reporter.log("The given region is selected"+Data_region);
			
			Thread.sleep(4000);
		
			pp.selectCountry(Data_Country);
		
			Reporter.log("The given Country is selected"+Data_Country);
			
			Thread.sleep(4000);
		
			pp.selectSite(Data_Site);
			
			Reporter.log("The given Site is selected"+Data_Site);
			
			Thread.sleep(4000);
		
			pp.submitPlan();
		
			Reporter.log("The Plan is Submitted");
			
			Thread.sleep(3000);
			
			PlanNextPage pnp = new PlanNextPage(StaffpointDriver);
			
			Reporter.log("Navigated to Plan Next Page ");
			
			Thread.sleep(3000);
			
			pnp.SummaryUserGuide();
			
			Reporter.log("The SummaryUserGuide is  checked");
		
			Thread.sleep(3000);
			
			pnp.clickBreakdown();
			
			Reporter.log("The Breakdown Tab is selected");
		
			Thread.sleep(3000);

			pnp.BreakdownUserGuide();
			
			Reporter.log("The BreakdownUserGuide is  checked");
		
			Thread.sleep(3000);
			
			pnp.saveDatabase();
			
			Reporter.log("The Plan is saved into database");*/
			
  }
	
	/*
		@Test(priority=2)
	  public void CreateFav() throws AWTException, InterruptedException { 
		  
			//Login_Page lp = new Login_Page();
			  
			 //lp.userLogin();
			  
			Thread.sleep(7000);
		
			PlanningPage pp = new PlanningPage(StaffpointDriver);	
			 
			 Thread.sleep(3000);
			 pp.clickPlanning(); 
		  
			 System.out.println("check1");
			 
			 System.out.println("check2");
			 Thread.sleep(2000);
			
			//String Data_Operations_Vp = "COMBS DARLA [1487783]";
			
				//pp.selectOperationVp(Data_Operations_Vp);
				
				Thread.sleep(3000);
				
				String Data_Start_Date = "6";
				
				String Data_ParentClient = "2020 Exchange [12052]";
				
				String Data_Client = "2020 Exchange - L&L - Australia [R823]";
				
				String Data_program = "2020 Exchange - L&L - Australia [R823]";
				
				String Data_project = "2020 Exchange - L&L - Australia [R823]";
				
				String Data_region = "Europe [EUR]";
				
				String Data_Country = "Bulgaria [BG]";
				
				String Data_Site = "Plovdiv, Bulgaria [347]";
				
				String Data_EndDate = "15";
				
				String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
						
				String Site_Valid	= "Plovdiv, Bulgaria";
				
				pp.selectStartDate(Data_Start_Date);
				
				Thread.sleep(3000);
				
				pp.selectEndDate(Data_EndDate);
				
				Thread.sleep(3000);
				
				pp.selectParentClient(Data_ParentClient);
				
				Thread.sleep(4000);
				
				pp.selectClient(Data_Client);
				
				Thread.sleep(4000);
				
				pp.selectProgram(Data_program);
				
				Thread.sleep(4000);
				
				pp.selectProject(Data_project);
				
				Thread.sleep(4000);
				
				pp.selectRegion(Data_region);
				
				Thread.sleep(4000);
				
				pp.selectCountry(Data_Country);
				
				Thread.sleep(4000);

				pp.selectSite(Data_Site);
				
				Thread.sleep(4000);
				
				pp.submitFavorite("Hello");
				
				Thread.sleep(2000);

				pp.viewFavPlanning();
				
				Thread.sleep(4000);
				
				pp.selectRoWCount("100");
				
				Thread.sleep(4000);
				
				pp.viewFav("2020 Exchange - L&L - Australia", "Plovdiv Bulgaria");
		  
	  }
	
			
			@Test(priority=3)
		  public void deleteFav() throws AWTException, InterruptedException { 
			  
				//Login_Page lp = new Login_Page();
				  
				 //lp.userLogin();
				  
				Thread.sleep(7000);
			
				PlanningPage pp = new PlanningPage(StaffpointDriver);	
				 
				 Thread.sleep(3000);
				 pp.clickPlanning(); 
			  
				 System.out.println("check1");
				 
				 System.out.println("check2");
				 Thread.sleep(2000);
				
				//String Data_Operations_Vp = "COMBS DARLA [1487783]";
				
					//pp.selectOperationVp(Data_Operations_Vp);
					
					Thread.sleep(3000);
					
					String Data_Start_Date = "6";
					
					String Data_ParentClient = "2020 Exchange [12052]";
					
					String Data_Client = "2020 Exchange - L&L - Australia [R823]";
					
					String Data_program = "2020 Exchange - L&L - Australia [R823]";
					
					String Data_project = "2020 Exchange - L&L - Australia [R823]";
					
					String Data_region = "Europe [EUR]";
					
					String Data_Country = "Bulgaria [BG]";
					
					String Data_Site = "Plovdiv, Bulgaria [347]";
					
					String Data_EndDate = "15";
					
					String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
							
					String Site_Valid	= "Plovdiv, Bulgaria";
					
					pp.selectStartDate(Data_Start_Date);
					
					Thread.sleep(3000);
					
					pp.selectEndDate(Data_EndDate);
					
					Thread.sleep(3000);
					
					pp.selectParentClient(Data_ParentClient);
					
					Thread.sleep(4000);
					
					pp.selectClient(Data_Client);
					
					Thread.sleep(4000);
					
					pp.selectProgram(Data_program);
					
					Thread.sleep(4000);
					
					pp.selectProject(Data_project);
					
					Thread.sleep(4000);
					
					pp.selectRegion(Data_region);
					
					Thread.sleep(4000);
					
					pp.selectCountry(Data_Country);
					
					Thread.sleep(4000);

					pp.selectSite(Data_Site);
					
					Thread.sleep(4000);
					
					pp.submitFavorite("Hello");
					
					Thread.sleep(2000);

					pp.viewFavPlanning();
					
					Thread.sleep(4000);
					
					pp.selectRoWCount("100");
					
					Thread.sleep(4000);
					
					pp.delFav("2020 Exchange - L&L - Australia", "Plovdiv Bulgaria");
					
					
					WebElement DelFav = StaffpointDriver.findElement(By.xpath("//div[@aria-labelledby='ui-dialog-title-dialogConfirmMessage']/div/table/tbody/tr/td/label[@id='dialogConfirmText']"));
					
					Assert.assertEquals(DelFav.getText().trim(), "Are you sure you want to delete this favorite?");
					
					Thread.sleep(1000);
					
					//DelFav.getText()
					
					//pp.viewFav("2020 Exchange - L&L - Australia", "Plovdiv Bulgaria");
					
					pp.delFavPopup();
			  
		  }
			
			@Test(priority=4)
			  public void CreatePlanProfile() throws AWTException, InterruptedException {
					
					//Login_Page lp = new Login_Page();
					  
					 //lp.userLogin();
					  
					Thread.sleep(7000);
				
					PlanningPage pp = new PlanningPage(StaffpointDriver);	
					 
					 Thread.sleep(3000);
					 pp.clickPlanning(); 
				  
					 System.out.println("check1");
					 
					 System.out.println("check2");
					 Thread.sleep(2000);
					
					//String Data_Operations_Vp = "COMBS DARLA [1487783]";
					
						//pp.selectOperationVp(Data_Operations_Vp);
						
						Thread.sleep(3000);
						
						String Data_Start_Date = "6";
						
						String Data_ParentClient = "2020 Exchange [12052]";
						
						String Data_Client = "2020 Exchange - L&L - Australia [R823]";
						
						String Data_program = "2020 Exchange - L&L - Australia [R823]";
						
						String Data_project = "2020 Exchange - L&L - Australia [R823]";
						
						String Data_region = "Europe [EUR]";
						
						String Data_Country = "Bulgaria [BG]";
						
						String Data_Site = "Plovdiv, Bulgaria [347]";
						
						String Data_EndDate = "15";
						
						String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
								
						String Site_Valid	= "Plovdiv, Bulgaria";
						
						pp.selectStartDate(Data_Start_Date);
						
						Thread.sleep(3000);
						
						pp.selectEndDate(Data_EndDate);
						
						Thread.sleep(3000);
						
						pp.selectParentClient(Data_ParentClient);
						
						Thread.sleep(4000);
						
						pp.selectClient(Data_Client);
						
						Thread.sleep(4000);
						
						pp.selectProgram(Data_program);
						
						Thread.sleep(4000);
						
						pp.selectProject(Data_project);
						
						Thread.sleep(4000);
						
						pp.selectRegion(Data_region);
						
						Thread.sleep(4000);
						
						pp.selectCountry(Data_Country);
						
						Thread.sleep(4000);

						pp.selectSite(Data_Site);
						
						Thread.sleep(4000);
					
						pp.submitPlan();
						
						Thread.sleep(3000);
						
						PlanNextPage pnp = new PlanNextPage(StaffpointDriver);
						
						Thread.sleep(2000);
						
						pnp.SummaryUserGuide();
						
					
						pnp.clickBreakdown();
						
						Thread.sleep(1000);

						pnp.BreakdownUserGuide();
						
						pnp.saveProfile("Maradona");
						
						}
						
					
				@Test(priority=5)
			  public void viewPlanProfile() throws AWTException, InterruptedException {
					
					
					//Login_Page lp = new Login_Page();
					  
					 //lp.userLogin();
					  
					Thread.sleep(7000);
				
					PlanningPage pp = new PlanningPage(StaffpointDriver);	
					 
					 Thread.sleep(3000);
											
						 pp.clickPlanning(); 
						 
						  Thread.sleep(2000);
						 
							String Data_Start_Date = "6";
							
							String Data_ParentClient = "2020 Exchange [12052]";
							
							String Data_Client = "2020 Exchange - L&L - Australia [R823]";
							
							String Data_program = "2020 Exchange - L&L - Australia [R823]";
							
							String Data_project = "2020 Exchange - L&L - Australia [R823]";
							
							String Data_region = "Europe [EUR]";
							
							String Data_Country = "Bulgaria [BG]";
							
							String Data_Site = "Plovdiv, Bulgaria [347]";
							
							String Data_EndDate = "15";
							
							String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
									
							String Site_Valid	= "Plovdiv, Bulgaria";
						 
						 pp.selectStartDate(Data_Start_Date);
							
							Thread.sleep(3000);
							
							pp.selectEndDate(Data_EndDate);
							
							Thread.sleep(3000);
							
							pp.selectParentClient(Data_ParentClient);
							
							Thread.sleep(4000);
							
							pp.selectClient(Data_Client);
							
							Thread.sleep(4000);
							
							pp.selectProgram(Data_program);
							
							Thread.sleep(4000);
							
							pp.selectProject(Data_project);
							
							Thread.sleep(4000);
							
							pp.selectRegion(Data_region);
							
							Thread.sleep(4000);
							
							pp.selectCountry(Data_Country);
							
							Thread.sleep(4000);

							pp.selectSite(Data_Site);
			 						
							pp.searchScenarios();
							
							Thread.sleep(5000);
							
							pp.viewSimulationPlanning("Maradona");
					
						 }	

	
	@Test(priority=6)
	  public void deletePlanProfile() throws AWTException, InterruptedException {
		
		
		//Login_Page lp = new Login_Page();
		  
		 //lp.userLogin();
		  
		Thread.sleep(7000);
	
		PlanningPage pp = new PlanningPage(StaffpointDriver);	
		 
		 Thread.sleep(3000);
								
			 pp.clickPlanning();
			 
			 Thread.sleep(2000);
			 
				String Data_Start_Date = "6";
				
				String Data_ParentClient = "2020 Exchange [12052]";
				
				String Data_Client = "2020 Exchange - L&L - Australia [R823]";
				
				String Data_program = "2020 Exchange - L&L - Australia [R823]";
				
				String Data_project = "2020 Exchange - L&L - Australia [R823]";
				
				String Data_region = "Europe [EUR]";
				
				String Data_Country = "Bulgaria [BG]";
				
				String Data_Site = "Plovdiv, Bulgaria [347]";
				
				String Data_EndDate = "15";
				
				String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
						
				String Site_Valid	= "Plovdiv, Bulgaria";
			 
			 pp.selectStartDate(Data_Start_Date);
				
				Thread.sleep(3000);
				
				pp.selectEndDate(Data_EndDate);
				
				Thread.sleep(3000);
				
				pp.selectParentClient(Data_ParentClient);
				
				Thread.sleep(4000);
				
				pp.selectClient(Data_Client);
				
				Thread.sleep(4000);
				
				pp.selectProgram(Data_program);
				
				Thread.sleep(4000);
				
				pp.selectProject(Data_project);
				
				Thread.sleep(4000);
				
				pp.selectRegion(Data_region);
				
				Thread.sleep(4000);
				
				pp.selectCountry(Data_Country);
				
				Thread.sleep(4000);

				pp.selectSite(Data_Site);
 						
				pp.searchScenarios();
				
				Thread.sleep(5000);
				
				pp.deleteSimulationPlanning("Maradona");
				
			Thread.sleep(2000);
				
			WebElement Verify_delete = StaffpointDriver.findElement(By.xpath("//label[@id='dialogConfirmText']"));	
		
			
			Assert.assertEquals(Verify_delete.getText(),"Are you sure you want to delete this simulation?");
		
			
	}
	@Test(priority=7)
	 public void sortingfavGrid() throws AWTException, InterruptedException {
			

			//Login_Page lp = new Login_Page();
			  
			 //lp.userLogin();
			  
			Thread.sleep(7000);
		
			PlanningPage pp = new PlanningPage(StaffpointDriver);	
			 
			 Thread.sleep(3000);
									
				 pp.clickPlanning();
				 
				 Thread.sleep(2000);
				 
				 pp.viewFavPlanning();
				 
				 Thread.sleep(4000);
	
				 WebElement fav_description = StaffpointDriver.findElement(By.xpath("//th[@id='favoriteGrid_Description']"));
				 
				 fav_description.click();
				 
				 Thread.sleep(3000);
				 
				 WebElement fav_ParentClient = StaffpointDriver.findElement(By.xpath("//th[@id='favoriteGrid_ParentClient']"));
				 
				 fav_ParentClient.click();
				 
				 Thread.sleep(3000);
				 
				 WebElement Close_favorite = StaffpointDriver.findElement(By.xpath("//div[@class='ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix']/a/span[@class='ui-icon ui-icon-closethick']"));
				 
				 Close_favorite.click();
				 
				pp.searchScenarios();
				
				Thread.sleep(5000);
				
				pp.sortingSimulation1();
				
	}
	
	@Test(priority=8)
	 public void verifyPagination() throws AWTException, InterruptedException {
		
		//Login_Page lp = new Login_Page();
		  
		 //lp.userLogin();
		  
		Thread.sleep(7000);
	
		PlanningPage pp = new PlanningPage(StaffpointDriver);	
		 
		 Thread.sleep(3000);
								
			 pp.clickPlanning();
			 
			 Thread.sleep(2000);
			 
			 pp.viewFavPlanning();
			 
			 Thread.sleep(4000);
			 
			 pp.selectfavoriteRoWCount("20");;
			 
			 Thread.sleep(3000);
			 
			 pp.selectfavoriteRoWCount("50");
			 
			 Thread.sleep(3000);
			 
			 pp.selectfavoriteRoWCount("100");
			 
			 Thread.sleep(3000);
			 
			 WebElement Close_favorite = StaffpointDriver.findElement(By.xpath("//div[@class='ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix']/a/span[@class='ui-icon ui-icon-closethick']"));
			 
			 Close_favorite.click();
			 
			 pp.searchScenarios();
				
			 Thread.sleep(5000);
			 
			JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
				
			js.executeScript("window.scrollBy(0,500)"); 
			 
			pp.selectSimulationRoWCount("20");
			 
			 Thread.sleep(2000);
			 
			pp.selectSimulationRoWCount("50");
			 
			 Thread.sleep(2000);
			 
			pp.selectSimulationRoWCount("100");
			 		 		 
	
	}	*/
	

}