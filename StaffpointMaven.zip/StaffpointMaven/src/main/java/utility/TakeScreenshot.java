package utility;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class TakeScreenshot {

	public static void screenShot(WebDriver driver , String filepath) throws IOException, InterruptedException
	{
		String file_screenshot = filepath;

		TakesScreenshot ts = (TakesScreenshot)driver;



		File scr= ts.getScreenshotAs(OutputType.FILE);

		File dest= new File("file_screenshot"+timestamp()+".png");
		FileUtils.copyFile(scr, dest);
	}


	public static String timestamp() {
		return new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date(0));
									
	}
}

