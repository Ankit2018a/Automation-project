package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Repositories {

	public  static String getChromeProperty() throws IOException{
		File ObjRepo=new File("./Configuration/Object_Repo.properties");
		FileInputStream ObjRepo_Input =new FileInputStream(ObjRepo);
		Properties pro=new Properties();
		pro.load(ObjRepo_Input);
		String Chromeclass = pro.getProperty("ChromeProperty");
		
		return Chromeclass;
	
	}

	public  static String getChromePath() throws IOException{
		File ObjRepo=new File("./Configuration/Object_Repo.properties");
		FileInputStream ObjRepo_Input =new FileInputStream(ObjRepo);
		Properties pro=new Properties();
		pro.load(ObjRepo_Input);
		String Chromepath = pro.getProperty("ChromeDriverPath");
		
		return Chromepath;
	
	}
	
	
	public  static String getURL() throws IOException{
		File ObjRepo=new File("./Configuration/Object_Repo.properties");
		FileInputStream ObjRepo_Input =new FileInputStream(ObjRepo);
		Properties pro=new Properties();
		pro.load(ObjRepo_Input);
		String Staff_URL = pro.getProperty("StaffpointURL");
		
		return Staff_URL;
	
	}
	
	
	public  static String getScreenshotPath() throws IOException{
		File ObjRepo=new File("./Configuration/Object_Repo.properties");
		FileInputStream ObjRepo_Input =new FileInputStream(ObjRepo);
		Properties pro=new Properties();
		pro.load(ObjRepo_Input);
		String Screenshot_Path = pro.getProperty("ScreenshotPath");
		
		return Screenshot_Path;
	
	}
	
	
	public  static String getExcelPath() throws IOException{
		File ObjRepo=new File("./Configuration/Object_Repo.properties");
		FileInputStream ObjRepo_Input =new FileInputStream(ObjRepo);
		Properties pro=new Properties();
		pro.load(ObjRepo_Input);
		String Exl_Path = pro.getProperty("ExcelPath");
		
		return Exl_Path;
	
	}
	
	
	public  static String getJDBCclassPath() throws IOException{
		File ObjRepo=new File("./Configuration/Object_Repo.properties");
		FileInputStream ObjRepo_Input =new FileInputStream(ObjRepo);
		Properties pro=new Properties();
		pro.load(ObjRepo_Input);
		String JDBC_ClassPath = pro.getProperty("JDBCclassPath");
		
		return JDBC_ClassPath;
	
	}
	
	public  static String getJDBCUserName() throws IOException{
		File ObjRepo=new File("./Configuration/Object_Repo.properties");
		FileInputStream ObjRepo_Input =new FileInputStream(ObjRepo);
		Properties pro=new Properties();
		pro.load(ObjRepo_Input);
		String JDBCUserName_Path = pro.getProperty("JDBCUserName");
		
		return JDBCUserName_Path;
	
	}
	
	public  static String getJDBCPassword() throws IOException{
		File ObjRepo=new File("./Configuration/Object_Repo.properties");
		FileInputStream ObjRepo_Input =new FileInputStream(ObjRepo);
		Properties pro=new Properties();
		pro.load(ObjRepo_Input);
		String JDBCPassword_Path = pro.getProperty("JDBCPassword");
		
		return JDBCPassword_Path;
	
	}
	
	
}
