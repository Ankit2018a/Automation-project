package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;







public class ExcellData {
	

		public static  String[][] ExcelData(String FilePath , int sheet_index) throws IOException{

			System.out.println("Check1");

			ArrayList<String> Arraycell = new ArrayList();

			File Dt = new File(FilePath);

			FileInputStream Excel_File = new FileInputStream(Dt);
			System.out.println("Check2");
			XSSFWorkbook ExcelWBook = new XSSFWorkbook(Excel_File);
			System.out.println("Check3");
			XSSFSheet ExcelWSheet =  ExcelWBook.getSheetAt(sheet_index);

			int Rowcount = ExcelWSheet.getLastRowNum();
			int columnCount = ExcelWSheet.getRow(0).getLastCellNum();
			
			System.out.println(Rowcount+" "+columnCount);
			String[][] datasets = new String[Rowcount+1][columnCount];
			
			Iterator<Row> rowIterator = ExcelWSheet.iterator();
			
			

			int i = 0;
			int t = 0;
			
			while (rowIterator.hasNext())
			{ int k =t;
			    t++;
				Row row = rowIterator.next();
				// ArrayList<String> Arrayrow = new ArrayList();
				//Row.getStringRowValue();

				//For each row iterate through each columns
				Iterator <Cell> cellIterator = row.cellIterator();
				int j = 0; 
				while (cellIterator.hasNext())
				{

					Cell cell = cellIterator.next();
					//    ArrayList<String> Arraycell = new ArrayList();

					switch(cell.getCellType()) {
					case XSSFCell.CELL_TYPE_BOOLEAN:
						String str = cell.getBooleanCellValue()+"";
						datasets[k][j++] = str;
						System.out.println(k+" "+j+" "+str);
						break;
					case XSSFCell.CELL_TYPE_NUMERIC:
						String str1 =  NumberToTextConverter.toText(cell.getNumericCellValue());
						Arraycell.add(str1);
						datasets[k][j++] = str1;
						System.out.println(k+" "+j+" "+str1);
						//information = information + " " +headerValue+" - "+cellValue+ "; ";
						break;
					case XSSFCell.CELL_TYPE_STRING:
						String str2 = cell.getStringCellValue();
						Arraycell.add(str2);
						datasets[k][j++] = str2;
						//information = information + " " +headerValue+" - "+cellValue+ "; ";
						System.out.println(k+" "+j+" "+str2);
						break;
					case XSSFCell.CELL_TYPE_BLANK:
						break;
					}


				}


			}
			Excel_File.close();
			return datasets;
			//return Arraycell;

		}
		
	
			
		} 
		



