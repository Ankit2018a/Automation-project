package utility;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StaffpointDB {

	
	
	public static void dbVerification( String Sqlquery) throws ClassNotFoundException, SQLException{
	
	
	java.sql.Connection con=null;
    java.sql.Statement st = null;
    ResultSet rs = null;
	
    
	try{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	
	con= DriverManager.getConnection("jdbc:oracle:thin:@fugit:1521/tteasc01.teletech.com","ORCERT","ORCERT");
	
	System.out.println("Connected to oracle 11g");
	
	
	 st = con.createStatement();
	
	rs = ((java.sql.Statement) st).executeQuery(Sqlquery);
	
	
	while(rs.next()){ 
	String EE_number = rs.getString("ee_number");
	System.out.println("Employee number is "+ EE_number);
	};
	}
	catch(Exception e){
	e.printStackTrace();
	}
	}
}
	
	

