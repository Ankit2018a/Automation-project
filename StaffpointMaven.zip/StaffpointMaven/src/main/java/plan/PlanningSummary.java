package plan;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;

public class PlanningSummary extends PlanNextPage {

	public PlanningSummary(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, PlanNextPage.class);

		PageFactory.initElements(driver, this);
	
	}

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_0']")
	public List<WebElement> Summary_Week_Of;

	
	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_1']")
	public List<WebElement> Summary_FTE;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_2']")
	public List<WebElement> Summary_Volume;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_3']")
	public List<WebElement> Summary_Hours;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_4']")
	public List<WebElement> Summary_Seat_Sharing_Ratio;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_5']")
	public List<WebElement> Phone_Occupancy ;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_6']")
	public List<WebElement> Summary_AHT;

	@FindBy(how = How.XPATH , 
			using = "//tr[@id='metricGridghead_0_7']")
	public List<WebElement> Summary_Shrinkage;


	
	
}
