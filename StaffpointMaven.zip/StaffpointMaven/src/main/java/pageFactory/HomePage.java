package pageFactory;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;

public class HomePage extends TabularBarPage {

	//WebDriver driver; 

	private static final String WebElement = null;


	public HomePage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, this);
	}

	/*List of Elements in MY Favorites*/ 

	//Delete and View functionality

	@FindBy(how = How.XPATH , 
			using = "//input[@class='open-scenario'][@title='View Favorite']")
	public WebElement Favorites_ViewFavorites;

	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/Home/Delete/120']")
	public WebElement Favorites_Delete;

	//Line of Business views

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_OperationsVP']")
	public List<WebElement> Favorites_Operations_VP;


	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_ParentClient']")
	public List<WebElement> Favorites_ParentClient;	

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Client']")
	public List<WebElement> Favorites_Client;

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Program']")
	public List<WebElement> Favorites_Program;

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Project']")
	public List<WebElement> Favorites_Project;

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Region']")
	public List<WebElement> Favorites_Region;

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Country']")
	public List<WebElement> Favorites_Country;

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Site']")
	public List<WebElement> Favorites_Site;


	//LIST OF ELEMENTS IN FAVORITE GRID

	@FindBy(how = How.XPATH , 
			using = "//table[@id='favoriteGrid']/tbody/tr")
	public List<WebElement> Favorites_Grid;


	/*List of Elements in My Simulation Snapshots*/


	@FindBy(how = How.XPATH , 
			using = "//input[@class='open-scenario'][@title='View Simulation']")
	public WebElement Simulation_ViewSimulation;


	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/Home/Delete/13db3c1d-b22d-4892-b75a-6b920629cb58']")
	public WebElement Simulation_DeleteSimulation;

	//Scenario's Name Description and Created date

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='scenarioGrid_Description']")
	public WebElement Simulation_Name;


	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='scenarioGrid_CreatedDate']")
	public WebElement Simulation_CreatedDate;	


	//Line of Business views

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_OperationsVP']")
	public List<WebElement> Simulation_Operations_VP;


	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_ParentClient']")
	public List<WebElement> Simulation_ParentClient;	

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Client']")
	public List<WebElement> Simulation_Client;

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Program']")
	public List<WebElement> Simulation_Program;

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Project']")
	public List<WebElement> Simulation_Project;

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Region']")
	public List<WebElement> Simulation_Region;

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Country']")
	public List<WebElement> Simulation_Country;

	@FindBy(how = How.XPATH , 
			using = "//td[@aria-describedby='favoriteGrid_Site']")
	public List<WebElement> Simulation_Site;
	
	
	//columns List in scenario Grid
	
	@FindBy(how = How.XPATH , 
			using = "//table[@class='ui-jqgrid-htable'][@aria-labelledby='gbox_scenarioGrid']/thead/tr/th")
	public List<WebElement> Simulation_columns;


	/*Element Related to Simulation Grid*/
	
	
	@FindBy(how = How.XPATH , 
			using = "//table[@id='scenarioGrid']/tbody/tr")
	public List<WebElement> Simulation_Grid;

	
	
	
	/*List of Scenarios in Plan Tab*/


//Elements Related to Plan Grid

	@FindBy(how = How.XPATH , 
			using = "//table[@id='complianceGrid']/tbody/tr")
	public List<WebElement> Plan_Grid;


	//methods for view functionality




	//List of Methods in HomePage

	public String getFavoritesOperationsVP(String FavoritesOp_VP){

		String Current_Val = "Null";

		for(WebElement FavoriteOperation : Favorites_Operations_VP){
			if(FavoriteOperation.getText().equalsIgnoreCase(FavoritesOp_VP)){
				Current_Val = FavoritesOp_VP;
				//return Current_Val;
			}
		}
		return Current_Val;
	}


	public String getFavoritesParentClient(String FavoriteP_Client){

		String Current_Val = "";

		for(WebElement FavoriteParentClient : Favorites_ParentClient){
			if(FavoriteParentClient.getText().equalsIgnoreCase(FavoriteP_Client)){
				Current_Val = FavoriteP_Client;
			}
		}
		return Current_Val;

	}

	public String getFavoritesProgram(String Favorite_Program){

		String Current_Val = "";

		for(WebElement FavoriteProgram : Favorites_Program){
			if(FavoriteProgram.getText().equalsIgnoreCase(Favorite_Program)){
				Current_Val = Favorite_Program;
			}
		}
		return Current_Val;

	}

	public String getFavoritesProject(String Favorite_Project){

		String Current_Val = "";

		for(WebElement FavoriteProject : Favorites_Project){
			if(FavoriteProject.getText().equalsIgnoreCase(Favorite_Project)){
				Current_Val = Favorite_Project;
			}


		}
		return Current_Val;

	}
	public String getFavoritesSite(String Favorite_Site){

		String Current_Val = "";

		for(WebElement FavoriteSite : Favorites_Site){
			if(FavoriteSite.getText().equalsIgnoreCase(Favorite_Site)){
				Current_Val = Favorite_Site;
			}
		}
		return Current_Val;

	}
	public String getFavoritesCountry(String Favorite_Country){

		String Current_Val = "";

		for(WebElement FavoriteCountry : Favorites_Country){
			if(FavoriteCountry.getText().equalsIgnoreCase(Favorite_Country)){
				Current_Val = Favorite_Country;
			}
		}
		return Current_Val;
	}

	//methods for delete functionality




	public void deletefavorite(String Project , String Site ) throws InterruptedException{

		System.out.println("Check0");

		for(WebElement TableRow:Favorites_Grid){

			System.out.println("Check1");

			String str2 = TableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='favoriteGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='favoriteGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);


				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}


				System.out.println(ele.getText());

				if(ele.getText().equalsIgnoreCase(Project)){

					System.out.println(TableRow.getAttribute("id"));

					String str = TableRow.getAttribute("id");

					String str3 = "//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='favoriteGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));

					if(ele2.getText().equalsIgnoreCase(Site)){

						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_Action']"
								+ "/a";


						WebElement Ele6 = driver.findElement(By.xpath(str4));

						Ele6.click();

						//ele4.click();

					}
				}

			}		

		}

	}


	//Method to view favorite


	public void viewfavorite(String Project , String Site ) throws InterruptedException{

		System.out.println("Check0");

		outerloop:
		for(WebElement tableRow:Favorites_Grid){

			System.out.println("Check1");

			String str2 = tableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='favoriteGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='favoriteGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);


				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}


				System.out.println(ele.getText());

				if(ele.getText().trim().equalsIgnoreCase(Project)){

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='favoriteGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));

					ele2.getText();
					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){


						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_Action']"
								+ "/input";


						WebElement Ele6 = driver.findElement(By.xpath(str4));

						Ele6.click();

					break outerloop;

					}
				}

			}		

		}


	}


	public ArrayList<String> viewLOBfavorite(String Project , String Site ) throws InterruptedException{

		System.out.println(Project);
		
		System.out.println(Site);
		
		System.out.println("Check0");

		ArrayList<String> al = new ArrayList();

		for(WebElement tableRow:Favorites_Grid){

			System.out.println("Check71");

			String str2 = tableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check72");

				String str1	=	"//table[@id='favoriteGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='favoriteGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);

				System.out.println("Check21");
				
				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}


				System.out.println(ele.getText());
				
				System.out.println("Check211");
				
				if(ele.getText().trim().equalsIgnoreCase(Project)){
					
					System.out.println("Check212");

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='favoriteGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));

					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){


						System.out.println("Check27");

						WebElement Ele_Op_Vp = driver.findElement(By.xpath("//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_OperationsVP']"));

						al.add(Ele_Op_Vp.getAttribute("title").trim());


						WebElement Ele_ParentClient = driver.findElement(By.xpath("//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_ParentClient']"));

						al.add(Ele_ParentClient.getAttribute("title").trim());

						WebElement Ele_Client = driver.findElement(By.xpath("//table[@id='favoriteGrid']/tbody/tr[@id='"+str+

								"']/td[@aria-describedby='favoriteGrid_Client']"));

						al.add(Ele_Client.getAttribute("title").trim());


						WebElement Ele_program = driver.findElement(By.xpath("//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_Program']"));

						al.add(Ele_program.getAttribute("title").trim());

						WebElement Ele_project = driver.findElement(By.xpath("//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_Project']"));

						al.add(Ele_project.getAttribute("title").trim());

						WebElement Ele_Region = driver.findElement(By.xpath("//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_Region']"));

						al.add(Ele_Region.getAttribute("title").trim());

						WebElement Ele_Country = driver.findElement(By.xpath("//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_Country']"));

						al.add(Ele_Country.getAttribute("title").trim());

						WebElement Ele_site = driver.findElement(By.xpath("//table[@id='favoriteGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='favoriteGrid_Site']"));

						al.add(Ele_site.getAttribute("title").trim());



					}
				}

			}		

		}

		return al;	

	}

			//Method Related to Simulation_columns
	
	public ArrayList<String> scenarioColumns(){
		
		ArrayList<String> Simu_Colms = new ArrayList();
		
		for(WebElement ScenarioColumn : Simulation_columns ){
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView(true);", ScenarioColumn);
			
			System.out.println(ScenarioColumn.getText());
			
			Simu_Colms.add(ScenarioColumn.getText().trim());
			
		}
		
		return Simu_Colms;
	}
	
	
		//Method Related to Delete Simulations
	


	public void deleteSimulation(String Project , String Site ) throws InterruptedException{

		System.out.println("Check0");

		for(WebElement TableRow:Simulation_Grid){

			System.out.println("Check1");

			String str2 = TableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='scenarioGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='scenarioGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);


				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}


				System.out.println(ele.getText());

				if(ele.getText().equalsIgnoreCase(Project)){

					System.out.println(TableRow.getAttribute("id"));

					String str = TableRow.getAttribute("id");

					String str3 = "//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='scenarioGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));

					if(ele2.getText().equalsIgnoreCase(Site)){

						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='scenarioGrid_Action']"
								+ "/a";


						WebElement Ele6 = driver.findElement(By.xpath(str4));

						
						
						Ele6.click();

						//ele4.click();

					}
				}

			}		

		}

	}
	
	
	
	//Method to view Simulation
	

	public void viewSimulation(String Project , String Site ) throws InterruptedException{

		System.out.println("Check0");

		for(WebElement tableRow:Simulation_Grid){

			System.out.println("Check1");

			String str2 = tableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='scenarioGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='scenarioGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);

				

				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].scrollIntoView(true);", ele);
				
				System.out.println(ele.getText());

				if(ele.getText().trim().equalsIgnoreCase(Project)){

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='scenarioGrid']/tbody/tr[@id='"+str2+
							"']/td[@aria-describedby='scenarioGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));
					
					js = (JavascriptExecutor) driver;
					js.executeScript("arguments[0].scrollIntoView(true);", ele2);

					ele2.getText();
					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){


						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='scenarioGrid_Action']"
								+ "/input";


						WebElement Ele6 = driver.findElement(By.xpath(str4));
						
						js = (JavascriptExecutor) driver;
						js.executeScript("arguments[0].scrollIntoView(true);", Ele6);

						Ele6.click();
						break;


					}
				}

			}		

		}


	}

	

	public ArrayList<String> viewLOBSimulation(String Project , String Site ) throws InterruptedException{

		System.out.println(Project);
		
		System.out.println(Site);
		
		System.out.println("Check0");

		ArrayList<String> Lob = new ArrayList();

		for(WebElement tableRow:Simulation_Grid){

			System.out.println("Check71");

			String str2 = tableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check72");

				String str1	=	"//table[@id='scenarioGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='scenarioGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);

				System.out.println("Check21");
				
				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

				

				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].scrollIntoView(true);", ele);
				
				
				System.out.println(ele.getText());
				
				System.out.println("Check211");
				
				if(ele.getText().trim().equalsIgnoreCase(Project)){
					
					System.out.println("Check212");

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='scenarioGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));

					
					js = (JavascriptExecutor) driver;
					js.executeScript("arguments[0].scrollIntoView(true);", ele2);
					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){

					
						
						WebElement Ele_Name = driver.findElement(By.xpath("//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='scenarioGrid_Description']"));


						 js = (JavascriptExecutor) driver;
						js.executeScript("arguments[0].scrollIntoView(true);", Ele_Name);
						
						
					String Name = Ele_Name.getAttribute("title").trim();
					
						Lob.add(Name);
					
					WebElement Ele_CreatedDate = driver.findElement(By.xpath("//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='scenarioGrid_CreatedDate']"));

				String CreatedDate = Ele_CreatedDate.getAttribute("title").trim();
				
						Lob.add(CreatedDate);
				
				WebElement Ele_CreatedBy = driver.findElement(By.xpath("//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
						"']/td[@aria-describedby='scenarioGrid_CreatedBy']"));

						String CreatedBy = Ele_Name.getAttribute("title").trim();
						
						Lob.add(CreatedBy);	
			
						System.out.println("Check27");

						WebElement Ele_Op_Vp = driver.findElement(By.xpath("//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='scenarioGrid_OperationsVP']"));

					String	Op_Vp = Ele_Op_Vp.getAttribute("title").trim();
						
						Lob.add(Op_Vp);

						WebElement Ele_ParentClient = driver.findElement(By.xpath("//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='scenarioGrid_ParentClient']"));

						String	ParentClient = Ele_ParentClient.getAttribute("title").trim();

						Lob.add(ParentClient);
						
						WebElement Ele_Client = driver.findElement(By.xpath("//table[@id='scenarioGrid']/tbody/tr[@id='"+str+

								"']/td[@aria-describedby='scenarioGrid_Client']"));

						 js = (JavascriptExecutor) driver;
							js.executeScript("arguments[0].scrollIntoView(true);", Ele_Client);
						
						
						String	Client = Ele_Client.getAttribute("title").trim();

						Lob.add(Client);
						
						WebElement Ele_program = driver.findElement(By.xpath("//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='scenarioGrid_Program']"));

						String program = Ele_program.getAttribute("title").trim();
						
						Lob.add(program);
						
						WebElement Ele_project = driver.findElement(By.xpath("//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='scenarioGrid_Project']"));

						js = (JavascriptExecutor) driver;
						js.executeScript("arguments[0].scrollIntoView(true);", Ele_project);
						
						String project = Ele_project.getAttribute("title").trim();

						Lob.add(project);
						
					
						WebElement Ele_Country = driver.findElement(By.xpath("//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='scenarioGrid_Country']"));
						
						js = (JavascriptExecutor) driver;
						js.executeScript("arguments[0].scrollIntoView(true);", Ele_Country);
						
						
						String Country = Ele_Country.getAttribute("title").trim();

						Lob.add(Country);
						
						WebElement Ele_site = driver.findElement(By.xpath("//table[@id='scenarioGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='scenarioGrid_Site']"));

						js = (JavascriptExecutor) driver;
						js.executeScript("arguments[0].scrollIntoView(true);", Ele_site);
						
						String site = Ele_site.getAttribute("title").trim();

						Lob.add(site);


					}
				}

			}		

		}

		return Lob;	

	}
	
	
	//method related to view Plan
	
	public void viewPlan(String Project , String Site ) throws InterruptedException{

		System.out.println("Check0");

		for(WebElement tableRow:Plan_Grid){

			System.out.println("Check1");

			String str2 = tableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='complianceGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='complianceGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);

				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

		
				System.out.println(ele.getText());

				if(ele.getText().trim().equalsIgnoreCase(Project)){

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='complianceGrid']/tbody/tr[@id='"+str2+
							"']/td[@aria-describedby='complianceGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));
				

					ele2.getText();
					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){


						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='complianceGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='complianceGrid_Action']"
								+ "/input";


						WebElement Ele6 = driver.findElement(By.xpath(str4));
						

						Ele6.click();
						break;


					}
				}

			}		

		}


	}
	
	//Method to get Plan LOB
	
	public ArrayList<String> viewLOBPlan(String Project , String Site ) throws InterruptedException{

		System.out.println(Project);
		
		System.out.println(Site);
		
		System.out.println("Check0");

		ArrayList<String> Lob = new ArrayList();

		for(WebElement tableRow:Plan_Grid){

			System.out.println("Check71");

			String str2 = tableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check72");

				String str1	=	"//table[@id='complianceGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='complianceGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);

				System.out.println("Check21");
				
				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

		
				System.out.println(ele.getText());
				
				System.out.println("Check211");
				
				if(ele.getText().trim().equalsIgnoreCase(Project)){
					
					System.out.println("Check212");

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='complianceGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='complianceGrid_Site']";

				WebElement ele2 =	driver.findElement(By.xpath(str3));

					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){

					
				WebElement Ele_Parent_Client = driver.findElement(By.xpath("//table[@id='complianceGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='complianceGrid_ParentClient']"));

						
						String Parent_Client = Ele_Parent_Client.getAttribute("title").trim();
					
						Lob.add(Parent_Client);
					
				WebElement Ele_project = driver.findElement(By.xpath("//table[@id='complianceGrid']/tbody/tr[@id='"+str+
							"']/td[@aria-describedby='complianceGrid_Project']"));

				String project = Ele_project.getAttribute("title").trim();
				
						Lob.add(project);
				
				WebElement Ele_Site = driver.findElement(By.xpath("//table[@id='complianceGrid']/tbody/tr[@id='"+str+
						"']/td[@aria-describedby='complianceGrid_Site']"));

						String site = Ele_Site.getAttribute("title").trim();
						
						Lob.add(site);	
			

				WebElement Ele_Modification_Date = driver.findElement(By.xpath("//table[@id='complianceGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='complianceGrid_LastModificationDate']"));

					String	Modification_Date = Ele_Modification_Date.getAttribute("title").trim();
						
						Lob.add(Modification_Date);

						WebElement Ele_Compliances = driver.findElement(By.xpath("//table[@id='complianceGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='complianceGrid_Compliances']"));

						String	Compliances = Ele_Compliances.getAttribute("title").trim();

						Lob.add(Compliances);
						
			


					}
				}

			}		

		}

		return Lob;	

	}
	
	
	//Method Related to get Plan modification date
	
	
	public String viewPlanModificationDate(String Project , String Site ) throws InterruptedException{

		System.out.println("Check0");
		
		String Modification_date = null;

		for(WebElement tableRow:Plan_Grid){

			System.out.println("Check1");

			String str2 = tableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='complianceGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='complianceGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);

				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

		
				System.out.println(ele.getText());

				if(ele.getText().trim().equalsIgnoreCase(Project)){

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='complianceGrid']/tbody/tr[@id='"+str2+
							"']/td[@aria-describedby='complianceGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));
				

					ele2.getText();
					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){


						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='complianceGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='complianceGrid_LastModificationDate']";


						WebElement Ele6 = driver.findElement(By.xpath(str4));
						
					 Modification_date = Ele6.getText(); 
						
						break;


					}
				}

			}		

		}

		return	Modification_date;
	}

	public String viewPlanComplaince(String Project , String Site ) throws InterruptedException{

		System.out.println("Check0");
		
		String Plan_Complaince = null;

		for(WebElement tableRow:Plan_Grid){

			System.out.println("Check1");

			String str2 = tableRow.getAttribute("id");

			System.out.println(str2);

			if(str2.isEmpty()){ System.out.println(" String is Empty");
			}

			else{

				System.out.println("Check2");

				String str1	=	"//table[@id='complianceGrid']/tbody/tr[@id='"+str2+
						"']/td[@aria-describedby='complianceGrid_Project']";

				System.out.println(str1);

				Thread.sleep(1000);

				WebElement ele = null;
				try{
					ele = driver.findElement(By.xpath(str1));
				}

				catch(Exception e){
					System.out.println(e.getMessage());
				}

		
				System.out.println(ele.getText());

				if(ele.getText().trim().equalsIgnoreCase(Project)){

					System.out.println(tableRow.getAttribute("id"));

					String str = tableRow.getAttribute("id");

					String str3 = "//table[@id='complianceGrid']/tbody/tr[@id='"+str2+
							"']/td[@aria-describedby='complianceGrid_Site']";

					WebElement ele2 =	driver.findElement(By.xpath(str3));
				

					ele2.getText();
					
					if(ele2.getText().trim().equalsIgnoreCase(Site)){


						System.out.println(ele2.getText());
						System.out.println(ele.getText());

						String str4 = "//table[@id='complianceGrid']/tbody/tr[@id='"+str+
								"']/td[@aria-describedby='complianceGrid_Compliances']";


						WebElement Ele6 = driver.findElement(By.xpath(str4));
						
					 Plan_Complaince = Ele6.getText().trim(); 
						
						break;
					}
				}

			}		

		}

		return	Plan_Complaince;
	}


	
	public String validationPlanComplaince(int DiffinDays){
		
		String Compl_Validn = null;
		
		if(DiffinDays>10){
			
			Compl_Validn="Non-Compliant";
			
			return Compl_Validn;
		}
		
		else if((DiffinDays<=10)&&(DiffinDays>7)){
			
			Compl_Validn="Compliant";
			
			return Compl_Validn;
		}
		
		else{
			Compl_Validn="Compliant";
			
			return Compl_Validn;
			
		}
		
	}
}







