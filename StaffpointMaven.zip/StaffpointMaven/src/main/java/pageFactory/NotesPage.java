package pageFactory;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;

public class NotesPage extends TabularBarPage {

	public NotesPage(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
		
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, this);
	}

	
	//Line of business

	/*Elements Related to Plan Start date*/

	@FindBy(how = How.XPATH , 
		using = "//input[@name='StartDate']")
	public WebElement Notes_StartDate;


	/*Elements Related to Plan End date*/

	@FindBy(how = How.XPATH , 
		using = "//table[@class='ui-datepicker-calendar']/tbody/tr/td/a")
	public List<WebElement> Notes_StartDate_List;
	


	//Element to select Next month
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Next']")
	public WebElement Notes_StartDate_Next;
	
	//Element to select Prev month
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Prev']")
	public WebElement Plan_EndDate_Prev;

	
		/*Elements Related to Plan End date*/
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='ExceptionEndDate']")
	public WebElement Notes_EndDate;

	@FindBy(how = How.XPATH , 
			using = "//table[@class='ui-datepicker-calendar']/tbody/tr/td/a")
	public WebElement Notes_EndDate_List;
	
	
	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='ParentClientIds_chosen']")
	public WebElement Parent_client_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ParentClientIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Parent_client_List;

	//Elements related to Client_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='ClientIds_chosen']")
	public WebElement Client_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ClientIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Client_List;

	//Elements related to Program_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='ProgramIds_chosen']")
	public WebElement Program_Id_Select;



	@FindBy(how = How.XPATH , 
			using = "//div[@id='ProgramIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Program_Id_List;

	//Elements related to Project_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='ProjectIds_chosen']")
	public WebElement Project_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ProjectIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Project_Id_List;

	//Elements related to Region

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='RegionIds_chosen']")
	public WebElement Region_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='RegionIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Region_Id_List;

	//Elements Related to country

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='CountryIds_chosen']")
	public WebElement Country_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='CountryIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Country_Id_List;

	//Elements Related to Site

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-multi'][@id='SiteIds_chosen']")
	public WebElement Site_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='SiteIds_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result group-option')]")
	public List<WebElement> Site_Id_List;

	//Elements related to fiscal week
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='FiscalWeek']")
	public WebElement Fiscal_Week;

	@FindBy(how = How.XPATH , 
			using = "//table[@class='ui-datepicker-calendar']/tbody/tr/td/a[@href='#']")
	public List<WebElement> Fiscal_Week_List;
	
	
	@FindBy(how = How.XPATH , 
			using = "//input[@type='button'][@value='Create Note']")
	public WebElement Create_Note_Button;


	@FindBy(how = How.XPATH , 
			using = "//input[@type='submit'][@value='Search Notes']")
	public WebElement Search_Notes_Button;	
	
	//add notes
	

	
//"//input[@type='submit'][@value='Save']"
	
	@FindBy(how = How.XPATH , 
			using = "//input[@type='submit'][@value='Save']")
	public WebElement Exclusion_Save;
	
	
	public void selectStartDate(String Data_StartDate) throws InterruptedException{

		
		Notes_StartDate.click();

		Thread.sleep(2000);

		for(WebElement StartDate:Notes_StartDate_List ){
			
			if(StartDate.getText().equalsIgnoreCase(Data_StartDate)){
				
				StartDate.click();
				
				break;
			}
		}


	}
	
	//Method related to plan End Date
	
	public void selectEndDate(String Data_EndDate) throws InterruptedException{

		
		Notes_EndDate.click();

		Thread.sleep(2000);

		for(WebElement StartDate:Notes_StartDate_List ){

			
			if(StartDate.getText().equalsIgnoreCase(Data_EndDate)){

				
				StartDate.click();
				
				break;
			}
		}


	}
	
	
	


	//Method related to Parent Client

	public void selectParentClient(String Data_ParentClient) throws InterruptedException{

		Parent_client_Select.click();

		Thread.sleep(1000);

		for(WebElement ParentClient:Parent_client_List ){

			if(ParentClient.getText().equalsIgnoreCase(Data_ParentClient)){

				ParentClient.click();
				
				break;
			}
		}
	}

	//Method related to client

	public void selectClient(String Data_Client) throws InterruptedException{

		//Actions act = new Actions(driver);
		
		//act.moveToElement(Client_Select).click().build().perform();
		
		Client_Select.click();

		Thread.sleep(1000);

		for(WebElement Client:Client_List){

			if(Client.getText().equalsIgnoreCase(Data_Client)){

				Client.click();
				
				break;
			}
		}
	}

	//Method Related to Program

	public void selectProgram(String Data_Program_Id) throws InterruptedException{

		Program_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Program_Id:Program_Id_List ){

			if(Program_Id.getText().equalsIgnoreCase(Data_Program_Id)){

				Program_Id.click();
				
				break;
			}
		}
	}

	//Method related to Project

	public void selectProject(String Data_Project_Id) throws InterruptedException{

		Project_Id_Select.click();


		Thread.sleep(2000);
		for(WebElement Project_Id:Project_Id_List ){

			if(Project_Id.getText().equalsIgnoreCase(Data_Project_Id)){

				Project_Id.click();
				
				break;
			}
		}
	}

	//Method related to Region

	public void selectRegion(String Data_Region) throws InterruptedException{

		Region_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Region:Region_Id_List ){

			if(Region.getText().equalsIgnoreCase(Data_Region)){

				Region.click();
				
				break;
			}
		}
	}

	//Method Related to country

	public void selectCountry(String Data_Country) throws InterruptedException{

		Country_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Country:Country_Id_List ){

			if(Country.getText().equalsIgnoreCase(Data_Country)){

				Country.click();
				
				break;
			}
		}
	}

	//Method related to site

	public void selectSite(String Data_Site) throws InterruptedException{

		Site_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Site:Site_Id_List ){

			if(Site.getText().equalsIgnoreCase(Data_Site)){

				Site.click();
				
				break;
			}
		}
	
	}
	
	
		 
		

		public void createNote(){
			Create_Note_Button.click();
		}
		
		public void searchNote(){
			
			Search_Notes_Button.click();
		}
		
		
}
