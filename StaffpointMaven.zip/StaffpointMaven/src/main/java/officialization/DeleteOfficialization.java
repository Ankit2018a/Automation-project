package officialization;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;
import pageFactory.OfficializePlan;

public class DeleteOfficialization extends OfficializePlan {

	public DeleteOfficialization(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, OfficializePlan.class);
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='StartDate2']")
	public WebElement Plan_StartDate;

	
	/*Elements Related to Plan End date*/
	
	@FindBy(how = How.XPATH , 
			using = "//table[@class='ui-datepicker-calendar']/tbody/tr/td/a")
	public List<WebElement> Plan_StartDate_List;
	
	//Elements Related to date picker
	
	//Element to select Prev months
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Prev']")
	public WebElement Plan_StartDate_Prev;

	//Element to select Next month
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Next']")
	public WebElement Plan_StartDate_Next;

	
		/*Elements Related to Plan End date*/
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='FinishDate2']")
	public WebElement Plan_EndDate;

	@FindBy(how = How.XPATH , 
			using = "//table[@class='ui-datepicker-calendar']/tbody/tr/td[@class=' ']")
	public WebElement Plan_EndDate_List;
	
	//Element to select Prev month
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Prev']")
	public WebElement Plan_EndDate_Prev;

	//Element to select Next month
	
	@FindBy(how = How.XPATH , 
			using = "//span[text()='Next']")
	public WebElement Plan_EndDate_Next;

	
	//Elements related to Plan_Operation_Vp

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single']")
	public WebElement Plan_Operations_VP_ID;

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-search']/input[@type='text']")
	public WebElement Op_Vp_id_input;


	@FindBy(how = How.XPATH , 
			using = "//ul[@class='chosen-results']/li")
	public List<WebElement> Op_Vp_id_list;

	//Elements related to Parent_Client_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single'][@id='ParentClientId2_chosen']")
	public WebElement Parent_client_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ParentClientId2_chosen']/div/ul[@class='chosen-results']/li")
	public List<WebElement> Parent_client_List;

	//Elements related to Client_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single chosen-container-single-nosearch'][@id='ClientId2_chosen']")
	public WebElement Client_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ClientId2_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Client_List;

	//Elements related to Program_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single chosen-container-single-nosearch'][@id='ProgramId2_chosen']")
	public WebElement Program_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ProgramId2_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Program_Id_List;

	//Elements related to Project_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single chosen-container-single-nosearch'][@id='ProjectId2_chosen']")
	public WebElement Project_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ProjectId2_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Project_Id_List;

	//Elements related to Region

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single chosen-container-single-nosearch'][@id='RegionId2_chosen']")
	public WebElement Region_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='RegionId2_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Region_Id_List;

	//Elements Related to country

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single chosen-container-single-nosearch'][@id='CountryId2_chosen']")
	public WebElement Country_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='CountryId2_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Country_Id_List;

	//Elements Related to Site

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single chosen-container-single-nosearch'][@id='SiteId2_chosen']")
	public WebElement Site_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='SiteId2_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Site_Id_List;



	//Element Related to view Plan

	@FindBy(how = How.XPATH , 
			using = "//input[@value='View Plan']")
	public WebElement Plan_ViewPlan;
	
	//Element Related to delete officialize Plan
	
	@FindBy(how = How.XPATH , 
			using = "//input[@value='Delete Official Plan']")
	public WebElement Plan_DeleteOfficialPlan;
	
	//Plan Favorite


	@FindBy(how = How.XPATH , 
			using = "//img[@src='/StaffPoint.WebDev/Content/Images/fav_transparent_2.png']")
	public WebElement Plan_Favorite;

	//Favorite_Ok_Ui_Button

	@FindBy(how = How.XPATH , 
			using = "//span[@class='ui-button-text'][text()='Ok']")
	public List<WebElement> Ok_Favorite;

	@FindBy(how = How.XPATH , 
			using = "//span[@class='ui-button-text'][text()='Cancel']")
	public List<WebElement> Cancel_Favorite;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='txtFavorite']")
	public WebElement Favorite_Text;
	
	//Element Related to Approve Plan
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='btnMakeOfficialTop']")
	public WebElement Approve_Plan;		
	//btnMakeOfficialTop

	
	/*Method Related to Plan Start date*/
	
	public void selectStartDate(String Data_StartDate) throws InterruptedException{

		
		Plan_StartDate.click();

		Thread.sleep(2000);

		for(WebElement StartDate:Plan_StartDate_List ){
			
			if(StartDate.getText().equalsIgnoreCase(Data_StartDate)){
				
				StartDate.click();
				
				break;
			}
		}


	}
	
	//Method related to plan End Date
	
	public void selectEndDate(String Data_EndDate) throws InterruptedException{

		
		Plan_EndDate.click();

		Thread.sleep(2000);

		for(WebElement StartDate:Plan_StartDate_List ){

			
			if(StartDate.getText().equalsIgnoreCase(Data_EndDate)){

				
				StartDate.click();
				
				break;
			}
		}


	}
	
	
	
	
	//Method related to OP_VP

	public void selectOperationVp(String Data_Operations_Vp) throws InterruptedException{

		Plan_Operations_VP_ID.click();

		Op_Vp_id_input.sendKeys(Data_Operations_Vp);

		Thread.sleep(2000);


		for(WebElement Operations_Vp:Op_Vp_id_list ){

			if(Operations_Vp.getText().equalsIgnoreCase(Data_Operations_Vp)){

				Operations_Vp.click();
			
				break;
			}
		}


	}


	//Method related to Parent Client

	public void selectParentClient(String Data_ParentClient) throws InterruptedException{

		Parent_client_Select.click();

		Thread.sleep(1000);

		for(WebElement ParentClient:Parent_client_List ){

			if(ParentClient.getText().equalsIgnoreCase(Data_ParentClient)){

				ParentClient.click();
				
				break;
			}
		}
	}

	//Method related to client

	public void selectClient(String Data_Client) throws InterruptedException{

		//Actions act = new Actions(driver);
		
		//act.moveToElement(Client_Select).click().build().perform();
		
		Client_Select.click();

		Thread.sleep(1000);

		for(WebElement Client:Client_List){

			if(Client.getText().equalsIgnoreCase(Data_Client)){

				Client.click();
				
				break;
			}
		}
	}

	//Method Related to Program

	public void selectProgram(String Data_Program_Id) throws InterruptedException{

		Program_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Program_Id:Program_Id_List ){

			if(Program_Id.getText().equalsIgnoreCase(Data_Program_Id)){

				Program_Id.click();
				
				break;
			}
		}
	}

	//Method related to Project

	public void selectProject(String Data_Project_Id) throws InterruptedException{

		Project_Id_Select.click();


		Thread.sleep(1000);
		for(WebElement Project_Id:Project_Id_List ){

			if(Project_Id.getText().equalsIgnoreCase(Data_Project_Id)){

				Project_Id.click();
			
				break;
			}
		}
	}

	//Method related to Region

	public void selectRegion(String Data_Region) throws InterruptedException{

		Region_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Region:Region_Id_List ){

			if(Region.getText().equalsIgnoreCase(Data_Region)){

				Region.click();
				
				break;
			}
		}
	}

	//Method Related to country

	public void selectCountry(String Data_Country) throws InterruptedException{

		Country_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Country:Country_Id_List ){

			if(Country.getText().equalsIgnoreCase(Data_Country)){

				Country.click();
				
				break;
			}
		}
	}

	//Method related to site

	public void selectSite(String Data_Site) throws InterruptedException{

		Site_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Site:Site_Id_List ){

			if(Site.getText().equalsIgnoreCase(Data_Site)){

				Site.click();
				
				break;
			}
		}
	}



	public void viewPlan(){

		Plan_ViewPlan.click();

	}
	
	
	public void deletePlan(){

		Plan_ViewPlan.click();

	}

	

	public void submitFavorite(String Input_Faovorite_Name) throws InterruptedException{

		Plan_Favorite.click();

		Thread.sleep(2000);

		for(WebElement Ok_first:Ok_Favorite){
			int X_Ok_first = Ok_first.getLocation().getX();
			int Y_Ok_first = Ok_first.getLocation().getY();	
			if((X_Ok_first > 0)&&(Y_Ok_first > 0)){
				Ok_first.click();
			}
		}
		Favorite_Text.sendKeys(Input_Faovorite_Name);
		
		Thread.sleep(1000);
		
		for(WebElement Ok_Second:Ok_Favorite){
			int X_Ok_Second = Ok_Second.getLocation().getX();
			int Y_Ok_Second = Ok_Second.getLocation().getY();	
			if((X_Ok_Second > 0)&&(Y_Ok_Second > 0)){
				Ok_Second.click();
			}
		}
		
		Thread.sleep(4000);
		
		for(WebElement Ok_Third:Ok_Favorite){
			int X_Ok_Third = Ok_Third.getLocation().getX();
			int Y_Ok_Third = Ok_Third.getLocation().getY();	
			if((X_Ok_Third > 0)&&(Y_Ok_Third > 0)){
				Ok_Third.click();
			}
		}
	}


	public void cancelFavorite() throws InterruptedException{

		Plan_Favorite.click();

		Thread.sleep(3000);

		for(WebElement Cancel_first:Cancel_Favorite){
			int X_Cancel_first = Cancel_first.getLocation().getX();
			int Y_Cancel_first = Cancel_first.getLocation().getY();	
			if((X_Cancel_first > 0)&&(Y_Cancel_first > 0)){
				Cancel_first.click();
			}
		}

	}

	public void secondCancelFavorite(String Input_Faovorite_Name) throws InterruptedException{

		Plan_Favorite.click();

		Thread.sleep(2000);

		for(WebElement Ok_first:Ok_Favorite){
			int X_Ok_first = Ok_first.getLocation().getX();
			int Y_Ok_first = Ok_first.getLocation().getY();	
			if((X_Ok_first > 0)&&(Y_Ok_first > 0)){
				Ok_first.click();
			}
		}
		Favorite_Text.sendKeys(Input_Faovorite_Name);

		Thread.sleep(2000);
		
		for(WebElement Cancel_first:Cancel_Favorite){
			int X_Cancel_first = Cancel_first.getLocation().getX();
			int Y_Cancel_first = Cancel_first.getLocation().getY();	
			if((X_Cancel_first > 0)&&(Y_Cancel_first > 0)){
				Cancel_first.click();

			}
		}
	}


public void approvePlan() throws InterruptedException{
	
	Approve_Plan.click();
	
	Thread.sleep(3000);
	
	WebElement Approv_Plan = driver.findElement(By.xpath("//span[@class='ui-button-text'][text()='Ok']"));

	Approv_Plan.click();

	Thread.sleep(4000);
	
	WebElement Approv_Plan_ok =  driver.findElement(By.xpath("//div[@aria-labelledby='ui-dialog-title-dialogMessage']/div/div/button/span[text()='Ok']"));
	
	Approv_Plan_ok.click();
	
	Thread.sleep(7000);
	
	WebElement Approv_Plan_2ndok =  driver.findElement(By.xpath("//div[@aria-labelledby='ui-dialog-title-dialogInfoMessage']/div/div/button/span[text()='Ok']"));
	
	Approv_Plan_2ndok.click();
	
	
}
	

}
