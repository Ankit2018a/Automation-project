package notes;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import StaticPages.TabularBarPage;
import pageFactory.NotesPage;

public class CreateNotes extends NotesPage{

	public CreateNotes(WebDriver driver2) {
		super(driver2);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, NotesPage.class);
		PageFactory.initElements(driver, this);
		
	}


	
	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single'][@id='ParentClientId_chosen']/a")
	public WebElement Parent_client_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ParentClientId_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Parent_client_List;

	//Elements related to Client_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single'][@id='ClientId_chosen']")
	public WebElement Client_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ClientId_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Client_List;

	//Elements related to Program_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single'][@id='ProgramId_chosen']")
	public WebElement Program_Id_Select;



	@FindBy(how = How.XPATH , 
			using = "//div[@id='ProgramId_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Program_Id_List;

	//Elements related to Project_id

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single'][@id='ProjectId_chosen']")
	public WebElement Project_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='ProjectId_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Project_Id_List;

	//Elements related to Region

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single'][@id='RegionId_chosen']")
	public WebElement Region_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='RegionId_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Region_Id_List;

	//Elements Related to country

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single'][@id='CountryId_chosen']")
	public WebElement Country_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='CountryId_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Country_Id_List;

	//Elements Related to Site

	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single'][@id='SiteId_chosen']")
	public WebElement Site_Id_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='SiteId_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li")
	public List<WebElement> Site_Id_List;

	
	//add notes
	
	@FindBy(how = How.XPATH , 
			using = "//td[@class='search-field']/textarea[@id='Notes']")
	public WebElement Reuester_Notes;
	
	
	// Save notes
	
	@FindBy(how = How.XPATH , 
			using = "//input[@type='submit'][@value='Save']")
	public WebElement Notes_Save;
	
	//Elements related to fiscal week
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='FiscalWeek']")
	public WebElement Fiscal_Week;

	@FindBy(how = How.XPATH , 
			using = "//table[@class='ui-datepicker-calendar']/tbody/tr/td/a[@href='#']")
	public List<WebElement> Fiscal_Week_List;
	
	//Elements Related to add Title
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='Title']")
	public WebElement Title_notes;
	
	@FindBy(how = How.XPATH , 
			using = "//div[@id='contentEditor']")
	public WebElement Note_notes;

	
	//"//input[@id='Title']"
	
	//Method related to Parent Client

	public void selectParentClient(String Data_ParentClient) throws InterruptedException{

		Parent_client_Select.click();

		Thread.sleep(1000);

		for(WebElement ParentClient:Parent_client_List ){

			if(ParentClient.getText().equalsIgnoreCase(Data_ParentClient)){

				ParentClient.click();
				
				break;
			}
		}
	}

	//Method related to client

	public void selectClient(String Data_Client) throws InterruptedException{

		//Actions act = new Actions(driver);
		
		//act.moveToElement(Client_Select).click().build().perform();
		
		Client_Select.click();

		Thread.sleep(1000);

		for(WebElement Client:Client_List){

			if(Client.getText().equalsIgnoreCase(Data_Client)){

				Client.click();
				
				break;
			}
		}
	}

	//Method Related to Program

	public void selectProgram(String Data_Program_Id) throws InterruptedException{

		Program_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Program_Id:Program_Id_List ){

			if(Program_Id.getText().equalsIgnoreCase(Data_Program_Id)){

				Program_Id.click();
				
				break;
			}
		}
	}

	//Method related to Project

	public void selectProject(String Data_Project_Id) throws InterruptedException{

		Project_Id_Select.click();


		Thread.sleep(2000);
		for(WebElement Project_Id:Project_Id_List ){

			if(Project_Id.getText().equalsIgnoreCase(Data_Project_Id)){

				Project_Id.click();
				
				break;
			}
		}
	}

	//Method related to Region

	public void selectRegion(String Data_Region) throws InterruptedException{

		Region_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Region:Region_Id_List ){

			if(Region.getText().equalsIgnoreCase(Data_Region)){

				Region.click();
				
				break;
			}
		}
	}

	//Method Related to country

	public void selectCountry(String Data_Country) throws InterruptedException{

		Country_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Country:Country_Id_List ){

			if(Country.getText().equalsIgnoreCase(Data_Country)){

				Country.click();
				
				break;
			}
		}
	}

	//Method related to site

	public void selectSite(String Data_Site) throws InterruptedException{

		Site_Id_Select.click();

		Thread.sleep(1000);

		for(WebElement Site:Site_Id_List ){

			if(Site.getText().equalsIgnoreCase(Data_Site)){

				Site.click();
				
				break;
			}
		}
	
	}
	
	public void weekSelect(String Week) throws InterruptedException{
		
		Fiscal_Week.click();
		
		Thread.sleep(1000);

		for(WebElement week:Fiscal_Week_List ){

			if(week.getText().equalsIgnoreCase(Week)){

				week.click();
				
				break;
			}
		}
		}
	
	public void addTitle(String Title){
	
		Title_notes.sendKeys(Title);
		
	}
	
	public void addNote(String Note){

		Note_notes.click();
	}


	public void SaveNotes(){
		
		Notes_Save.click();
	
	}


}