package StaticPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class TabularBarPage {

	public WebDriver driver; 



	/*List of Elements in Title Page*/


	public TabularBarPage(WebDriver driver2) {
		// TODO Auto-generated constructor stub
		//super();
	// TODO Auto-generated constructor stub
		
		this.driver=driver2;
	
		PageFactory.initElements(driver2, this);
	}


	/*List of Elements in Tabular Bar*/	
	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/']")
	public WebElement TabularBar_Home;

	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/Planning']")
	public WebElement TabularBar_Planning;

	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/WeekConfiguration']")
	public WebElement TabularBar_Configuration;

	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/Notes']")
	public WebElement TabularBar_Notes;

	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/AboutUs']")
	public WebElement TabularBar_AboutUs;

	
	//Element related to account
	
	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/Account']")
	public WebElement TabularBar_Account;
	
	
	//Element related to officialize Plan
	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/OfficialPlanning']")
	public WebElement TabularBar_OfficialPlanning;
	
	//Element Related to  Emails
	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/Email']")
	public WebElement TabularBar_Email;
	
	//Element Related to Exclusion
	
	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/Exclusions']")
	public WebElement TabularBar_Exclusions;
	
	
	
	
	/*List of Elements in Logout*/

	@FindBy(how = How.XPATH , 
			using = "//div[@id='UserName']")
	public WebElement Logout_Username;

	//List of methods based on Tabular Bar


	public void clickHome(){

		TabularBar_Home.click();
	
	//Actions action = new Actions(driver)
	}	

	public void clickAccount(){

		TabularBar_Account.click();
	}	

	public void clickOfficialPlanning(){

		TabularBar_OfficialPlanning.click();
	}	

	public void clickEmail(){

		TabularBar_Email.click();
	}	

	public void clickExclusions(){

		TabularBar_Exclusions.click();
	}	

	public void clickPlanning(){

		TabularBar_Planning.click();
	}	

	public void clickConfiguration(){

		TabularBar_Configuration.click();
	}	

	public void clickNotes(){

		TabularBar_Notes.click();
	}	

	public void clickAboutUs(){

		TabularBar_AboutUs.click();
	}
}
