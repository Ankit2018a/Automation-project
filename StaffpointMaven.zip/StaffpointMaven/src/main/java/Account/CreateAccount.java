package Account;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import StaticPages.TabularBarPage;
import pageFactory.AccountPlanning;
import pageFactory.PlanningPage;

public class CreateAccount extends AccountPlanning{

	public CreateAccount(WebDriver driver2) {
		super(driver2);
		
		PageFactory.initElements(driver, AccountPlanning.class);
		PageFactory.initElements(driver, TabularBarPage.class);
		PageFactory.initElements(driver, PlanningPage.class);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}
	
	//List of fields in create Configuration Page


	//Elements Related to Project

	@FindBy(how = How.XPATH , 
			using = "//select[@id='DomainName']")
	public WebElement Acc_Search_Domain;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='TextToSearch']")
	public WebElement Acc_Domain_text;


	//Elements Related to site

	@FindBy(how = How.XPATH , 
			using = "//input[@value='Search']")
	public WebElement Acc_Domain_Search_button;


	//Account details
	
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='FirstName']")
	public WebElement Acc_FirstName;


	//Elements Related to Headcount type

	@FindBy(how = How.XPATH , 
			using = "//input[@id='LastName']")
	public WebElement Acc_LastName;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='OracleId']")
	public WebElement Acc_Oracle_Id;

	/*input fields in createConfiguration Page*/

	//Elements Related to Agents
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='ShowDashboard']")
	public WebElement Acc_ShowDashboard;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='EditPastData']")
	public WebElement Acc_EditPastData;
	
	
	//List of Elements Related to Roles
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='roles_Admin']")
	public WebElement Acc_roles_Admin;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='roles_ExclusionApprover']")
	public WebElement Acc_roles_ExclusionApprover;
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='roles_ExclusionRequester']")
	public WebElement Acc_roles_ExclusionRequester;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='roles_PlanOfficializer']")
	public WebElement Acc_roles_PlanOfficializer;
	
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='roles_ReadOnlyUser']")
	public WebElement Acc_roles_ReadOnlyUser;


	@FindBy(how = How.XPATH , 
			using = "//input[@id='roles_WFMSuperUser']")
	public WebElement Acc_roles_WFMSuperUser;
	
	
	@FindBy(how = How.XPATH , 
			using = "//input[@id='roles_WFMUser']")
	public WebElement Acc_roles_WFMUser;
	

	//Elements Related save and Returning Back 
	
	@FindBy(how = How.XPATH , 
			using = "//input[@type='submit'][@onclick='return checkOneSelected();']")
	public WebElement Acc_detailsSave;


	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/Account']")
	public WebElement Acc_AccountPage;


	@FindBy(how = How.XPATH , 
			using = "//a[@href='/StaffPoint.WebDev/Account/Create']")
	public WebElement Acc_CreatePage;
	
	
	@FindBy(how = How.XPATH , 
			using = "//input[@type='submit'][@value='Confirm Delete']")
	public WebElement Acc_Delete_Confirm;

	
	//Assign Parent Client
	
	@FindBy(how = How.XPATH , 
			using = "//div[@class='chosen-container chosen-container-single'][@id='AllParentClients_chosen']")
	public WebElement Assign_Parent_Select;


	@FindBy(how = How.XPATH , 
			using = "//div[@id='AllParentClients_chosen']/div[@class='chosen-drop']/ul[@class='chosen-results']/li[contains(@class,'active-result')]")
	public List<WebElement> Assign_Parent_List;

	@FindBy(how = How.XPATH , 
			using = "//input[@type='submit'][@value='Add']")
	public WebElement Assign_Parent_Add;

	
	//Add Parent Client
	
	public void addParentClient(String Data_ParentClient) throws InterruptedException{

		JavascriptExecutor scrool = (JavascriptExecutor)driver;
		scrool.executeScript("arguments[0].scrollIntoView(true);", Acc_detailsSave);
		Assign_Parent_Select.click();

		Thread.sleep(1000);

		for(WebElement ParentClient:Assign_Parent_List ){

			if(ParentClient.getText().equalsIgnoreCase(Data_ParentClient)){

				ParentClient.click();
				
				break;
			}
		}
		
		Assign_Parent_Add.click();
		
	}

	public void searchDomain(String DomainType , String DomainName ){

		Select select = new Select(Acc_Search_Domain);
		select.selectByVisibleText(DomainType);
		Acc_Domain_text.sendKeys(DomainName);
		Acc_Domain_Search_button.click();
	
	}

	
	public void step2CreateAccount(String Displayfirst , String Displaylast ){

		String str = "//a[contains(@href,'/StaffPoint.WebDev/Account/CheckExists?disp=";
		String str2 = "%20";
		String str3 = "')]";
		
		
		WebElement ele = driver.findElement(By.xpath(str+Displayfirst+str2+Displaylast+str3));
		
		ele.click();
		
		
	}
	
	public void step3InputData(String FirstName , String LastName , String OracleId){

		Acc_FirstName.clear();
		Acc_FirstName.sendKeys(FirstName);
		Acc_LastName.clear();
		Acc_LastName.sendKeys(LastName);
		Acc_Oracle_Id.clear();
		Acc_Oracle_Id.sendKeys(OracleId);
}
	

	public void step3ShowDashboard(){

		Acc_ShowDashboard.click();
	}


	public void step3EditPastData(){

		Acc_EditPastData.click();
	}
	
	//methods related to Roles
	
	public void step3rolesAdmin(){

		Acc_roles_Admin.click();
	}
	
	public void step3rolesExclusionApprove(){

		Acc_roles_ExclusionApprover.click();
	}

	public void step3ExclusionRequester(){

		Acc_roles_ExclusionRequester.click();
	}

	public void step3PlanOfficializer(){

		Acc_roles_PlanOfficializer.click();
	}

	public void step3ReadOnlyUser(){

		Acc_roles_ReadOnlyUser.click();
	}

	public void step3WFMSuperUser(){

		Acc_roles_WFMSuperUser.click();
	}
	
	public void step3WFMUser(){

		Acc_roles_WFMUser.click();
	}
	
	public void AccountSave(){
	 
		Acc_detailsSave.click();
	}

	public void deleteConfirm(){
		
		JavascriptExecutor scrool = (JavascriptExecutor)driver;
		scrool.executeScript("arguments[0].scrollIntoView(true);", Acc_Delete_Confirm);
		
		Acc_Delete_Confirm.click();
		
	}
	
	
	
}