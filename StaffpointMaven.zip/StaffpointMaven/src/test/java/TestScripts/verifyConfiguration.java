package TestScripts;

import java.awt.AWTException;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.Test;

import config.CreateConfiguration;
import config.DeleteConfiguration;
import pageFactory.Login_Page;
import pageFactory.OfficializePlan;
import pageFactory.PlanningPage;
import plan.PlanNextPage;

public class verifyConfiguration extends DriverConfig {
  /*
	@Test(priority=1)
  public void CreateConfigurationAgent() throws InterruptedException, AWTException {
	  
		

		Login_Page lp = new Login_Page();
		  
		 lp.userLogin();
		  
		Thread.sleep(7000);
	 		
	  CreateConfiguration ccp = new CreateConfiguration(StaffpointDriver);
	  
	  Thread.sleep(8000);
	  
	  ccp.clickConfiguration();
	  
		ccp.newConfig();
		
		Thread.sleep(12000);
		
		ccp.selectConfigProject("ABB Limited - L&L - Australia [R608]");
		
		Thread.sleep(2000);
		
		ccp.selectConfigSite("Agent At Home - Healthcare [408]");
		
		Thread.sleep(1000);
		
		ccp.selectConfigHeadcountType("Agent");
			
		Thread.sleep(3000);
		
		ccp.inputAgentProduction("4");
		ccp.inputAgentNesting("3");
		ccp.inputAgentTraining("7");
		ccp.inputConfigFTEDefinition("3");
		ccp.inputTargetPhoneOccupancy("6");
		ccp.inputContractualForecast("2");
		ccp.inputLockedWeeks("2");
		
		ccp.clickSave();
	  
		Thread.sleep(3000);
		
		PlanningPage pp = new PlanningPage(StaffpointDriver);	
		 
		 Thread.sleep(3000);
		 
		 pp.clickPlanning(); 
		 
		 Thread.sleep(5000);
			
			pp.selectParentClient("ABB Limited [11861]");
			
			Thread.sleep(4000);
			
			pp.selectClient("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(4000);
			
			pp.selectProgram("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(4000);
			
			pp.selectProject("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(4000);
			
			pp.selectRegion("Oceania [OCE]");
			
			Thread.sleep(4000);
			
			pp.selectCountry("Australia [AU]");
			
			Thread.sleep(4000);

			pp.selectSite("Agents At Home - AU [206]");
			
			Thread.sleep(4000);
			
			pp.submitPlan();
			
			PlanNextPage pnp = new PlanNextPage(StaffpointDriver);
			
			Thread.sleep(2000);
			
			pnp.SummaryUserGuide();
			
		
			pnp.clickBreakdown();
			
			Thread.sleep(1000);

			pnp.BreakdownUserGuide();
			
			Thread.sleep(3000);
		 
		 }
	
	@Test(priority=2)
	 public void CreateConfigurationGA() throws InterruptedException, AWTException {
		 

			Login_Page lp = new Login_Page();
			  
			 lp.userLogin();
			  
			Thread.sleep(7000);
		 		
		  CreateConfiguration ccp = new CreateConfiguration(StaffpointDriver);
		  
		  Thread.sleep(3000);
		  
		  ccp.clickConfiguration();
		  
			ccp.newConfig();
			
			Thread.sleep(12000);

			ccp.selectConfigProject("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(1000);
			
			ccp.selectConfigSite("Agent At Home - Healthcare [408]");
			
			Thread.sleep(1000);
			
			ccp.selectConfigHeadcountType("G&A");
			
			Thread.sleep(1000);
			
			ccp.inputGAProduction("6");;
			ccp.inputGANesting("5");;
			ccp.inputGATraining("4");
			ccp.inputConfigFTEDefinition("3");
			ccp.inputTargetPhoneOccupancy("6");
			ccp.inputContractualForecast("2");
			ccp.inputLockedWeeks("2");
			
			ccp.clickSave();
			
			Thread.sleep(3000);
		
		PlanningPage pp = new PlanningPage(StaffpointDriver);	
		 
		 Thread.sleep(3000);
		 
		 pp.clickPlanning(); 
		 
		 Thread.sleep(5000);
			
			pp.selectParentClient("ABB Limited [11861]");
			
			Thread.sleep(4000);
			
			pp.selectClient("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(4000);
			
			pp.selectProgram("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(4000);
			
			pp.selectProject("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(4000);
			
			pp.selectRegion("Oceania [OCE]");
			
			Thread.sleep(4000);
			
			pp.selectCountry("Australia [AU]");
			
			Thread.sleep(4000);

			pp.selectSite("Agents At Home - AU [206]");
			
			Thread.sleep(4000);
			
			pp.submitPlan();
			
			Thread.sleep(3000);
			
			PlanNextPage pnp = new PlanNextPage(StaffpointDriver);
			
			Thread.sleep(2000);
			
			pnp.SummaryUserGuide();
			
		
			pnp.clickBreakdown();
			
			Thread.sleep(1000);

			pnp.BreakdownUserGuide();
			
	 }
	
	
	@Test(priority=3)
	 public void CreateConfigurationBoth() throws InterruptedException, AWTException {
		 

			Login_Page lp = new Login_Page();
			  
			 lp.userLogin();
			 
			  
			Thread.sleep(7000);
		 		
		  CreateConfiguration ccp = new CreateConfiguration(StaffpointDriver);
		  
		  Thread.sleep(3000);
		  
		  ccp.clickConfiguration();
		  
		  Thread.sleep(3000);
		  
			ccp.newConfig();
			
			Thread.sleep(12000);

			ccp.selectConfigProject("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(1000);
			
			ccp.selectConfigSite("Agent At Home - Healthcare [408]");
			
			Thread.sleep(1000);
			
			ccp.selectConfigHeadcountType("Both");
			
			Thread.sleep(1000);
			
			
			ccp.inputAgentProduction("4");
			ccp.inputAgentNesting("3");
			ccp.inputAgentTraining("7");
			
			ccp.inputGAProduction("6");;
			ccp.inputGANesting("5");;
			ccp.inputGATraining("4");
			ccp.inputConfigFTEDefinition("3");
			ccp.inputTargetPhoneOccupancy("6");
			ccp.inputContractualForecast("2");
			ccp.inputLockedWeeks("2");
			
			ccp.clickSave();
			
		Thread.sleep(3000);
		
		PlanningPage pp = new PlanningPage(StaffpointDriver);	
		 
		 Thread.sleep(1000);
		 
		 pp.clickPlanning(); 
		 
		 Thread.sleep(6000);
			
			pp.selectParentClient("ABB Limited [11861]");
			
			Thread.sleep(4000);
			
			pp.selectClient("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(4000);
			
			pp.selectProgram("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(4000);
			
			pp.selectProject("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(4000);
			
			pp.selectRegion("Oceania [OCE]");
			
			Thread.sleep(4000);
			
			pp.selectCountry("Australia [AU]");
			
			Thread.sleep(4000);

			pp.selectSite("Agents At Home - AU [206]");
			
			Thread.sleep(4000);
			
			pp.submitPlan();
			
			Thread.sleep(3000);
			
			PlanNextPage pnp = new PlanNextPage(StaffpointDriver);
			
			Thread.sleep(2000);
			
			pnp.SummaryUserGuide();
			
		
			pnp.clickBreakdown();
			
			Thread.sleep(1000);

			pnp.BreakdownUserGuide();
			
}
	 
	 
		@Test(priority=4)
	  public void CreateConfigurationAgentOP() throws InterruptedException, AWTException {
		  
			

			Login_Page lp = new Login_Page();
			  
			 lp.userLogin();
			  
			Thread.sleep(7000);
		 		
		  CreateConfiguration ccp = new CreateConfiguration(StaffpointDriver);
		  
		  Thread.sleep(8000);
		  
		  ccp.clickConfiguration();
		  
			ccp.newConfig();
			
			Thread.sleep(12000);
			
			ccp.selectConfigProject("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(2000);
			
			ccp.selectConfigSite("Agent At Home - Healthcare [408]");
			
			Thread.sleep(1000);
			
			ccp.selectConfigHeadcountType("Agent");
				
			Thread.sleep(3000);
			
			ccp.inputAgentProduction("4");
			ccp.inputAgentNesting("3");
			ccp.inputAgentTraining("7");
			ccp.inputConfigFTEDefinition("3");
			ccp.inputTargetPhoneOccupancy("6");
			ccp.inputContractualForecast("2");
			ccp.inputLockedWeeks("2");
			
			ccp.clickSave();
		  
			Thread.sleep(3000);
			
			OfficializePlan pp = new OfficializePlan(StaffpointDriver);	
			 
			 Thread.sleep(3000);
			 
			 pp.clickOfficialPlanning();
			 
			 Thread.sleep(5000);
				
				pp.selectParentClient("ABB Limited [11861]");
				
				Thread.sleep(4000);
				
				pp.selectClient("ABB Limited - L&L - Australia [R608]");
				
				Thread.sleep(4000);
				
				pp.selectProgram("ABB Limited - L&L - Australia [R608]");
				
				Thread.sleep(4000);
				
				pp.selectProject("ABB Limited - L&L - Australia [R608]");
				
				Thread.sleep(4000);
				
				pp.selectRegion("Oceania [OCE]");
				
				Thread.sleep(4000);
				
				pp.selectCountry("Australia [AU]");
				
				Thread.sleep(4000);

				pp.selectSite("Agents At Home - AU [206]");
				
				Thread.sleep(4000);
				
				
				pp.viewPlan();
				
				Thread.sleep(6000);
				
				pp.clickBreakdown();
				
				pp.selectMonth("Feb-18");
				
				Thread.sleep(3000);
			 
			 }*/
		
		@Test(priority=5)
		 public void CreateConfigurationOP() throws InterruptedException, AWTException {
			 

				Login_Page lp = new Login_Page();
				  
				 lp.userLogin();
				  
				Thread.sleep(7000);
			 		
			  CreateConfiguration ccp = new CreateConfiguration(StaffpointDriver);
			  
			  Thread.sleep(3000);
			  
			  ccp.clickConfiguration();
			  
				ccp.newConfig();
				
				Thread.sleep(12000);

				ccp.selectConfigProject("ABB Limited - L&L - Australia [R608]");
				
				Thread.sleep(1000);
				
				ccp.selectConfigSite("Agent At Home - Healthcare [408]");
				
				Thread.sleep(1000);
				
				ccp.selectConfigHeadcountType("G&A");
				
				Thread.sleep(1000);
				
				ccp.inputGAProduction("6");;
				ccp.inputGANesting("5");;
				ccp.inputGATraining("4");
				ccp.inputConfigFTEDefinition("3");
				ccp.inputTargetPhoneOccupancy("6");
				ccp.inputContractualForecast("2");
				ccp.inputLockedWeeks("2");
				
				ccp.clickSave();
				
				Thread.sleep(3000);
			
				OfficializePlan pp = new OfficializePlan(StaffpointDriver);	
				 
				 Thread.sleep(3000);
				 
				 pp.clickOfficialPlanning();
				 
				 Thread.sleep(5000);
					
					pp.selectParentClient("ABB Limited [11861]");
					
					Thread.sleep(4000);
					
					pp.selectClient("ABB Limited - L&L - Australia [R608]");
					
					Thread.sleep(4000);
					
					pp.selectProgram("ABB Limited - L&L - Australia [R608]");
					
					Thread.sleep(4000);
					
					pp.selectProject("ABB Limited - L&L - Australia [R608]");
					
					Thread.sleep(4000);
					
					pp.selectRegion("Oceania [OCE]");
					
					Thread.sleep(4000);
					
					pp.selectCountry("Australia [AU]");
					
					Thread.sleep(4000);

					pp.selectSite("Agents At Home - AU [206]");
					
					Thread.sleep(4000);
					
					pp.viewPlan();
					
					Thread.sleep(6000);
					
					//pp.approvePlan();
					
					pp.clickBreakdown();
					
					pp.selectMonth("Feb-18");
					
					Thread.sleep(3000);
					

		 }
		
		
		@Test(priority=6)
		 public void CreateConfigurationBothOP() throws InterruptedException, AWTException {
			 

				Login_Page lp = new Login_Page();
				  
				 lp.userLogin();
				 
				  
				Thread.sleep(7000);
			 		
			  CreateConfiguration ccp = new CreateConfiguration(StaffpointDriver);
			  
			  Thread.sleep(3000);
			  
			  ccp.clickConfiguration();
			  
			  Thread.sleep(3000);
			  
				ccp.newConfig();
				
				Thread.sleep(12000);

				ccp.selectConfigProject("ABB Limited - L&L - Australia [R608]");
				
				Thread.sleep(1000);
				
				ccp.selectConfigSite("Agent At Home - Healthcare [408]");
				
				Thread.sleep(1000);
				
				ccp.selectConfigHeadcountType("Both");
				
				Thread.sleep(1000);
				
				
				ccp.inputAgentProduction("4");
				ccp.inputAgentNesting("3");
				ccp.inputAgentTraining("7");
				
				ccp.inputGAProduction("6");;
				ccp.inputGANesting("5");;
				ccp.inputGATraining("4");
				ccp.inputConfigFTEDefinition("3");
				ccp.inputTargetPhoneOccupancy("6");
				ccp.inputContractualForecast("2");
				ccp.inputLockedWeeks("2");
				
				ccp.clickSave();
				
			Thread.sleep(3000);
			
			OfficializePlan pp = new OfficializePlan(StaffpointDriver);	
			 
			 Thread.sleep(3000);
			 
			 pp.clickOfficialPlanning(); 
			 
			 Thread.sleep(5000);
				
				pp.selectParentClient("ABB Limited [11861]");
				
				Thread.sleep(4000);
				
				pp.selectClient("ABB Limited - L&L - Australia [R608]");
				
				Thread.sleep(4000);
				
				pp.selectProgram("ABB Limited - L&L - Australia [R608]");
				
				Thread.sleep(4000);
				
				pp.selectProject("ABB Limited - L&L - Australia [R608]");
				
				Thread.sleep(4000);
				
				pp.selectRegion("Oceania [OCE]");
				
				Thread.sleep(4000);
				
				pp.selectCountry("Australia [AU]");
				
				Thread.sleep(4000);

				pp.selectSite("Agents At Home - AU [206]");
				
				Thread.sleep(4000);
				
				Thread.sleep(4000);
				
				pp.viewPlan();
				
				Thread.sleep(6000);
				
				//pp.approvePlan();
				

				pp.clickBreakdown();
				
				pp.selectMonth("Feb-18");
				
				Thread.sleep(4000);
	
	}
	
/*
	@Test(priority = 7)
	  public void CreateConfigurationError() throws InterruptedException, AWTException {
		  
			Login_Page lp = new Login_Page();
			  
			 lp.userLogin();
			  
			Thread.sleep(7000);
		 		
		  CreateConfiguration ccp = new CreateConfiguration(StaffpointDriver);
		  
		  Thread.sleep(3000);
		  
		  ccp.clickConfiguration();
		  
			ccp.newConfig();
			
			Thread.sleep(2000);

			ccp.selectConfigProject("ABB Limited - L&L - Australia [R608]");
			
			Thread.sleep(1000);
			
			ccp.selectConfigSite("Agent At Home - Healthcare [408]");
			
			Thread.sleep(1000);
			
			ccp.selectConfigHeadcountType("Agent");
			
			Thread.sleep(1000);
			
			ccp.inputAgentProduction("51");
			ccp.inputAgentNesting("53");
			ccp.inputAgentTraining("87");
			ccp.inputConfigFTEDefinition("93");
			ccp.inputTargetPhoneOccupancy("107");
			ccp.inputContractualForecast("201");
			ccp.inputLockedWeeks("57");
			
			ccp.clickSave();
			
			Thread.sleep(2000);
			
			ArrayList<String> err_List = ccp.errorValidation();
			
		    java.util.Iterator<String> itr =err_List.iterator();
		    
		    while(itr.hasNext())
		    {
		    	System.out.println(itr.next());
		    }
			
		    Assert.assertTrue(err_List.contains("The field FTE Definition must be between 1 and 80."));
		    
		    Assert.assertTrue(err_List.contains("The field Target Phone Occupancy must be between 1 and 100."));
	
		  	}
	
	
	@Test(priority = 8)
	  public void DeleteConfigurationError() throws InterruptedException, AWTException {
		
		Login_Page.userLogin();
		Thread.sleep(5000);
		
		Thread.sleep(3000);


		CreateConfiguration ccp = new CreateConfiguration(StaffpointDriver);

		ccp.clickConfiguration();
		
		Thread.sleep(2000);
		
		ccp.selectRoWCount("100");
		
		Thread.sleep(7000);

		String str1 = "Hassell Ltd - L&L - Australia [R157]";
		String str2 = "Phoenix (Census) [534]";
		//ccp.scrollGrid();
		
		//ccp.getConfigurationValue(str1 , str2);
		  
		ccp.deleteConfigurationValue(str1, str2);
		
		Thread.sleep(3000);
		
		DeleteConfiguration dc = new DeleteConfiguration(StaffpointDriver);
		
		//dc.ConfigDelete();
		
		
	}

	
	
	@Test(priority = 9)
	  public void changeConfigurationError() throws InterruptedException, AWTException {
		
		Login_Page.userLogin();
		
		Thread.sleep(5000);
		
		Thread.sleep(3000);


		CreateConfiguration ccp = new CreateConfiguration(StaffpointDriver);

		ccp.clickConfiguration();
		
		Thread.sleep(2000);
		
		ccp.selectRoWCount("100");
		
		Thread.sleep(7000);

		String str1 = "EXPERIAN SERVICE CORP [835]";
		String str2 = "Singapore (Visa) [552]";
		//ccp.scrollGrid();
		
		//ccp.getConfigurationValue(str1 , str2);
		  
		ccp.editConfigurationValue(str1, str2);
		
			
			ccp.selectConfigHeadcountType("Agent");
			
			Thread.sleep(1000);
			
			ccp.inputAgentProduction("5");
			ccp.inputAgentNesting("5");
			ccp.inputAgentTraining("8");
			ccp.inputConfigFTEDefinition("9");
			ccp.inputTargetPhoneOccupancy("10");
			ccp.inputContractualForecast("20");
			ccp.inputLockedWeeks("5");
			
			//ccp.clickSave();
			
			Thread.sleep(2000);	
	}
	
	@Test(priority = 10)
	  public void detailConfigurationError() throws InterruptedException, AWTException {
		
		Login_Page.userLogin();
		
		Thread.sleep(5000);
		
		Thread.sleep(3000);


		CreateConfiguration ccp = new CreateConfiguration(StaffpointDriver);

		ccp.clickConfiguration();
		
		Thread.sleep(2000);
		
		ccp.selectRoWCount("100");
		
		Thread.sleep(7000);

		String str1 = "EXPERIAN SERVICE CORP [835]";
		String str2 = "Singapore (Visa) [552]";
		//ccp.scrollGrid();
		
		//ccp.getConfigurationValue(str1 , str2);
		  
	ccp.detailConfigurationValue(str1, str2);
		
			
			//ccp.clickSave();
			
			Thread.sleep(2000);	
	}*/
	
	
}