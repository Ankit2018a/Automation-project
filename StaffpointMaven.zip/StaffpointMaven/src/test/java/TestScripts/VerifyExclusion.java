package TestScripts;

import org.testng.AssertJUnit;
import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import exclusion.CreateExclusion;
import pageFactory.Login_Page;
import utility.ExcellData;
import utility.Repositories;
import utility.WriteExcel;


public class VerifyExclusion extends DriverConfig {
	
	
	@Test(priority=1)
	public synchronized void createExclusion() throws Exception {
	
		
		/*
		try {
			getExcell = ExcellData.ExcelData("C:\\Users\\499670\\Desktop\\Staffpoint_testData.xlsx", 0);
			 Thread.sleep(3000);
			System.out.println(getExcell[1][1]);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		//Login_Page lp = new Login_Page();
	  
		Thread.sleep(2000);
		
		Login_Page.userLogin();
		
		Thread.sleep(5000);
		
		Thread.sleep(2000);
		
		CreateExclusion ce = new CreateExclusion(StaffpointDriver);
		
		ce.clickExclusions();
		
		Thread.sleep(7000);
		
		
		ce.newExclusion();
		
		Thread.sleep(5000);
		
		ce.selectExclusionConfiguration(getExcell[1][2]);
		
		
		Thread.sleep(3000);
		
		ce.selectParentClient(getExcell[1][3]);
		
		Thread.sleep(5000);
		
		ce.selectClient(getExcell[1][4]);
		
		Thread.sleep(5000);
		
		ce.selectProgram(getExcell[1][5]);

		Thread.sleep(5000);
		
		ce.selectProject(getExcell[1][6]);
		
		Thread.sleep(5000);
		
		ce.selectRegion(getExcell[1][7]);
		
		Thread.sleep(5000);
		
		ce.selectCountry(getExcell[1][8]);
		
		Thread.sleep(5000);
		
		ce.selectSite(getExcell[1][9]);
	  
		Thread.sleep(3000);
		
		ce.inputRequesterNote(getExcell[1][10]);
		
		Thread.sleep(5000);
		
		ce.exclusionSave();
		*/
		Thread.sleep(6000);
		String[] ar = {"Pass", "Fail", "Pass", "Fail"};
	WriteExcel.writeExcel("C:\\Users\\499670\\Desktop\\Staffpoint_testData.xlsx", "Demo", ar);
		
		
		
		//Test
		
  }/*
	@Test(priority=2)
	public void approveExclusion() throws AWTException, InterruptedException {
		  
		  Login_Page lp = new Login_Page();
		  
		  Thread.sleep(2000);
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);
			
			CreateExclusion ce = new CreateExclusion(StaffpointDriver);
			
			ce.clickExclusions();
			
			Thread.sleep(7000);
			
			JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
			js.executeScript("window.scrollBy(0,250)", "");
	
			
			ce.approveExclusion(getExcell[2][6], getExcell[2][9]);
			
			Thread.sleep(3000);
			
			ce.confirmApproval(getExcell[2][10]);
	
	}
	
	@Test(priority=3)
	public void rejExclusion() throws AWTException, InterruptedException {
		  
		  Login_Page lp = new Login_Page();
		  
		  Thread.sleep(2000);
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);
			
			CreateExclusion ce = new CreateExclusion(StaffpointDriver);
			
			ce.clickExclusions();
			
			Thread.sleep(7000);
			
			JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
			js.executeScript("window.scrollBy(0,450)", "");
			
			ce.rejectExclusion(getExcell[3][6], getExcell[3][9]);
			
			Thread.sleep(3000);
			
			ce.rejectApproval(getExcell[3][10]);	
	
	}
	
	@Test(priority=4)
	public void delExclusion() throws AWTException, InterruptedException {
		  
		  Login_Page lp = new Login_Page();
			
		  Thread.sleep(2000);
		  
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);
			
			CreateExclusion ce = new CreateExclusion(StaffpointDriver);
			
			ce.clickExclusions();
			
			Thread.sleep(7000);
			
			ce.deleteExclusion(getExcell[4][6], getExcell[4][9]);
			
			Thread.sleep(3000);
			
			ce.deleteConfirm();
	
	}
	
	@Test(priority=5)
	public void exclusionMessageVerify() throws AWTException, InterruptedException {
	
		  Login_Page lp = new Login_Page();
		  
		  Thread.sleep(2000);
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);
			
			CreateExclusion ce = new CreateExclusion(StaffpointDriver);
			
			ce.clickExclusions();
			
			Thread.sleep(7000);
			
			ce.newExclusion();
			
			Thread.sleep(5000);
			
			ce.selectExclusionConfiguration(getExcell[5][2]);
			
			Thread.sleep(3000);
			
			ce.selectParentClient(getExcell[5][3]);
			
			Thread.sleep(3000);
			
			ce.selectClient(getExcell[5][4]);
			
			Thread.sleep(3000);
			
			ce.selectProgram(getExcell[5][5]);

			Thread.sleep(3000);
			
			ce.selectProject(getExcell[5][6]);
			
			Thread.sleep(3000);
			
			ce.selectRegion(getExcell[5][7]);
			
			Thread.sleep(3000);
			
			ce.selectCountry(getExcell[5][8]);
			
			Thread.sleep(3000);
			
			ce.selectSite(getExcell[5][9]);
		  
			Thread.sleep(3000);
			
			ce.inputRequesterNote(getExcell[5][10]);
			
			Thread.sleep(2000);
			
			ce.exclusionSave();
			
			Thread.sleep(3000);
			
			WebElement ele = StaffpointDriver.findElement(By.xpath("//label[@id='dialogText']"));
			
			System.out.println(ele.getText());
			
			String Allready_Exclusion = "There is already scope exclusion created for "
					+ "this LOB. Please select different LOB for exclusion";
			
			AssertJUnit.assertEquals(ele.getText().trim(), Allready_Exclusion.trim());
	}
	@Test(priority=7)
	public void exclusionNotEditable() throws AWTException, InterruptedException {
	
		  
		  Login_Page lp = new Login_Page();
		  
		  Thread.sleep(2000);
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);
			
			CreateExclusion ce = new CreateExclusion(StaffpointDriver);
			
			ce.clickExclusions();
			
			Thread.sleep(7000);
			
			ce.editExclusion(getExcell[6][6], getExcell[6][9]);
			
			
			try{
	ce.editExclusion("1 wealth street - l&l - us", "Ghana");
			}	
	catch(Exception e){
	System.out.println(e.getMessage());	
	}
	}
	
	public void detailLink_Confirm() throws AWTException, InterruptedException {
	
		  
		  Login_Page lp = new Login_Page();
		  
		  Thread.sleep(2000);
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);
			
			CreateExclusion ce = new CreateExclusion(StaffpointDriver);
			
			ce.clickExclusions();
			
			Thread.sleep(7000);
			
			JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
			js.executeScript("window.scrollBy(0,450)", "");
			
			ce.detailExclusion(getExcell[7][6], getExcell[7][9]);
			
			Thread.sleep(2000);
			
			ce.confirmApproval(getExcell[7][10]);
			
	}
	@Test(priority=8)
	public void detailLink_Reject() throws AWTException, InterruptedException {
	
		  
		  Login_Page lp = new Login_Page();
		  
		  Thread.sleep(2000);
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);
			
			CreateExclusion ce = new CreateExclusion(StaffpointDriver);
			
			ce.clickExclusions();
			
			Thread.sleep(7000);
			
			JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
			js.executeScript("window.scrollBy(0,450)", "");
			
			ce.detailExclusion(getExcell[8][6], getExcell[8][9]);
			
			Thread.sleep(2000);
			
			ce.rejectApproval(getExcell[8][10]);
		
	}*/
	}
