package TestScripts;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import StaticPages.TabularBarPage;
import pageFactory.ConfigurationPage;
import pageFactory.HomePage;
import pageFactory.Login_Page;
import pageFactory.PlanningPage;
import utility.Repositories;

public class VerifyPlan {

	public static void main(String[] args) throws Throwable, Exception{

		WebDriver StaffpointDriver = null;
		DesiredCapabilities capabilities=null;
		ChromeOptions options=null;
		JavascriptExecutor js=null;
		// String str="ABCD";


		//Configuring Chrome Options to Enable Automation extension in Chrome

		options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_settings.popups", 0);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.setExperimentalOption("excludeSwitches", Arrays.asList("enable-automation"));
		options.addArguments("start-maximized");
		options.addArguments("ash-debug-shortcuts");
		options.addArguments("ash-dev-shortcuts");

		//Chrome Option is Passed to Desired Capabilities to make driver Compatible

		capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		int count = 0;

		System.out.println(capabilities.isJavascriptEnabled());
		System.out.println(capabilities.getCapability(ChromeOptions.CAPABILITY));



		// 

		while(count==0){
			try{
				System.setProperty(Repositories.getChromeProperty(), Repositories.getChromePath());
				StaffpointDriver = new ChromeDriver(capabilities);
				count++;
			}

			catch(Exception e){
				e.printStackTrace();

			}	
			System.out.println(options.toJson());

		}

		try{

			StaffpointDriver.get("http://usvia-stfptq02/Staffpoint.WebDev/");

			//dvr.get("https://www.google.com");
		}
		catch(Exception e){
			e.printStackTrace();

		}	

/*
		 
		Login_Page.userLogin();
		Thread.sleep(5000);
		
		PlanningPage home=null;
		
		 Thread.sleep(25000);
		
	  try{
		  
		 TabularBarPage Tabularbar = new TabularBarPage(StaffpointDriver);
		 home = new PlanningPage(StaffpointDriver);	
		 
		 Thread.sleep(10000);
		 Tabularbar.clickPlanning(); 
	  }
		/*
		 System.out.println("check1");
		 
	  }
	  catch(Exception e){
		  System.out.println(e.getMessage());
	  }
	  
		 System.out.println("check2");
		Thread.sleep(2000);
		
		String Data_Operations_Vp = "ANDERSON SCOTT [123865]";
		try{
			home.selectOperationVp(Data_Operations_Vp);
			
			Thread.sleep(3000);
			
			String Data_ParentClient = "24/7 Inc. [11727]";
			
			home.selectParentClient(Data_ParentClient);
			
			Thread.sleep(3000);

			home.submitPlan();
			
			PlanningRecomendation Prp = new PlanningRecomendation(StaffpointDriver);
			
			Thread.sleep(3000);
			
			
			Prp.clickRecomendations();
			
			 js = (JavascriptExecutor)StaffpointDriver;
			
			js.executeScript("scroll(0,250);");
			
			Thread.sleep(2000);
			
			Prp.makeTrainingMetricVisible();
			
			Thread.sleep(2000);
			
			Prp.makeTrainingMetricClose();
			
			Thread.sleep(2000);
			
			Prp.makeTrainingMetricVisible();
			
			Thread.sleep(2000);
			
			Prp.getNHC_Max_Graduating("metricGrid_Week1");
			
			Thread.sleep(2000);
			
			js.executeScript("scroll(0,750);");
			
			Thread.sleep(2000);
			
			Prp.selectMonth("Jan-18");
			
			Prp.makeATOMetricVisible();
			
			Thread.sleep(2000);
			
			Prp.makeATOMetricClose();
			
			Thread.sleep(2000);
			
			Prp.makeATOMetricVisible();
			
			Prp.getATO_Acceptable_Overstaffing("metricGrid_Week1");
			
				
			//String Input_Faovorite_Name="Jamaica";
			
			//home.secondCancelFavorite(Input_Faovorite_Name);
			
			}
			
				
		
		  catch(Exception e){
			  e.printStackTrace();
		  }
		  
		//System.out.println(str);
		
	
	  
		System.out.println("Check 3");
	 
		Thread.sleep(2000);
		
	*/
	
	//js.executeScript("scroll(0,750);");
	
	
	/*
	Thread.sleep(2000);
	
	
	ccp.newConfig();
	
	Thread.sleep(2000);

	ccp.selectConfigProject("ABB Limited - L&L - Australia [R608]");
	
	Thread.sleep(1000);
	
	ccp.selectConfigSite("Agent At Home - Healthcare [408]");
	
	Thread.sleep(1000);
	
	ccp.selectConfigHeadcountType("Agent");
	
	Thread.sleep(1000);
	
	ccp.inputAgentProduction("4");
	ccp.inputAgentNesting("3");
	ccp.inputAgentTraining("7");
	ccp.inputConfigFTEDefinition("3");
	//ccp.inputTargetPhoneOccupancy("6");
	ccp.inputContractualForecast("2");
	ccp.inputLockedWeeks("2");
	
	ccp.clickSave();
	
	ccp.selectConfigFirstDayOfWeek("Tuesday");
	
	ArrayList<String> err_List = ccp.errorValidation();
	
    java.util.Iterator<String> itr =err_List.iterator();
    
    while(itr.hasNext())
    {
    	System.out.println(itr.next());
    }


*/	
	Login_Page.userLogin();
	Thread.sleep(5000);
	
	Thread.sleep(3000);




	
	}
	 
	}
	

		
	


