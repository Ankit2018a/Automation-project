package TestScripts;

import org.testng.annotations.Test;

import StaticPages.TabularBarPage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.AssertJUnit;
import java.awt.AWTException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import org.testng.annotations.Test;

import pageFactory.HomePage;
import pageFactory.Login_Page;
import pageFactory.OfficializePlan;
import pageFactory.PlanningPage;
import plan.PlanNextPage;


public class HomeScripts extends DriverConfig{
	
	//private static final char[] OP_Vp = null;

	HomePage hp= null;
	
	PlanningPage pp = null;
	
	Login_Page lp= null;
	
  @Test(priority=1)
  public void tabVerify() throws InterruptedException, AWTException {
	  
	  Login_Page lp = new Login_Page();
	  
	  lp.userLogin();
	  
	  hp = new HomePage(StaffpointDriver);
	  
	  Thread.sleep(4000);
	  
	  hp.clickPlanning();
	  
	  Thread.sleep(4000);

	  hp.clickConfiguration();
	  
	  Thread.sleep(4000);
	  
	  hp.clickAccount();
	  
	  Thread.sleep(7000);
	  
	  hp.clickExclusions();
	  
	  Thread.sleep(6000);
	  
	  hp.clickAboutUs();
	  
	  Thread.sleep(6000);  
	  
  }


  @Test(priority=2)
  public void favoriteVerify() throws InterruptedException, AWTException{
	
  lp = new Login_Page();
	  
	  lp.userLogin();
	  
	  hp = new HomePage(StaffpointDriver);
	  
	  
	  Thread.sleep(5000);
	  
	  hp.clickHome();
	  
	  Thread.sleep(5000);
	  
	  String Operation_VP = "COMBS DARLA";
	  
	  String Project = "American Red Cross - Hurricane Irene";
	  
	  String Site = "Plovdiv Bulgaria"; 
	  
	 String OP_Vp= null; 
	 String proj = null;
	 String site = null;
	 
	OP_Vp = hp.getFavoritesOperationsVP(Operation_VP);
	
	proj= hp.getFavoritesProject(Project);
	
	site = hp.getFavoritesSite(Site);
	//System.out.println(OP_Vp);
	
	 Assert.assertEquals(proj,Project );

	 Assert.assertEquals(site,Site);
	 
	 //Assert.assertEquals(actual, expected);
	 
  }


	@Test(priority=3)
	public void favoriteDelete() throws InterruptedException, AWTException{
		
		 lp = new Login_Page();
		  
		  lp.userLogin();
		  
		  hp = new HomePage(StaffpointDriver);
		  
		  
		  Thread.sleep(5000);
		  
		  hp.clickHome();
		  
		  Thread.sleep(5000);
		
		hp.deletefavorite("American Red Cross - Hurricane Irene", "Plovdiv Bulgaria");
		
		String delete_Msg =	StaffpointDriver.findElement(By.xpath("//label[@id='dialogConfirmText']")).getText();
		
		System.out.println(delete_Msg);
		
		Assert.assertEquals(delete_Msg, "Are you sure you want to delete this favorite?" , "The following given Record is deleted");
		
		//StaffpointDriver.findElement(By.xpath("//span[@class='ui-button-text'][text()='Ok']")).click();
		
		
	}
	
	
	@Test(priority=4)
	public void favoriteView() throws AWTException, InterruptedException{

		 lp = new Login_Page();
		  
		  lp.userLogin();
		  
		  hp = new HomePage(StaffpointDriver);
		  
		  
		  Thread.sleep(5000);
		  
		  hp.clickHome();
		  
		  Thread.sleep(5000);
		  
		ArrayList<String> al1 = new ArrayList<String>();  
		
		  al1 = hp.viewLOBfavorite("24/7 Inc.", "Percepta Italy");
	
		  hp.viewfavorite("24/7 Inc.", "Percepta Italy");
		  
		  
		  
		  for(String str2:al1){
			  
			  System.out.println(str2);
		  }
		  
		  Thread.sleep(3000);
	
		 	Assert.assertTrue(al1.contains("24/7 Inc."));
			
		 	Assert.assertTrue(al1.contains("Percepta Italy"));
			
		}

	
	
	@Test(priority=5)
	public void addfavorite() throws AWTException, InterruptedException{
	
		 lp = new Login_Page();
		  
		  lp.userLogin();
		  
		Thread.sleep(4000);
		  
		 pp = new PlanningPage(StaffpointDriver);	
		 
		 Thread.sleep(3000);
		 pp.clickPlanning(); 
	  
		 System.out.println("check1");
		 
		 System.out.println("check2");
		 Thread.sleep(2000);
		
		String Data_Operations_Vp = "COMBS DARLA [1487783]";
		
			pp.selectOperationVp(Data_Operations_Vp);
			
			Thread.sleep(3000);
			
			String Data_Start_Date = "17";
			
			String Data_ParentClient = "AMERICAN RED CROSS [10232]";
			
			String Data_Client = "American Red Cross - Hurricane Irene [0014]";
			
			String Data_program = "American Red Cross - Hurricane Irene [0014]";
			
			String Data_project = "American Red Cross - Hurricane Irene [0014]";
			
			String Data_region = "Europe [EUR]";
			
			String Data_Country = "Bulgaria [BG]";
			
			String Data_Site = "Plovdiv, Bulgaria [347]";
			
			String Data_EndDate = "19";
			
			String Project_Valid= "American Red Cross - Hurricane Irene";
					
			String Site_Valid	= "Plovdiv Bulgaria";
			
			pp.selectStartDate(Data_Start_Date);
			
			Thread.sleep(3000);
			
			pp.selectEndDate(Data_EndDate);
			
			Thread.sleep(2000);
			
			pp.selectParentClient(Data_ParentClient);
			
			Thread.sleep(4000);
			
			pp.selectClient(Data_Client);
			
			Thread.sleep(3000);
			
			pp.selectProgram(Data_program);
			
			Thread.sleep(2000);
			
			pp.selectProject(Data_project);
			
			Thread.sleep(2000);
			
			pp.selectRegion(Data_region);
			
			Thread.sleep(2000);
			
			pp.selectCountry(Data_Country);
			
			Thread.sleep(2000);

			pp.selectSite(Data_Site);
			
			Thread.sleep(2000);
			
			pp.submitFavorite("Ashes");
			
			pp.clickHome();
		
			Thread.sleep(3000);
			
			HomePage hp = new HomePage(StaffpointDriver);
			//String str[] = new String[8];  
			
			
			JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
			
			js.executeScript("window.scrollBy(0,500)");
			
			Thread.sleep(2000);
			
			ArrayList<String> al1 = new ArrayList<String>();
			
			  al1 =hp.viewLOBfavorite(Project_Valid, Site_Valid);
			  
			for(String str:al1){
				System.out.println(str);
			}
				  
			  }	  
	
	
	@Test(priority=6)
	public void getScenarioColm() throws AWTException, InterruptedException{
	
		ArrayList<String> al = new ArrayList();
		
		 lp = new Login_Page();
		  
		 lp.userLogin();
		  
		Thread.sleep(5000);
		
		HomePage hp = new HomePage(StaffpointDriver);
		
		JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
		
		js.executeScript("window.scrollBy(0,500)");
	
		al = hp.scenarioColumns();

		Assert.assertTrue(al.contains("Actions"));
		Assert.assertTrue(al.contains("Name"));
		Assert.assertTrue(al.contains("Created Date"));
		Assert.assertTrue(al.contains("Created By"));
		Assert.assertTrue(al.contains("Operations VP"));
		Assert.assertTrue(al.contains("Parent Client"));
		Assert.assertTrue(al.contains("Client"));
		Assert.assertTrue(al.contains("Program"));
		Assert.assertTrue(al.contains("Project"));
		Assert.assertTrue(al.contains("Country"));
		Assert.assertTrue(al.contains("Site"));
			
	}
	
	@Test(priority=7)
	public void getScenarioView() throws AWTException, InterruptedException{
		
		 lp = new Login_Page();
		  
		 lp.userLogin();
		  
		Thread.sleep(6000);
		
		JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
		
		js.executeScript("window.scrollBy(0,500)");
		
		HomePage hp = new HomePage(StaffpointDriver);
		
		String Simul_project = "Best Buy Geek Sq Concierge";
		
		String Simul_site = "Bacoor, PHI";
		
		ArrayList<String> viewLob = new ArrayList(); 
		
		viewLob = hp.viewLOBSimulation(Simul_project, Simul_site);
		
		for(String lob:	viewLob){
			System.out.println(lob);
		}
		
		hp.viewSimulation(Simul_project, Simul_site);
		
		System.out.println("check71");
		
		Thread.sleep(7000);
		
		PlanNextPage pnp = new PlanNextPage(StaffpointDriver);
		
		Thread.sleep(6000);
		
		ArrayList<String> verifyLob = new ArrayList();
		verifyLob = pnp.verifyLob();
		
		for(String lob:	verifyLob){
			System.out.println(lob);
		}
		
		System.out.println(!Collections.disjoint(viewLob,verifyLob));
		
		
	}

	
	@Test(priority=8)
	public void getPlanView() throws AWTException, InterruptedException{
	
		 lp = new Login_Page();
		  
		 lp.userLogin();
		  
		Thread.sleep(5000);
		
		HomePage hp = new HomePage(StaffpointDriver);
		
		String Plan_project = "2020 Exchange - L&L - Australia [R823]";
		
		String Plan_site = "Plovdiv, Bulgaria [347]";

		ArrayList<String> viewLobPlan = new ArrayList();
		
		viewLobPlan = hp.viewLOBPlan(Plan_project, Plan_site);
		
		hp.viewPlan(Plan_project, Plan_site);
		
		Thread.sleep(7000);
		
		PlanNextPage pnp = new PlanNextPage(StaffpointDriver);
		
		Thread.sleep(6000);
		
		ArrayList<String> verifyLob = new ArrayList();
		verifyLob = pnp.verifyLob();
		
		
		System.out.println(!Collections.disjoint(viewLobPlan,verifyLob));
		
		
	}
	
	
	@Test(priority=9)
	public void getPlanNonCompliance() throws AWTException, InterruptedException, ParseException{
		 
		lp = new Login_Page();
		  
		 lp.userLogin();
		  
		Thread.sleep(7000);
		
		HomePage hp = new HomePage(StaffpointDriver);
		
		String Plan_project = "21st Century Fox - L&L Australia [RC04]";
		
		String Plan_site = "PRG Luxembourg Holding SARL [257]";
		
		String Date_Valid = hp.viewPlanModificationDate(Plan_project, Plan_site);
		
		Date d1 = new Date();
		
		Date d2 = new Date(Date_Valid);
		
		//SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		//d2 = format.parse(Date_Valid);
		
		System.out.println(d1);
		System.out.println(d2);
		
	        int diffInDays = (int) ((d1.getTime() - d2.getTime()) / (1000 * 60 * 60 * 24));
		
	        System.out.println(diffInDays);
	        
	        String Complaince_Actual = hp.viewPlanComplaince(Plan_project, Plan_site);
	        
	        String Complaince_Expected	= hp.validationPlanComplaince(diffInDays);
	        
	        Assert.assertEquals(Complaince_Actual,Complaince_Expected,"The Value is getting correctly for Non Complaince PLan" );
			
	}	



	
	@Test(priority=10)
	public void getPlanCompliance() throws AWTException, InterruptedException, ParseException{
		 
		lp = new Login_Page();
		  
		 lp.userLogin();
		  
		Thread.sleep(7000);
		
		HomePage hp = new HomePage(StaffpointDriver);
		
		String Plan_project = "2020 Exchange - L&L - Australia [R823]";
		
		String Plan_site = "Plovdiv, Bulgaria [347]";
		
		String Date_Valid = hp.viewPlanModificationDate(Plan_project, Plan_site);
		
		Date d1 = new Date();
		
		Date d2 = new Date(Date_Valid);
		
		//SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		//d2 = format.parse(Date_Valid);
		
		System.out.println(d1);
		System.out.println(d2);
		
	        int diffInDays = (int) ((d1.getTime() - d2.getTime()) / (1000 * 60 * 60 * 24));
		
	        System.out.println(diffInDays);
	        
	        String Complaince_Actual = hp.viewPlanComplaince(Plan_project, Plan_site);
	        
	        String Complaince_Expected	= hp.validationPlanComplaince(diffInDays);
	        
	        Assert.assertEquals(Complaince_Actual,Complaince_Expected,"The Value is getting correctly for Complaince PLan" );
			
	}	

/*

@Test(priority=1)
public void getPlanCaution() throws AWTException, InterruptedException, ParseException{
	 
	lp = new Login_Page();
	  
	 lp.userLogin();
	  
	Thread.sleep(7000);
	
	HomePage hp = new HomePage(StaffpointDriver);
	
	String Plan_project = "EXPERIAN SERVICE CORP [835]";
	
	String Plan_site = "Singapore (Visa)";
	
	String Date_Valid = hp.viewPlanModificationDate(Plan_project, Plan_site);
	
	Date d1 = new Date();
	
	Date d2 = new Date(Date_Valid);
	
	//SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
	//d2 = format.parse(Date_Valid);
	
	System.out.println(d1);
	System.out.println(d2);
	
        int diffInDays = (int) ((d1.getTime() - d2.getTime()) / (1000 * 60 * 60 * 24));
	
        System.out.println(diffInDays);
        
        String Complaince_Actual = hp.viewPlanComplaince(Plan_project, Plan_site);
        
        String Complaince_Expected	= hp.validationPlanComplaince(diffInDays);
        
        Assert.assertEquals(Complaince_Actual,Complaince_Expected,"The Value is getting correctly for Complaince PLan" );
		
}	*/

	@Test(priority=11)
	public void createPlan() throws AWTException, InterruptedException, ParseException{
		 
		lp = new Login_Page();
		  
		 lp.userLogin();
		  
		Thread.sleep(7000);
		
		OfficializePlan pp = new OfficializePlan(StaffpointDriver);	
		 
		 Thread.sleep(3000);
		 pp.clickOfficialPlanning(); 
	  
		 System.out.println("check1");
		 
		 System.out.println("check2");
		 Thread.sleep(2000);
		
		//String Data_Operations_Vp = "COMBS DARLA [1487783]";
		
			//pp.selectOperationVp(Data_Operations_Vp);
			
			Thread.sleep(3000);
			
			String Data_Start_Date = "6";
			
			String Data_ParentClient = "2020 Exchange [12052]";
			
			String Data_Client = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_program = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_project = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_region = "Europe [EUR]";
			
			String Data_Country = "Bulgaria [BG]";
			
			String Data_Site = "Plovdiv, Bulgaria [347]";
			
			String Data_EndDate = "15";
			
			String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
					
			String Site_Valid	= "Plovdiv, Bulgaria";
			
			pp.selectStartDate(Data_Start_Date);
			
			Thread.sleep(3000);
			
			pp.selectEndDate(Data_EndDate);
			
			Thread.sleep(3000);
			
			pp.selectParentClient(Data_ParentClient);
			
			Thread.sleep(4000);
			
			pp.selectClient(Data_Client);
			
			Thread.sleep(4000);
			
			pp.selectProgram(Data_program);
			
			Thread.sleep(4000);
			
			pp.selectProject(Data_project);
			
			Thread.sleep(4000);
			
			pp.selectRegion(Data_region);
			
			Thread.sleep(4000);
			
			pp.selectCountry(Data_Country);
			
			Thread.sleep(4000);

			pp.selectSite(Data_Site);
			
			Thread.sleep(4000);
			
			pp.viewPlan();
			
			Thread.sleep(6000);
			
			pp.approvePlan();
			
			Thread.sleep(5000);
			
		/*
		
		//String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
		
		//String Site_Valid	= "Plovdiv, Bulgaria";
		
		
			HomePage hp = new HomePage(StaffpointDriver);
			//String str[] = new String[8];  
			
			
			
			Thread.sleep(2000);
			
			ArrayList<String> al = new ArrayList();
			
			al =hp.viewLOBPlan(Project_Valid, Site_Valid);

			for(String str1: al){
				System.out.println(str1);
			}

			Assert.assertTrue(al.contains(Project_Valid));
			
			Assert.assertTrue(al.contains(Site_Valid));*/
	
	}
}
			


