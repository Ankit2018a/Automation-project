package TestScripts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import utility.ExcellData;
import utility.Repositories;

public class DriverConfig {

	WebDriver StaffpointDriver = null;
	DesiredCapabilities capabilities=null;
	ChromeOptions options=null;
	String[][] getExcell = null;
	
	
	@BeforeMethod
	public synchronized void beforeMethod() throws IOException, JSONException {

		 /* ExtentReports extent;
		  
		  extent = new ExtentReports (System.getProperty("user.dir") +"/test-output/STMExtentReport.html", true);
		//Configuring Chrome Options to Enable Automation extension in Chrome
*/
		options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_settings.popups", 0);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.setExperimentalOption("excludeSwitches", Arrays.asList("enable-automation"));
		options.addArguments("start-maximized");
		options.addArguments("ash-debug-shortcuts");
		options.addArguments("ash-dev-shortcuts");

		//Chrome Option is Passed to Desired Capabilities to make driver Compatible

		capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		int count = 0;

		System.out.println(capabilities.isJavascriptEnabled());
		System.out.println(capabilities.getCapability(ChromeOptions.CAPABILITY));



		// 

		while(count==0){
			try{
				System.setProperty(Repositories.getChromeProperty(), Repositories.getChromePath());
				StaffpointDriver = new ChromeDriver(capabilities);
				count++;
			}

			catch(Exception e){
				e.printStackTrace();

			}	
			System.out.println(options.toJson());

		}

		try{

			StaffpointDriver.get(Repositories.getURL());

			//dvr.get("https://www.google.com");
		}
		catch(Exception e){
			e.printStackTrace();

		}	

	}

	@AfterMethod
	public void afterMethod() {

		//StaffpointDriver.quit();
	}

}
