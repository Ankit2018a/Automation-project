package TestScripts;

import java.awt.AWTException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import officialization.DeleteOfficialization;
import pageFactory.HomePage;
import pageFactory.Login_Page;
import pageFactory.OfficializePlan;

public class VerifyOfficialization extends DriverConfig {
  
	
	@Test(priority=1)
  public void verifyOfficialization() throws AWTException, InterruptedException {
  
		
		Login_Page lp = new Login_Page();
		  
		 lp.userLogin();
		  
		Thread.sleep(7000);
		
		OfficializePlan pp = new OfficializePlan(StaffpointDriver);	
		 
		 Thread.sleep(3000);
		 pp.clickOfficialPlanning(); 
	  
		 System.out.println("check1");
		 
		 System.out.println("check2");
		 
		 Thread.sleep(2000);
		
		//String Data_Operations_Vp = "COMBS DARLA [1487783]";
		
			//pp.selectOperationVp(Data_Operations_Vp);
			
			Thread.sleep(3000);
			
			String Data_Start_Date = "6";
			
			String Data_ParentClient = "2020 Exchange [12052]";
			
			String Data_Client = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_program = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_project = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_region = "Europe [EUR]";
			
			String Data_Country = "Bulgaria [BG]";
			
			String Data_Site = "Plovdiv, Bulgaria [347]";
			
			String Data_EndDate = "15";
			
			String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
					
			String Site_Valid	= "Plovdiv, Bulgaria";
			
			pp.selectStartDate(Data_Start_Date);
			
			Thread.sleep(3000);
			
			pp.selectEndDate(Data_EndDate);
			
			Thread.sleep(3000);
			
			pp.selectParentClient(Data_ParentClient);
			
			Thread.sleep(4000);
			
			pp.selectClient(Data_Client);
			
			Thread.sleep(4000);
			
			pp.selectProgram(Data_program);
			
			Thread.sleep(4000);
			
			pp.selectProject(Data_project);
			
			Thread.sleep(4000);
			
			pp.selectRegion(Data_region);
			
			Thread.sleep(4000);
			
			pp.selectCountry(Data_Country);
			
			Thread.sleep(4000);

			pp.selectSite(Data_Site);
			
			Thread.sleep(4000);
			
			pp.viewPlan();
			
			Thread.sleep(6000);
			
			pp.approvePlan();
			
			Thread.sleep(3000);
		
			pp.exclusionMsg();
			
			Thread.sleep(10000);
			
			pp.approvalConfirm();
			
			Thread.sleep(2000);
			
			pp.clickBreakdown();
			
			pp.selectMonth("Feb-18");
			
			
		}
	
	@Test(priority=2)
	  public void verifyOfficialPlan() throws AWTException, InterruptedException {
	  
			
			Login_Page lp = new Login_Page();
			  
			 lp.userLogin();
			  
			Thread.sleep(7000);
			
			String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
			
			String Site_Valid = "Plovdiv, Bulgaria";
			
			
				HomePage hp = new HomePage(StaffpointDriver);
				//String str[] = new String[8];  
				
				
				
				Thread.sleep(2000);
				
				ArrayList<String> al = new ArrayList();
				
				al =hp.viewLOBPlan(Project_Valid, Site_Valid);

				for(String str1: al){
					System.out.println(str1);
				}

				Assert.assertTrue(al.contains(Project_Valid));
				
				Assert.assertTrue(al.contains(Site_Valid));
			
	}
	
	/*
  
  	@Test(priority=3)
  public void deleteOfficialization() throws AWTException, InterruptedException {
	  
		
		Login_Page lp = new Login_Page();
		  
		 lp.userLogin();
		  
		Thread.sleep(7000);
		
		DeleteOfficialization pp = new DeleteOfficialization(StaffpointDriver);	
		 
		 Thread.sleep(3000);
		 
		 pp.clickOfficialPlanning(); 
		 
		 Thread.sleep(2000);
		 
		pp.deleteOfficialization();
	  
		 System.out.println("check1");
		 
		 System.out.println("check2");
		 
		 Thread.sleep(2000);
		
		//String Data_Operations_Vp = "COMBS DARLA [1487783]";
		
			//pp.selectOperationVp(Data_Operations_Vp);
			
			Thread.sleep(3000);
			
			String Data_Start_Date = "6";
			
			String Data_ParentClient = "2020 Exchange [12052]";
			
			String Data_Client = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_program = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_project = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_region = "Europe [EUR]";
			
			String Data_Country = "Bulgaria [BG]";
			
			String Data_Site = "Plovdiv, Bulgaria [347]";
			
			String Data_EndDate = "15";
			
			String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
					
			String Site_Valid	= "Plovdiv, Bulgaria";
			
			pp.selectStartDate(Data_Start_Date);
			
			Thread.sleep(3000);
			
			pp.selectEndDate(Data_EndDate);
			
			Thread.sleep(3000);
			
			pp.selectParentClient(Data_ParentClient);
			
			Thread.sleep(4000);
			
			pp.selectClient(Data_Client);
			
			Thread.sleep(4000);
			
			pp.selectProgram(Data_program);
			
			Thread.sleep(4000);
			
			pp.selectProject(Data_project);
			
			Thread.sleep(4000);
			
			pp.selectRegion(Data_region);
			
			Thread.sleep(4000);
			
			pp.selectCountry(Data_Country);
			
			Thread.sleep(4000);

			pp.selectSite(Data_Site);
			
			Thread.sleep(4000);
			
			pp.deletePlan();
	
			
		}
	*/
 	@Test(priority=3)
  public void favoriteOfficialization() throws AWTException, InterruptedException {
	  
 		
		Login_Page lp = new Login_Page();
		  
		 lp.userLogin();
		  
		Thread.sleep(7000);
		
		OfficializePlan pp = new OfficializePlan(StaffpointDriver);	
		 
		 Thread.sleep(3000);
		 pp.clickOfficialPlanning(); 
	  
		 System.out.println("check1");
		 
		 System.out.println("check2");
		 
		 Thread.sleep(3000);
		
		//String Data_Operations_Vp = "COMBS DARLA [1487783]";
		
			//pp.selectOperationVp(Data_Operations_Vp);
			
			Thread.sleep(3000);
			
			String Data_Start_Date = "6";
			
			String Data_ParentClient = "2020 Exchange [12052]";
			
			String Data_Client = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_program = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_project = "2020 Exchange - L&L - Australia [R823]";
			
			String Data_region = "Europe [EUR]";
			
			String Data_Country = "Bulgaria [BG]";
			
			String Data_Site = "Plovdiv, Bulgaria [347]";
			
			String Data_EndDate = "15";
			
			String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
					
			String Site_Valid	= "Plovdiv, Bulgaria";
			
			pp.selectStartDate(Data_Start_Date);
			
			Thread.sleep(3000);
			
			pp.selectEndDate(Data_EndDate);
			
			Thread.sleep(3000);
			
			pp.selectParentClient(Data_ParentClient);
			
			Thread.sleep(4000);
			
			pp.selectClient(Data_Client);
			
			Thread.sleep(4000);
			
			pp.selectProgram(Data_program);
			
			Thread.sleep(4000);
			
			pp.selectProject(Data_project);
			
			Thread.sleep(4000);
			
			pp.selectRegion(Data_region);
			
			Thread.sleep(4000);
			
			pp.selectCountry(Data_Country);
			
			Thread.sleep(4000);

			pp.selectSite(Data_Site);
			
			Thread.sleep(4000);
			
			pp.submitFavorite("Balistic miscile");
  
  }
	
 	@Test(priority=4)
	  public void favoriteverify() throws AWTException, InterruptedException {
		  
	 		
			Login_Page lp = new Login_Page();
			  
			 lp.userLogin();
			  
			Thread.sleep(7000);
			
			OfficializePlan pp = new OfficializePlan(StaffpointDriver);	
			 
			 Thread.sleep(3000);
			 pp.clickOfficialPlanning(); 
			 
			 Thread.sleep(2000);
			 
			 pp.viewFavPlanning();
			 
			 Thread.sleep(5000);
			 
			 pp.selectRoWCount("100");
			 
			 Thread.sleep(6000);
			 
			 pp.viewFav("USAA Credit Card Services", "Springfield MO");
		  
		
 	
 	}
 	
	@Test(priority=5)
	  public void verifyPlanNoExclusion() throws AWTException, InterruptedException {
	  
			
			Login_Page lp = new Login_Page();
			  
			 lp.userLogin();
			  
			Thread.sleep(7000);
			
			OfficializePlan pp = new OfficializePlan(StaffpointDriver);	
			 
			 Thread.sleep(3000);
			 pp.clickOfficialPlanning(); 
		  
			 System.out.println("check1");
			 
			 System.out.println("check2");
			 
			 Thread.sleep(2000);
			
			//String Data_Operations_Vp = "COMBS DARLA [1487783]";
			
				//pp.selectOperationVp(Data_Operations_Vp);
				
				Thread.sleep(3000);
				
				String Data_Start_Date = "6";
				
				String Data_ParentClient = "2020 Exchange [12052]";
				
				String Data_Client = "2020 Exchange - L&L - Australia [R823]";
				
				String Data_program = "2020 Exchange - L&L - Australia [R823]";
				
				String Data_project = "2020 Exchange - L&L - Australia [R823]";
				
				String Data_region = "Europe [EUR]";
				
				String Data_Country = "Bulgaria [BG]";
				
				String Data_Site = "Plovdiv, Bulgaria [347]";
				
				String Data_EndDate = "15";
				
				String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
						
				String Site_Valid	= "Plovdiv, Bulgaria";
				
				pp.selectStartDate(Data_Start_Date);
				
				Thread.sleep(3000);
				
				pp.selectEndDate(Data_EndDate);
				
				Thread.sleep(3000);
				
				pp.selectParentClient(Data_ParentClient);
				
				Thread.sleep(4000);
				
				pp.selectClient(Data_Client);
				
				Thread.sleep(4000);
				
				pp.selectProgram(Data_program);
				
				Thread.sleep(4000);
				
				pp.selectProject(Data_project);
				
				Thread.sleep(4000);
				
				pp.selectRegion(Data_region);
				
				Thread.sleep(4000);
				
				pp.selectCountry(Data_Country);
				
				Thread.sleep(4000);

				pp.selectSite(Data_Site);
				
				Thread.sleep(4000);
				
				pp.viewPlan();
				
				Thread.sleep(6000);
				
				pp.approvePlan();
				
				Thread.sleep(3000);
				

	WebElement ele = StaffpointDriver.findElement(By.xpath("//label[@id='dialogText']"));
	
	System.out.println(ele.getText());
	
	String Exclusion_msg = "No Exclusions found for this Plan. Please click OK to save.";
		Assert.assertEquals(ele.getText().trim(), Exclusion_msg.trim());
	
	}
	
	@Test(priority=6)
	  public void verifyPlanWithExclusion() throws AWTException, InterruptedException {
	  
			
			Login_Page lp = new Login_Page();
			  
			 lp.userLogin();
			  
			Thread.sleep(7000);
			
			OfficializePlan pp = new OfficializePlan(StaffpointDriver);	
			 
			 Thread.sleep(3000);
			 pp.clickOfficialPlanning(); 
		  
			 System.out.println("check1");
			 
			 System.out.println("check2");
			 
			 Thread.sleep(2000);
			
			//String Data_Operations_Vp = "COMBS DARLA [1487783]";
			
				//pp.selectOperationVp(Data_Operations_Vp);
				
				Thread.sleep(3000);
				
				String Data_Start_Date = "6";
				
				String Data_ParentClient = "1-800-Accountant [11205]";
				
				String Data_Client = "1-800-Accountant - WM [6883]";
				
				String Data_program = "1-800-Accountant - WM [6883]";
				
				String Data_project = "1-800-Accountant - WM [6883]";
				
				String Data_region = "Central America [CAMR]";
				
				String Data_Country = "Costa Rica [CR]";
				
				String Data_Site = "Costa Rica Corporate [187]";
				
				String Data_EndDate = "15";
				
				//String Project_Valid= "2020 Exchange - L&L - Australia [R823]";
						
				//String Site_Valid	= "Plovdiv, Bulgaria";
				
				pp.selectStartDate(Data_Start_Date);
				
				Thread.sleep(3000);
				
				pp.selectEndDate(Data_EndDate);
				
				Thread.sleep(3000);
				
				pp.selectParentClient(Data_ParentClient);
				
				Thread.sleep(4000);
				
				pp.selectClient(Data_Client);
				
				Thread.sleep(4000);
				
				pp.selectProgram(Data_program);
				
				Thread.sleep(4000);
				
				pp.selectProject(Data_project);
				
				Thread.sleep(4000);
				
				pp.selectRegion(Data_region);
				
				Thread.sleep(4000);
				
				pp.selectCountry(Data_Country);
				
				Thread.sleep(4000);

				pp.selectSite(Data_Site);
				
				Thread.sleep(4000);
				
				pp.viewPlan();
				
				Thread.sleep(6000);
				
				pp.approvePlan();
				
				Thread.sleep(3000);
				
				WebElement ele = StaffpointDriver.findElement(By.xpath("//label[@id='dialogConfirmText']"));
				
				System.out.println(ele.getText());
				
				String Exclusion_msg = "Records will not be officialized for following week ranges 04/17/2017 - 05/07/2017 as exclusion request "
						+ "exists with the same plan and week ranges. Do you wish to continue?";
						
					
				Assert.assertEquals(ele.getText().trim(), Exclusion_msg.trim());
	}
 	
}

