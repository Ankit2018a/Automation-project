package TestScripts;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import Account.CreateAccount;
import pageFactory.Login_Page;

public class VerifyAccount extends DriverConfig {
  
	@Test(priority=1)
  public void createAccount() throws AWTException, InterruptedException {

		Login_Page lp = new Login_Page();
		
		Login_Page.userLogin();
		
		Thread.sleep(5000);
		
		Thread.sleep(2000);

		CreateAccount ca = new CreateAccount(StaffpointDriver);
		
		ca.clickAccount();
		
		Thread.sleep(7000);
		
		JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
		
		js.executeScript("window.scrollBy(0,500)");
		
		ca.newAccount();
		
		Thread.sleep(2000);
		
		ca.searchDomain("TELETECH", "TELETECH");

		Thread.sleep(2000);
		
		ca.step2CreateAccount("TeleTech", "Evite");

		ca.step3InputData("Ankit12", "kaura123", "9818061");
		
		ca.step3PlanOfficializer();
		
		ca.step3rolesAdmin();
		
		//ca.AccountSave();
		
		}
	
		@Test(priority=2)
	  public void createAccountInvalidAD() throws AWTException, InterruptedException {
	

			Login_Page lp = new Login_Page();
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);

			CreateAccount ca = new CreateAccount(StaffpointDriver);
			
			ca.clickAccount();
			
			Thread.sleep(7000);
			
			JavascriptExecutor js = (JavascriptExecutor)StaffpointDriver;
			
			js.executeScript("window.scrollBy(0,500)");
			
			ca.newAccount();
			
			Thread.sleep(2000);
			
			ca.searchDomain("TELETECH", "12789");
	  
	  }


	@Test(priority=3)
	  public void viewAccount() throws AWTException, InterruptedException {
	

			Login_Page lp = new Login_Page();
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);

			CreateAccount ca = new CreateAccount(StaffpointDriver);
			
			ca.clickAccount();
			
			Thread.sleep(7000);
	
			ca.getAccountValue("3189022");

			Thread.sleep(3000);
	}
	
	

	@Test(priority=4)
	  public void editAccountRoles() throws AWTException, InterruptedException {
	

			Login_Page lp = new Login_Page();
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);

			CreateAccount ca = new CreateAccount(StaffpointDriver);
			
			ca.clickAccount();
			
			Thread.sleep(8000);
	
			ca.editAccount("2129209");
			
			Thread.sleep(2000);

			ca.step3rolesAdmin();
			
			//ca.AccountSave();
			
			
	}
	
	@Test(priority=5)
	  public void deleteAccount() throws AWTException, InterruptedException {
	

			Login_Page lp = new Login_Page();
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);

			CreateAccount ca = new CreateAccount(StaffpointDriver);
			
			ca.clickAccount();
			
			Thread.sleep(9000);
	
			ca.deleteAccount("3025009");
			
			Thread.sleep(2000);
			
			WebElement delete_Msg = StaffpointDriver.findElement(By.xpath("//div[@id='body']/section/h4"));
					
			Assert.assertEquals(delete_Msg.getText().trim(), "Are you sure you want to delete this account ?");
			
			//ca.deleteConfirm();
				
			
	}

	
	@Test(priority=6)
	  public void AddMultiParentClient() throws AWTException, InterruptedException {
	
		Login_Page lp = new Login_Page();
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);

			CreateAccount ca = new CreateAccount(StaffpointDriver);
			
			ca.clickAccount();
			
			Thread.sleep(9000);
	
			ca.editAccount("2039784");
			
			Thread.sleep(2000);
			
			ca.addParentClient("2020 Exchange [12052]");
	
			Thread.sleep(2000);
			
			//ca.AccountSave();
		
	}
	
	@Test(priority=7)
	  public void editAccountInputData() throws AWTException, InterruptedException {
	

			Login_Page lp = new Login_Page();
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);

			CreateAccount ca = new CreateAccount(StaffpointDriver);
			
			ca.clickAccount();
			
			Thread.sleep(8000);
	
			ca.editAccount("3025009");
			
			Thread.sleep(4000);

			ca.step3InputData("Ankit", "kaura", "9818061");
			
			Thread.sleep(3000);
			
			//ca.AccountSave();
			
			
	}
	
	@Test(priority=8)
	  public void editAccountPastData() throws AWTException, InterruptedException {
	

			Login_Page lp = new Login_Page();
			
			Login_Page.userLogin();
			
			Thread.sleep(5000);
			
			Thread.sleep(2000);

			CreateAccount ca = new CreateAccount(StaffpointDriver);
			
			ca.clickAccount();
			
			Thread.sleep(8000);
			
			
			Thread.sleep(8000);
	
			ca.editAccount("3025009");
			
			Thread.sleep(4000);
	
			ca.step3EditPastData();
			
			Thread.sleep(3000);
			
			//ca.AccountSave();
			
			
	}
	
	
}
